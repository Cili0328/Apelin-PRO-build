import ApelinCore
import ApelinProtocol
import Darwin
import Foundation

extension AgentWorker {
    /// Check the received descriptor itself, including when the caller passes a pipe.
    static func readAttachment(_ descriptor: OwnedDescriptor) throws -> Data {
        var info = stat()
        guard fstat(descriptor.rawValue, &info) == 0,
              info.st_mode & S_IFMT == S_IFREG, info.st_size >= 0
        else {
            throw ApelinError(.badRequest, "attachments must be regular files")
        }
        let handle = FileHandle(fileDescriptor: descriptor.rawValue, closeOnDealloc: false)
        try handle.seek(toOffset: 0)
        return try handle.readToEnd() ?? Data()
    }
}
