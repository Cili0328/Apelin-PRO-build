import ApelinProtocol
import Foundation
import KWWKAI

/// One selected group's keys. A rejected key stays spent for this session;
/// changing the saved configuration opens a fresh pool.
actor RelayCredentialPool {
    let original: OAuthCredentials
    let accounts: [(id: String, key: String)]
    private var index = 0
    private var exhausted = Set<String>()
    private let store: any CredentialSource
    private let statusID: String

    init(
        credentials: OAuthCredentials, groupID: String?, model: String?,
        storeID: String, store: any CredentialSource
    ) throws {
        original = credentials
        self.store = store
        statusID = RelayCredentials.statusID(storeID: storeID, groupID: groupID)
        let configuration = try RelayCredentials.configuration(credentials)
        let groupID = groupID ?? AgentRelayConfiguration.defaultGroupID
        if groupID != AgentRelayConfiguration.defaultGroupID {
            guard let group = configuration.groups.first(where: { $0.id == groupID }),
                  let model, group.models.contains(model)
            else { throw ApelinError(.badRequest, "The selected model is not available in this API group.") }
        }
        var entries: [(id: String, key: String)] = []
        if groupID == AgentRelayConfiguration.defaultGroupID {
            entries.append(("primary", credentials.access))
        }
        for account in configuration.accounts where account.enabled && account.groupID == groupID {
            if !entries.contains(where: { $0.key == account.apiKey }) {
                entries.append((account.id, account.apiKey))
            }
        }
        guard !entries.isEmpty else { throw ApelinError(.denied, "No enabled account is available in this API group.") }
        accounts = entries
    }

    func restore() async {
        if let status = try? await store.credentials(for: statusID),
           let id = DeepSeekProvider.extra("activeAccountID", in: status),
           let saved = accounts.firstIndex(where: { $0.id == id }) {
            index = saved
        }
    }

    func credentials() -> OAuthCredentials {
        var value = original
        value.access = accounts[index].key
        return value
    }

    func options(_ original: StreamOptions?) -> StreamOptions {
        var options = original ?? StreamOptions()
        let key = accounts[index].key
        options.apiKey = key
        options.resolvedAuth = ResolvedProviderAuth(token: key, scheme: .bearer)
        return options
    }

    func reject(_ failure: ProviderFailure, attempted: StreamOptions?) async -> Bool {
        do {
            try Task.checkCancellation()
            try attempted?.cancellation?.throwIfCancelled()
        } catch { return false }
        guard Self.isExhausted(failure), let key = attempted?.apiKey,
              let rejected = accounts.first(where: { $0.key == key })
        else { return false }
        exhausted.insert(rejected.id)
        if accounts[index].key != key, !exhausted.contains(accounts[index].id) { return true }
        guard let next = accounts.indices.first(where: { !exhausted.contains(accounts[$0].id) }) else {
            return false
        }
        index = next
        // This separate keychain item contains an ID only. Never rewrite the
        // saved configuration while a user may be editing it in another worker.
        var status = OAuthCredentials(access: "", refresh: "", expires: .max)
        status.extras["activeAccountID"] = .string(accounts[next].id)
        try? await store.store(status, for: statusID)
        return true
    }

    static func isExhausted(_ failure: ProviderFailure) -> Bool {
        if failure.category == .cancelled { return false }
        let code = failure.providerCode?.lowercased() ?? ""
        if ["insufficient_quota", "insufficient_balance", "quota_exceeded", "balance_not_enough",
            "account_quota_exhausted", "credit_balance_too_low"].contains(code) { return true }
        if failure.category == .quota || failure.httpStatus == 402 { return true }
        let message = (failure.message + " " + (failure.upstreamMessage ?? "")).lowercased()
        return ["insufficient balance", "insufficient quota", "insufficient credits",
                "credit balance is too low", "balance is not enough", "quota exhausted",
                "quota has been exhausted", "余额不足", "额度已用尽", "配额已耗尽", "账户余额不足"]
            .contains(where: message.contains)
    }
}

public enum RelayCredentials {
    public static func configuration(_ credentials: OAuthCredentials) throws -> AgentRelayConfiguration {
        guard let text = DeepSeekProvider.extra("relayConfiguration", in: credentials) else { return .init() }
        return try AgentRelayConfiguration.decode(text)
    }

    public static func statusID(storeID: String, groupID: String?) -> String {
        "apelin-relay-active.\(storeID).\(groupID ?? AgentRelayConfiguration.defaultGroupID)"
    }
}

/// Replaced only between runs, but read by streaming and compaction tasks.
final class RelayRoutingState: @unchecked Sendable {
    private let lock = NSLock()
    private var pool: RelayCredentialPool?

    init(_ pool: RelayCredentialPool?) {
        self.pool = pool
    }

    func update(_ pool: RelayCredentialPool?) {
        lock.withLock { self.pool = pool }
    }

    private var current: RelayCredentialPool? { lock.withLock { pool } }

    func options(_ options: StreamOptions?) async -> StreamOptions? {
        guard let pool = current else { return options }
        return await pool.options(options)
    }

    func reject(_ failure: ProviderFailure, attempted: StreamOptions?) async -> Bool {
        guard let pool = current else { return false }
        return await pool.reject(failure, attempted: attempted)
    }
}
