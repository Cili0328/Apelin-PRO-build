import Foundation
import KWWKAgent
import KWWKAI

/// kwwk's native compaction, except that a reply with no summary in it
/// falls back to kwwk's own summary instead of failing the compaction.
///
/// Anthropic's compaction can answer 200, stop reason `compaction`, with a
/// `compaction` block whose content is null: its documentation names a tool
/// called in place of the summary. kwwk keeps that an error ("Anthropic
/// compaction returned no summary") and does not summarise itself, so a
/// chat whose context had filled stopped with "context is too large and
/// compaction failed". A route that cannot compact natively answers nil and
/// kwwk summarises; this answers nil for a reply that brought nothing back
/// too. A refusal, a status, a transport failure and a cancellation stay
/// errors, and so does any failure kwwk would try again.
enum NativeCompactionFallback {
    static func compact(_ native: @escaping NativeCompactionFn = compactNative) -> NativeCompactionFn {
        { model, context, instructions, options in
            do {
                return try await native(model, context, instructions, options)
            } catch let error where returnedNoSummary(error) {
                return nil
            }
        }
    }

    /// A failure kwwk made of a reply that came back without a summary —
    /// none in it, or not the compaction asked for: no HTTP status, no
    /// transport or provider code, nothing it reads as a refusal or a limit
    /// (its own "Invalid …" wording reads as a bad request), and nothing it
    /// would retry.
    static func returnedNoSummary(_ error: any Error) -> Bool {
        guard let failure = error as? ProviderFailure else { return false }
        return failure.httpStatus == nil && failure.transportDomain == nil && failure.transportCode == nil
            && failure.providerCode == nil && [.unknown, .invalidRequest].contains(failure.category)
            && !failure.isRetryable
    }

    /// The compaction a session runs, on its own as the context fills and
    /// when the app asks: this in front of kwwk's native compaction, and
    /// kwwk's own numbers tightened.
    ///
    /// A chat that fills up fails with "compaction left <n> tokens, above the
    /// recovery target of <m>". The target is
    /// `window × threshold × recoveryRatio`, so on a 128k window with kwwk's
    /// defaults it is 131072 × 0.75 × 0.8 = 78643 — and the summary a long
    /// session produces lands well above that. kwwk retries by shrinking the
    /// recent tail and giving up after `maxSummaryAttempts` (2), which is not
    /// enough attempts to walk a large transcript down to the target:
    ///
    /// - `maxSummaryAttempts` 8, so the tail keeps halving instead of the
    ///   third attempt never happening. `maxSummaryAttempts` is capped in
    ///   effect by the tail reaching one message, so the extra attempts cost
    ///   nothing once the plan stops moving.
    /// - `recoveryRatio` 0.95, which lifts the target to 93388 on the same
    ///   window — still under `AgentRequestBudget.inputTokens` (98304), so
    ///   the summary that comes back is one the provider will accept.
    /// - `keepRecentTokens` 6000, so the first attempt starts closer to the
    ///   answer rather than spending an attempt on a 20000-token tail.
    /// - `summaryWordTarget` 600, so each recap is shorter to begin with.
    ///
    /// None of these change what a summary is: they change how hard the
    /// compactor tries and where it aims. The transcript still ends up with
    /// a recap plus the recent tail, and a session that fits is untouched.
    static var configuration: AgentContextCompactionConfig {
        AgentContextCompactionConfig(
            summaryWordTarget: 600,
            keepRecentTokens: 6_000,
            recoveryRatio: 0.95,
            maxSummaryAttempts: 8,
            nativeCompaction: compact(),
        )
    }
}
