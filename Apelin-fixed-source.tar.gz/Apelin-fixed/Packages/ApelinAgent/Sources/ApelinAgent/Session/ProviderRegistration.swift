import ApelinProtocol
import Foundation
import KWWKAI

/// The same registration for account verification and conversation requests.
/// kwwk owns the transports; Apelin adds DeepSeek's separate credential and
/// restores the catalog capabilities its generic Chat Completions login loses.
public enum ProviderRegistration {
    public static func resolve(
        storeID: String,
        manager: OAuthManager,
        modelOverride: String? = nil,
    ) async throws -> ResolvedAuth? {
        guard let credentials = try await manager.credentials(for: storeID) else { return nil }
        if storeID == CredentialProviderID.deepSeek {
            let id = modelOverride ?? DeepSeekProvider.extra("defaultModel", in: credentials) ?? DeepSeekProvider.defaultModel
            let base = DeepSeekProvider.extra("baseUrl", in: credentials) ?? DeepSeekProvider.baseURL
            let fallback = Model(id: id, api: "openai-completions", provider: "deepseek", baseURL: base)
            let model = DeepSeekProvider.applyingCatalog(to: fallback)
            await APIRegistry.shared.register(OpenAICompletionsProvider(), scope: model.provider)
            return ResolvedAuth(model: model, modelLabel: "\(model.name) from DeepSeek", authResolver: { _, _ in
                ResolvedProviderAuth(token: credentials.access, scheme: .bearer)
            })
        }
        let registered: ResolvedAuth? = if CredentialProviderID.endpointNumber(storeID) != nil {
            // kwwk knows one OpenAI-compatible login, by its store id. A
            // further endpoint is registered as that login, from its own
            // credentials: the model carries its base URL, and the key is
            // bound to this resolution below.
            try await registerStored(
                storeId: CredentialProviderID.openAICompatible,
                manager: OAuthManager(
                    source: DeliveredCredentialSource([CredentialProviderID.openAICompatible: credentials]),
                ),
                modelOverride: modelOverride,
            )
        } else {
            try await registerStored(storeId: storeID, manager: manager, modelOverride: modelOverride)
        }
        guard let resolved = registered else { return nil }
        guard CredentialProviderID.isOpenAICompatible(storeID) else {
            return resolved
        }
        let apiFormat = AgentAPIFormat(rawValue: DeepSeekProvider.extra("apiFormat", in: credentials) ?? "") ?? .chatCompletions
        var model = resolved.model
        model.api = apiFormat.rawValue
        // Keep endpoint settings on the resolved model, never on a shared
        // registry transport that another account can replace mid-request.
        let headers = try ProviderRequestConfiguration.headers(in: credentials)
        var combined = model.headers ?? [:]
        for (name, value) in headers {
            for existing in Array(combined.keys) where existing.lowercased() == name.lowercased() {
                combined.removeValue(forKey: existing)
            }
            combined[name] = value
        }
        model.headers = combined
        switch apiFormat {
        case .chatCompletions:
            await APIRegistry.shared.register(OpenAICompletionsProvider(), scope: model.provider)
        case .responses:
            await APIRegistry.shared.register(OpenAIResponsesProvider(webSocketClient: nil), scope: model.provider)
        }
        // The registry's transport is shared. Bind the key to this resolution
        // so another account verification cannot replace an in-flight key.
        return ResolvedAuth(
            model: DeepSeekProvider.isOfficial(credentials) ? DeepSeekProvider.applyingCatalog(to: model) : model,
            modelLabel: resolved.modelLabel,
            authResolver: { _, _ in ResolvedProviderAuth(token: credentials.access, scheme: .bearer) },
            providerSlots: resolved.providerSlots,
            authResolvers: resolved.authResolvers,
        )
    }
}

public enum ProviderRequestConfiguration {
    public static func parseHeaders(_ text: String) throws -> [String: String] {
        let invalid = ApelinError(.badRequest, "Enter valid request headers as a JSON object of text values. Authentication and transport headers cannot be overridden.")
        guard text.utf8.count <= 8192,
              let data = text.data(using: .utf8),
              let object = try? JSONSerialization.jsonObject(with: data),
              let headers = object as? [String: String],
              headers.count <= 24
        else { throw invalid }
        let reserved: Set<String> = [
            "authorization", "proxy-authorization", "x-api-key", "api-key", "cookie", "set-cookie",
            "host", "content-length", "content-type", "accept", "accept-encoding", "connection",
            "transfer-encoding", "upgrade", "trailer", "te",
        ]
        let punctuation = "!#$%&'*+-.^_`|~"
        var seen = Set<String>()
        for (name, value) in headers {
            let lower = name.lowercased()
            guard !name.isEmpty, name.utf8.count <= 128,
                  name.utf8.allSatisfy({
                      (48...57).contains($0) || (65...90).contains($0) || (97...122).contains($0)
                          || punctuation.utf8.contains($0)
                  }),
                  value.utf8.count <= 2048,
                  value.unicodeScalars.allSatisfy({ $0.value >= 32 && $0.value < 127 }),
                  !reserved.contains(lower), seen.insert(lower).inserted
            else { throw invalid }
        }
        return headers
    }

    public static func headers(in credentials: OAuthCredentials) throws -> [String: String] {
        var headers: [String: String] = ["User-Agent": "Apelin/0.5.7"]
        if let custom = DeepSeekProvider.extra("customHeaders", in: credentials) {
            for (name, value) in try parseHeaders(custom) {
                if name.lowercased() == "user-agent" {
                    headers.removeValue(forKey: "User-Agent")
                }
                headers[name] = value
            }
        }
        if let userAgent = DeepSeekProvider.extra("userAgent", in: credentials) {
            guard userAgent.utf8.count <= 512,
                  userAgent.unicodeScalars.allSatisfy({ $0.value >= 32 && $0.value < 127 })
            else { throw ApelinError(.badRequest, "Enter a valid User-Agent without line breaks.") }
            for key in Array(headers.keys) where key.lowercased() == "user-agent" {
                headers.removeValue(forKey: key)
            }
            headers["User-Agent"] = userAgent
        }
        return headers
    }
}

public enum DeepSeekProvider {
    public static let baseURL = "https://api.deepseek.com"
    public static let defaultModel = "deepseek-flash"

    public static func isOfficial(_ credentials: OAuthCredentials) -> Bool {
        guard let base = extra("baseUrl", in: credentials) else { return false }
        return URLComponents(string: base)?.host?.lowercased() == "api.deepseek.com"
    }

    /// Only documented aliases inherit Flash's capabilities. Unknown IDs keep
    /// their original configuration, and the selected wire ID is never renamed.
    static func applyingCatalog(to original: Model) -> Model {
        let catalogID: String = switch original.id {
        case "deepseek-v4-flash", "deepseek-v4-flash-vision-exp": defaultModel
        default: original.id
        }
        guard var model = ModelsCatalog.model(provider: "deepseek", id: catalogID) else { return original }
        model.id = original.id
        model.api = original.api
        model.provider = original.provider
        model.baseURL = original.baseURL
        model.headers = original.headers
        return model
    }

    static func extra(_ key: String, in credentials: OAuthCredentials) -> String? {
        guard case let .string(value)? = credentials.extras[key], !value.isEmpty else { return nil }
        return value
    }
}
