import Foundation
import KWWKAgent
import KWWKAI
import Network

public struct NetworkPath: Sendable {
    public var isSatisfied: @Sendable () -> Bool

    public init(isSatisfied: @escaping @Sendable () -> Bool) {
        self.isSatisfied = isSatisfied
    }

    public static var system: NetworkPath {
        let monitor = PathMonitor.shared
        return NetworkPath { monitor.isSatisfied }
    }
}

private final class PathMonitor: @unchecked Sendable {
    static let shared = PathMonitor()
    private let monitor = NWPathMonitor()
    private let lock = NSLock()
    @objc private dynamic var unsatisfied = false

    private init() {
        monitor.pathUpdateHandler = { [weak self] path in
            self?.update(unsatisfied: path.status == .unsatisfied)
        }
        monitor.start(queue: DispatchQueue(label: "wiki.qaq.apelin.agent.network-path"))
    }

    @objc dynamic var isSatisfied: Bool {
        lock.withLock { !unsatisfied }
    }

    @objc private dynamic func update(unsatisfied: Bool) {
        lock.withLock { self.unsatisfied = unsatisfied }
    }
}

/// Retries the current model request, preserving already settled tool results.
/// The SDK receives only the successful settlement or a permanent failure.
enum NetworkRecovery {
    enum Wait: Sendable {
        case route, handshake, retry
    }

    struct Patience: Sendable {
        var pathPoll: UInt64 = 1000
        var baseDelay: UInt64 = 1000
        var maximumDelay: UInt64 = 30000

        static let standard = Patience()
    }

    static func stream(
        path: NetworkPath,
        patience: Patience = .standard,
        routing: RelayRoutingState? = nil,
        inner: @escaping StreamFn = { model, context, options in
            try await KWWKAI.stream(model: model, context: context, options: options)
        },
        onWait: @escaping @Sendable (Wait) async -> Void,
    ) -> StreamFn {
        { model, context, options in
            // This provider can execute tools inside its stream. Only the SDK
            // has the invocation ledger needed to decide whether replay is safe.
            if model.api == "cursor-agent" {
                return try await inner(model, context, options)
            }
            let (stream, out) = AssistantMessageStream.makeStream()
            Task {
                await relay(
                    to: out, model: model, path: path, patience: patience,
                    cancellation: options?.cancellation, onWait: onWait,
                    routing: routing, options: options,
                ) { attempted in
                    try await inner(model, context, attempted)
                }
            }
            return stream
        }
    }

    static func isFailedHandshake(_ failure: ProviderFailure) -> Bool {
        failure.transportDomain == NSURLErrorDomain && failure.transportCode == NSURLErrorSecureConnectionFailed
    }

    static func isRecoverable(_ failure: ProviderFailure) -> Bool {
        if failure.shouldRetry == false {
            return false
        }
        if let status = failure.httpStatus, (400 ..< 500).contains(status),
           status != 408, status != 429
        {
            return false
        }
        if [.authentication, .quota, .refusal, .cancelled, .contextOverflow].contains(failure.category) {
            return false
        }
        if failure.isRetryable || isFailedHandshake(failure) {
            return true
        }
        if failure.transportDomain == NSURLErrorDomain,
           let code = failure.transportCode,
           [NSURLErrorCannotParseResponse, NSURLErrorCannotDecodeRawData,
            NSURLErrorCannotDecodeContentData].contains(code)
        {
            return true
        }
        if failure.transportDomain == NSCocoaErrorDomain, failure.transportCode == 3840 {
            return true
        }
        if failure.providerCode == "apelin_response_decode_error" {
            return true
        }
        let text = failure.message.lowercased()
        return ["cannot parse response", "could not parse response", "unable to parse response",
                "failed to parse response", "invalid json response", "malformed response",
                "unexpected end of json"].contains(where: text.contains)
    }

    static func delay(for failure: ProviderFailure, attempt: Int, patience: Patience) -> UInt64 {
        if let requested = failure.retryAfterMs, requested.isFinite,
           requested >= 0, requested < Double(UInt64.max)
        {
            return UInt64(requested.rounded(.up))
        }
        var milliseconds = min(
            Double(patience.maximumDelay),
            Double(patience.baseDelay) * pow(2, Double(min(attempt, 30))),
        )
        if let reset = failure.rateLimitResetMs, reset.isFinite, reset > 0 {
            milliseconds = max(milliseconds, min(reset, Double(patience.maximumDelay)))
        }
        return UInt64(milliseconds)
    }

    private static func relay(
        to out: AssistantMessageStream.Continuation,
        model: Model,
        path: NetworkPath,
        patience: Patience,
        cancellation: CancellationHandle?,
        onWait: @Sendable (Wait) async -> Void,
        routing: RelayRoutingState?,
        options: StreamOptions?,
        ask: @Sendable (StreamOptions?) async throws -> AssistantMessageStream,
    ) async {
        var retries = 0
        while true {
            var ending: AssistantMessageEvent?
            let final: AssistantMessage
            let attempted = await routing?.options(options) ?? options
            do {
                try await ProviderRetryPolicy.wait(0, cancellation: cancellation)
                let attempt = try await ask(attempted)
                // Exactly one start per attempt, even if a provider omits it.
                out.push(.start(partial: AssistantMessage(
                    content: [], api: model.api, provider: model.provider, model: model.id,
                )))
                for await event in attempt {
                    switch event {
                    case .done, .error: ending = event
                    case .start: break
                    default: out.push(event)
                    }
                }
                final = await attempt.result()
            } catch {
                var failure = ProviderFailure.capture(error)
                if error is DecodingError {
                    failure.providerCode = "apelin_response_decode_error"
                }
                final = AssistantMessage(
                    content: [], api: model.api, provider: model.provider, model: model.id,
                    stopReason: failure.category == .cancelled ? .aborted : .error,
                    errorMessage: failure.message, failure: failure,
                )
            }
            guard final.stopReason == .error, let failure = final.providerFailure else {
                finish(out, ending, final)
                return
            }
            if await routing?.reject(failure, attempted: attempted) == true {
                await onWait(.retry)
                continue
            }
            guard isRecoverable(failure) else {
                finish(out, ending, final)
                return
            }
            let lacksRoute = !path.isSatisfied()
            await onWait(lacksRoute ? .route : (isFailedHandshake(failure) ? .handshake : .retry))
            do {
                while !path.isSatisfied() {
                    try await ProviderRetryPolicy.wait(max(1, patience.pathPoll), cancellation: cancellation)
                }
                try await ProviderRetryPolicy.wait(
                    delay(for: failure, attempt: retries, patience: patience), cancellation: cancellation,
                )
            } catch {
                let stopped = AssistantMessage(
                    content: [], api: model.api, provider: model.provider, model: model.id,
                    stopReason: .aborted, errorMessage: "Request was aborted",
                )
                finish(out, .error(reason: .aborted, error: stopped), stopped)
                return
            }
            retries = min(retries + 1, 30)
        }
    }

    private static func finish(
        _ out: AssistantMessageStream.Continuation,
        _ ending: AssistantMessageEvent?,
        _ final: AssistantMessage,
    ) {
        if let ending {
            out.push(ending)
        }
        out.end(final)
    }
}
