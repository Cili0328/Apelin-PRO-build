import UIKit

/// How full the window is, as a line above the composer.
///
/// A conversation that is running out of room is worth knowing about before
/// the message that fails, and this is the one place it can be said without
/// taking a row: a label, a bar and the two numbers, on the line the keyboard
/// would otherwise push up against. Tapping it opens the inspector, which is
/// where the reason lives.
final class ContextMeterView: UIView {
    var onTap: (() -> Void)?

    private let label = UILabel()
    private let track = UIView()
    private let fill = UIView()
    private let value = UILabel()
    private var fraction: CGFloat = 0

    override init(frame: CGRect) {
        super.init(frame: frame)
        layer.cornerRadius = 9
        layer.cornerCurve = .continuous

        label.font = .systemFont(ofSize: 11.5, weight: .semibold)
        label.setContentHuggingPriority(.required, for: .horizontal)
        label.setContentCompressionResistancePriority(.required, for: .horizontal)
        label.text = String(localized: "Context")

        track.layer.cornerRadius = 2
        track.clipsToBounds = true
        track.translatesAutoresizingMaskIntoConstraints = false
        fill.layer.cornerRadius = 2
        track.addSubview(fill)

        value.font = .monospacedDigitSystemFont(ofSize: 11.5, weight: .semibold)
        value.setContentHuggingPriority(.required, for: .horizontal)
        value.setContentCompressionResistancePriority(.required, for: .horizontal)

        let row = UIStackView(arrangedSubviews: [label, track, value])
        row.axis = .horizontal
        row.spacing = 8
        row.alignment = .center
        row.isUserInteractionEnabled = false
        row.translatesAutoresizingMaskIntoConstraints = false
        addSubview(row)
        NSLayoutConstraint.activate([
            row.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 10),
            row.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -10),
            row.topAnchor.constraint(equalTo: topAnchor, constant: 7),
            row.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -7),
            track.heightAnchor.constraint(equalToConstant: 3.5),
        ])

        addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handleTap)))
        isAccessibilityElement = true
        accessibilityTraits = .button
        isHidden = true
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        fill.frame = CGRect(x: 0, y: 0, width: track.bounds.width * fraction, height: track.bounds.height)
    }

    func show(_ usage: ChatContextUsage) {
        fraction = CGFloat(usage.fraction)
        // a conversation with nothing in it has nothing to report; from the
        // first message on, the line stays put
        isHidden = usage.tokens <= 0
        let tint: UIColor = usage.isCritical
            ? .systemRed
            : (usage.isLarge ? .systemOrange : .systemGreen)
        backgroundColor = tint.withAlphaComponent(0.10)
        track.backgroundColor = tint.withAlphaComponent(0.22)
        fill.backgroundColor = tint
        label.textColor = Self.ink(critical: usage.isCritical, large: usage.isLarge)
        value.textColor = Self.ink(critical: usage.isCritical, large: usage.isLarge)
        value.text = usage.meterText
        accessibilityLabel = "\(String(localized: "Context")) \(usage.meterText)"
        setNeedsLayout()
    }

    @objc private func handleTap() {
        onTap?()
    }

    /// The design's darker text on the pale wash of the same hue, so the line
    /// reads at 11.5 points without a second colour scale.
    private static func ink(critical: Bool, large: Bool) -> UIColor {
        if critical { return UIColor(red: 0.70, green: 0.15, blue: 0.12, alpha: 1) }
        if large { return UIColor(red: 0.64, green: 0.35, blue: 0, alpha: 1) }
        return UIColor(red: 0.12, green: 0.48, blue: 0.22, alpha: 1)
    }
}
