import ApelinProtocol
import UIKit

/// The saved, enabled catalogue, grouped by its real provider and searchable.
final class ChatModelPickerController: UITableViewController, UISearchResultsUpdating {
    private let accounts: [AgentAccount]
    private let selected: ComposerModelSelection?
    private let onSelect: (String, AgentAccount) -> Void
    private let search = UISearchController(searchResultsController: nil)
    private var sections: [(account: AgentAccount, models: [String])] = []

    init(accounts: [AgentAccount], selected: ComposerModelSelection?, onSelect: @escaping (String, AgentAccount) -> Void) {
        self.accounts = accounts
        self.selected = selected
        self.onSelect = onSelect
        super.init(style: .plain)
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("Use init(accounts:selected:onSelect:)")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = String(localized: "Select Model")
        view.tintColor = ChatPalette.accent
        tableView.backgroundColor = .clear
        tableView.backgroundView = ChatGlassView(style: .systemMaterial)
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 64
        tableView.keyboardDismissMode = .onDrag
        tableView.separatorColor = .separator.withAlphaComponent(0.35)
        search.searchResultsUpdater = self
        search.obscuresBackgroundDuringPresentation = false
        search.searchBar.placeholder = String(localized: "Search")
        search.searchBar.searchBarStyle = .minimal
        navigationItem.searchController = search
        navigationItem.hidesSearchBarWhenScrolling = false
        definesPresentationContext = true
        updateSearchResults(for: search)
    }

    @objc dynamic func updateSearchResults(for searchController: UISearchController) {
        let query = (searchController.searchBar.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        sections = accounts.compactMap { account in
            let name = ProviderLabel.name(of: account.provider) ?? account.account ?? account.provider.displayName
            let matchesProvider = name.localizedCaseInsensitiveContains(query)
                || Self.groupName(account)?.localizedCaseInsensitiveContains(query) == true
            let models = (account.models ?? []).filter {
                query.isEmpty || matchesProvider || $0.localizedCaseInsensitiveContains(query)
            }
            return models.isEmpty ? nil : (account, models)
        }
        tableView.reloadData()
        if #available(iOS 17.0, *) {
            contentUnavailableConfiguration = sections.isEmpty ? UIContentUnavailableConfiguration.search() : nil
        }
    }

    override func numberOfSections(in _: UITableView) -> Int {
        sections.count
    }

    override func tableView(_: UITableView, numberOfRowsInSection section: Int) -> Int {
        sections[section].models.count
    }

    override func tableView(_: UITableView, titleForHeaderInSection section: Int) -> String? {
        let account = sections[section].account
        let providerName = ProviderLabel.name(of: account.provider) ?? account.account ?? account.provider.displayName
        let name = Self.groupName(account).map { "\(providerName) · \($0)" } ?? providerName
        if account.relayGroupID != nil || account.modelGroups?.isEmpty == false {
            return name
        }
        let identity = ProviderBalanceHistory.identity(providerRawValue: account.provider.rawValue, baseURL: account.account ?? "")
        guard ProviderMetaStore.meta(for: account.provider.rawValue).balanceEnabled,
              let balance = ProviderBalanceHistory.cachedText(identity)
        else { return name }
        return "\(name) · \(String(localized: "Balance")) \(balance)"
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "model") ?? UITableViewCell(style: .subtitle, reuseIdentifier: "model")
        let section = sections[indexPath.section]
        let model = section.models[indexPath.row]
        var content = cell.defaultContentConfiguration()
        content.text = model
        content.textProperties.font = .preferredFont(forTextStyle: .subheadline)
        content.textProperties.numberOfLines = 0
        content.secondaryText = Self.groupName(section.account)
            ?? ProviderLabel.name(of: section.account.provider) ?? section.account.account ?? section.account.provider.displayName
        content.secondaryTextProperties.font = .preferredFont(forTextStyle: .caption1)
        content.secondaryTextProperties.color = .secondaryLabel
        content.image = UIImage(systemName: "cpu")
        content.imageProperties.tintColor = ChatPalette.accent
        cell.contentConfiguration = content
        cell.backgroundColor = .clear
        let checked = section.account.provider == selected?.provider
            && section.account.relayGroupID == selected?.relayGroupID && model == selected?.model
        cell.accessoryType = checked ? .checkmark : .none
        cell.accessibilityTraits = checked ? [.button, .selected] : .button
        return cell
    }

    override func tableView(_: UITableView, didSelectRowAt indexPath: IndexPath) {
        let section = sections[indexPath.section]
        onSelect(section.models[indexPath.row], section.account)
        dismiss(animated: true)
    }

    private static func groupName(_ account: AgentAccount) -> String? {
        let id = account.relayGroupID ?? AgentRelayConfiguration.defaultGroupID
        return account.modelGroups?.first { $0.id == id }?.name
    }
}
