import ApelinProtocol
import Foundation

struct RelayAccountSummary: Equatable {
    let id: String
    let name: String
    let keySuffix: String
    let enabled: Bool
    let priority: Int?
}

struct RelayAccountSnapshot: Equatable {
    let groupName: String
    let accounts: [RelayAccountSummary]
    let activeAccountID: String?

    var hasStandbyAccount: Bool {
        accounts.filter(\.enabled).count > 1
    }

    init(configuration: AgentRelayConfiguration, primaryKey: String, groupID: String?, activeAccountID: String?) {
        let groupID = groupID ?? AgentRelayConfiguration.defaultGroupID
        groupName = configuration.groups.first { $0.id == groupID }?.name
            ?? String(localized: "Default API Group")
        var accounts: [RelayAccountSummary] = []
        var keys = Set<String>()
        var priority = 0
        if groupID == AgentRelayConfiguration.defaultGroupID, !primaryKey.isEmpty {
            priority += 1
            keys.insert(primaryKey)
            accounts.append(.init(
                id: "primary", name: String(localized: "Primary Account"),
                keySuffix: primaryKey.count > 4 ? String(primaryKey.suffix(4)) : "****",
                enabled: true, priority: priority,
            ))
        }
        for account in configuration.accounts where account.groupID == groupID {
            if account.enabled {
                guard keys.insert(account.apiKey).inserted else { continue }
                priority += 1
            }
            accounts.append(.init(
                id: account.id, name: account.name,
                keySuffix: account.apiKey.count > 4 ? String(account.apiKey.suffix(4)) : "****",
                enabled: account.enabled, priority: account.enabled ? priority : nil,
            ))
        }
        self.accounts = accounts
        self.activeAccountID = accounts.first { $0.enabled && $0.id == activeAccountID }?.id
    }
}
