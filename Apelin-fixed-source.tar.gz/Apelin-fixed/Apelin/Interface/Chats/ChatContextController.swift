import ApelinProtocol
import UIKit

/// What the conversation is made of, by size, and what to do about it.
///
/// The point is not the total — the line above the composer already says that
/// — but which part is taking the room and what can be done now. A
/// conversation that is almost all tool output wants one thing; one whose own
/// replies are the bulk wants another. The failure card at the top is the
/// same question asked after the fact, with the one action that answers it.
final class ChatContextController: TableController {
    private let usage: ChatContextUsage
    private let messages: [ChatMessage]
    private let messageCount: Int
    /// Why the last compaction failed, when it did. The numbers are the
    /// diagnosis; this is the sentence the agent gave.
    private let failure: String?
    /// Folds the oversized tool output and asks the session to compact again.
    var onTrimAndRetry: (() -> Void)?
    /// Asks for a compaction now, without changing anything first.
    var onCompact: (() -> Void)?

    /// The parts a request is made of. Only `history` is measured here; the
    /// other three are assembled by the agent after the app hands over the
    /// messages, so they are the design's estimates and say so.
    private enum Part: String, CaseIterable, Hashable {
        case systemPrompt
        case tools
        case memory
        case history

        var title: String {
            switch self {
            case .systemPrompt: String(localized: "System Prompt")
            case .tools: String(localized: "Tool Definitions")
            case .memory: String(localized: "Memory")
            case .history: String(localized: "Message History")
            }
        }

        var tokens: Double {
            switch self {
            case .systemPrompt: ChatContextUsage.systemPromptEstimate
            case .tools: ChatContextUsage.toolCatalogEstimate
            case .memory: ChatContextUsage.memoryEstimate
            case .history: 0 // filled in from the measurement
            }
        }
    }

    private enum Row: Hashable {
        case alert
        case total
        case part(Part)
        case largest(Int)
        case autoCompact
        case autoTrim
        case toolLimit
        case threshold
        case keepRecent
        case note
    }

    private enum Section: Hashable {
        case alert
        case breakdown
        case largest
        case tuning
        case note
    }

    private lazy var dataSource = TableDataSource<Section, Row, Row>(
        tableView: tableView,
        identifier: { $0 },
    ) { [weak self] _, _, row in
        self?.cell(for: row)
    }

    init(usage: ChatContextUsage, messages: [ChatMessage], messageCount: Int, failure: String? = nil) {
        self.usage = usage
        self.messages = messages
        self.messageCount = messageCount
        self.failure = failure
        super.init(style: .insetGrouped)
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = String(localized: "Context")
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 48
        dataSource.headerTitle = { section in
            switch section {
            case .breakdown: return String(localized: "Breakdown")
            case .largest: return String(localized: "Largest Messages")
            case .tuning: return String(localized: "Compaction")
            case .alert, .note: return nil
            }
        }
        rebuild()
    }

    private func rebuild() {
        var sections: [(Section, [Row])] = []
        if failure != nil {
            sections.append((.alert, [.alert]))
        }
        sections.append((.breakdown, [.total] + Part.allCases.map(Row.part)))
        let largest = ChatContextUsage.largest(messages)
        if !largest.isEmpty {
            sections.append((.largest, largest.indices.map { .largest($0) }))
        }
        sections.append((.tuning, [.autoCompact, .autoTrim, .toolLimit, .threshold, .keepRecent]))
        sections.append((.note, [.note]))
        dataSource.update(sections)
    }

    private func cell(for row: Row) -> UITableViewCell {
        switch row {
        case .alert: alertCell()
        case .total: totalCell()
        case let .part(part): partCell(part)
        case let .largest(index): largestCell(index)
        case .autoCompact: autoCompactCell()
        case .autoTrim: autoTrimCell()
        case .toolLimit: toolLimitCell()
        case .threshold: readOnlyCell(String(localized: "Threshold"), "80%")
        case .keepRecent: readOnlyCell(String(localized: "Keep Recent"), "6,000")
        case .note: noteCell()
        }
    }

    // MARK: - Cards

    /// The failure, in words, with the action that fixes it.
    private func alertCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.selectionStyle = .none
        cell.backgroundColor = UIColor.systemRed.withAlphaComponent(0.07)

        let icon = UIImageView(image: UIImage(systemName: "exclamationmark.circle"))
        icon.tintColor = UIColor(red: 0.70, green: 0.15, blue: 0.12, alpha: 1)
        icon.setContentHuggingPriority(.required, for: .horizontal)

        let title = UILabel()
        title.text = String(localized: "Compaction Failed")
        title.font = .systemFont(ofSize: 14, weight: .semibold)
        title.textColor = UIColor(red: 0.70, green: 0.15, blue: 0.12, alpha: 1)

        let heading = UIStackView(arrangedSubviews: [icon, title, UIView()])
        heading.axis = .horizontal
        heading.spacing = 8
        heading.alignment = .center

        let body = UILabel()
        body.numberOfLines = 0
        body.font = .systemFont(ofSize: 12.5)
        body.textColor = UIColor(red: 0.55, green: 0.16, blue: 0.13, alpha: 1)
        body.text = failure ?? String(localized: "Compaction left the conversation above the target.")

        var configuration = UIButton.Configuration.plain()
        var label = AttributedString(String(localized: "Trim Tool Output and Retry"))
        label.font = .systemFont(ofSize: 13, weight: .semibold)
        configuration.attributedTitle = label
        configuration.image = UIImage(systemName: "scissors")
        configuration.imagePadding = 6
        configuration.baseForegroundColor = UIColor(red: 0.70, green: 0.15, blue: 0.12, alpha: 1)
        configuration.background.backgroundColor = .secondarySystemGroupedBackground
        configuration.background.cornerRadius = 8
        configuration.contentInsets = NSDirectionalEdgeInsets(top: 8, leading: 12, bottom: 8, trailing: 12)
        let button = UIButton(configuration: configuration, primaryAction: UIAction { [weak self] _ in
            self?.onTrimAndRetry?()
        })

        let stack = UIStackView(arrangedSubviews: [heading, body, button])
        stack.axis = .vertical
        stack.spacing = 8
        stack.alignment = .leading
        stack.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
            stack.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 14),
            stack.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -14),
        ])
        return cell
    }

    /// The total, with the bar the design draws under it.
    private func totalCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.selectionStyle = .none
        cell.isAccessibilityElement = false

        let amount = UILabel()
        amount.font = .monospacedDigitSystemFont(ofSize: 13, weight: .semibold)
        amount.text = Self.exact(usage.tokens)

        let percent = UILabel()
        percent.font = .monospacedDigitSystemFont(ofSize: 13, weight: .semibold)
        percent.text = usage.percentText
        percent.textColor = usage.isCritical ? .systemRed : (usage.isLarge ? .systemOrange : .label)

        let head = UIStackView(arrangedSubviews: [amount, UIView(), percent])
        head.axis = .horizontal

        let track = UIView()
        track.backgroundColor = UIColor.tertiarySystemFill
        track.layer.cornerRadius = 3.5
        track.clipsToBounds = true
        track.translatesAutoresizingMaskIntoConstraints = false
        let fill = UIView()
        fill.backgroundColor = usage.isCritical ? .systemRed : (usage.isLarge ? .systemOrange : .tintColor)
        fill.layer.cornerRadius = 3.5
        fill.translatesAutoresizingMaskIntoConstraints = false
        track.addSubview(fill)

        let stack = UIStackView(arrangedSubviews: [head, track])
        stack.axis = .vertical
        stack.spacing = 7
        stack.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
            stack.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 12),
            stack.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -12),
            track.heightAnchor.constraint(equalToConstant: 7),
            fill.widthAnchor.constraint(equalTo: track.widthAnchor, multiplier: max(0.02, usage.fraction)),
            fill.heightAnchor.constraint(equalTo: track.heightAnchor),
        ])
        return cell
    }

    /// One part: its name, a bar of its own so the proportions are visible,
    /// and the count.
    private func partCell(_ part: Part) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.selectionStyle = .none
        cell.isAccessibilityElement = false

        let tokens = part == .history ? usage.byRole.values.reduce(0, +) : part.tokens
        let name = UILabel()
        name.text = part.title
        name.font = .systemFont(ofSize: 13.5, weight: part == .history ? .semibold : .regular)

        let track = UIView()
        track.backgroundColor = UIColor.tertiarySystemFill
        track.layer.cornerRadius = 2.5
        track.clipsToBounds = true
        track.translatesAutoresizingMaskIntoConstraints = false
        let fill = UIView()
        fill.backgroundColor = part == .history
            ? (usage.isCritical ? .systemRed : (usage.isLarge ? .systemOrange : .label))
            : .secondaryLabel
        fill.layer.cornerRadius = 2.5
        fill.translatesAutoresizingMaskIntoConstraints = false
        track.addSubview(fill)

        let amount = UILabel()
        amount.font = .monospacedDigitSystemFont(ofSize: 13, weight: part == .history ? .semibold : .regular)
        amount.textColor = part == .history ? .label : .secondaryLabel
        amount.text = Self.exact(tokens)
        amount.setContentHuggingPriority(.required, for: .horizontal)

        let stack = UIStackView(arrangedSubviews: [name, track, amount])
        stack.axis = .horizontal
        stack.spacing = 10
        stack.alignment = .center
        stack.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
            stack.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 8),
            stack.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -8),
            track.widthAnchor.constraint(equalToConstant: 64),
            track.heightAnchor.constraint(equalToConstant: 5),
            fill.widthAnchor.constraint(equalTo: track.widthAnchor, multiplier: min(1, max(0.01, tokens / usage.window))),
            fill.heightAnchor.constraint(equalTo: track.heightAnchor),
        ])
        return cell
    }

    /// One of the three rows taking the most room: what it is, and how much.
    private func largestCell(_ index: Int) -> UITableViewCell {
        let largest = ChatContextUsage.largest(messages)
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        cell.selectionStyle = .none
        guard largest.indices.contains(index) else { return cell }
        let entry = largest[index]

        var content = cell.defaultContentConfiguration()
        content.text = entry.title
        content.textProperties.font = .systemFont(ofSize: 12, weight: .semibold)
        content.textProperties.color = .label
        content.secondaryText = entry.preview
        content.secondaryTextProperties.font = .systemFont(ofSize: 13)
        content.secondaryTextProperties.color = .secondaryLabel
        content.secondaryTextProperties.numberOfLines = 2
        cell.contentConfiguration = content

        let amount = UILabel()
        amount.font = .monospacedDigitSystemFont(ofSize: 12, weight: .regular)
        amount.textColor = .tertiaryLabel
        amount.text = Self.exact(entry.tokens)
        amount.sizeToFit()
        cell.accessoryView = amount
        return cell
    }

    // MARK: - Tuning

    private func autoCompactCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var content = UIListContentConfiguration.valueCell()
        content.text = String(localized: "Automatic Compaction")
        content.textProperties.font = .systemFont(ofSize: 16)
        content.secondaryText = nil
        cell.contentConfiguration = content
        cell.selectionStyle = .none

        let toggle = UISwitch()
        toggle.isOn = CompactionTuning.autoCompact
        toggle.addAction(UIAction { _ in
            CompactionTuning.setAutoCompact(toggle.isOn)
        }, for: .valueChanged)
        cell.accessoryView = toggle
        return cell
    }

    private func autoTrimCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var content = UIListContentConfiguration.valueCell()
        content.text = String(localized: "Auto Trim")
        content.textProperties.font = .systemFont(ofSize: 16)
        content.secondaryText = nil
        cell.contentConfiguration = content
        cell.selectionStyle = .none

        let toggle = UISwitch()
        toggle.isOn = CompactionTuning.autoTrim
        toggle.addAction(UIAction { _ in
            CompactionTuning.setAutoTrim(toggle.isOn)
        }, for: .valueChanged)
        cell.accessoryView = toggle
        return cell
    }

    private func toolLimitCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var content = UIListContentConfiguration.valueCell()
        content.text = String(localized: "Tool Output Limit")
        content.textProperties.font = .systemFont(ofSize: 16)
        content.secondaryText = Self.limitTitle(CompactionTuning.toolOutputLimit)
        content.secondaryTextProperties.color = .secondaryLabel
        cell.contentConfiguration = content
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    private func readOnlyCell(_ title: String, _ value: String) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var content = UIListContentConfiguration.valueCell()
        content.text = title
        content.textProperties.font = .systemFont(ofSize: 16)
        content.secondaryText = value
        content.secondaryTextProperties.color = .secondaryLabel
        cell.contentConfiguration = content
        cell.selectionStyle = .none
        return cell
    }

    private func noteCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.selectionStyle = .none
        var content = UIListContentConfiguration.cell()
        // said plainly, because a count that is near the limit and an
        // estimate are two different reasons not to trust the number
        content.text = String(localized: "Estimated: the agent adds the system prompt and the tool catalogue after the messages leave here.")
        content.textProperties.color = .secondaryLabel
        content.textProperties.font = .preferredFont(forTextStyle: .footnote)
        content.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 14, leading: 16, bottom: 14, trailing: 16)
        cell.contentConfiguration = content
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard case .toolLimit? = dataSource.value(at: indexPath) else { return }
        let sheet = UIAlertController(
            title: String(localized: "Tool Output Limit"),
            message: String(localized: "A tool result longer than this is replaced by a placeholder when a send would not fit."),
            preferredStyle: .actionSheet,
        )
        for characters in [2_000, 4_000, 8_000, 16_000, 32_000] {
            sheet.addAction(UIAlertAction(title: Self.limitTitle(characters), style: .default) { _ in
                CompactionTuning.setToolOutputLimit(characters)
                self.rebuild()
            })
        }
        sheet.addAction(UIAlertAction(title: String(localized: "Cancel"), style: .cancel))
        sheet.popoverPresentationController?.sourceView = view
        sheet.popoverPresentationController?.sourceRect = CGRect(
            x: view.bounds.midX, y: view.bounds.midY, width: 0, height: 0,
        )
        present(sheet, animated: true)
    }

    // MARK: - Formatting

    private static func limitTitle(_ characters: Int) -> String {
        characters >= 1_000
            ? String(localized: "\(characters / 1_000) KB")
            : String(localized: "\(characters) characters")
    }

    /// `120,801` — the design spells the count out here, because the digits
    /// are the point.
    private static func exact(_ tokens: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 0
        return formatter.string(from: NSNumber(value: tokens.rounded())) ?? "\(Int(tokens))"
    }
}
