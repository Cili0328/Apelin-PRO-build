import ApelinProtocol
import UIKit

final class RelayAccountController: TableController {
    private let provider: AgentProvider
    private let groupID: String?
    private let model: String
    @objc private dynamic var values: [String: String]
    private var configuration: AgentRelayConfiguration
    @objc private dynamic var activeAccountID: String?
    private var balances: [String: ProviderBalance] = [:]
    private var failures = Set<String>()
    @objc private dynamic var loading = false
    @objc private dynamic var statusUnavailable = false
    private var loader: Task<Void, Never>?
    private var statusWatcher: Task<Void, Never>?
    @objc private dynamic var generation = 0

    private enum Row: Hashable {
        case context
        case continuation
        case account(String)
        case current
        case manage
    }

    private struct Content: Equatable {
        let row: Row
        let text: String
        let detail: String
        var account: RelayAccountSummary?
        var balance: String = ""
        var status: String = ""
        var active = false
    }

    private lazy var dataSource = TableDataSource<Int, Row, Content>(
        tableView: tableView, identifier: { $0.row },
    ) { [weak self] _, _, content in
        self?.cell(for: content)
    }

    init(provider: AgentProvider, groupID: String?, model: String, values: [String: String]) throws {
        self.provider = provider
        self.groupID = groupID
        self.model = model
        self.values = values
        configuration = try values["relayConfiguration"].map(AgentRelayConfiguration.decode) ?? .init()
        super.init(style: .plain)
        title = String(localized: "Calling Accounts")
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("Use init(provider:groupID:model:values:)")
    }

    deinit {
        loader?.cancel()
        statusWatcher?.cancel()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.backgroundColor = .clear
        tableView.backgroundView = ChatGlassView(style: .systemMaterial)
        tableView.tintColor = ChatPalette.accent
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 76
        navigationItem.largeTitleDisplayMode = .never
        let refresh = UIBarButtonItem(image: UIImage(systemName: "arrow.clockwise"), primaryAction: UIAction { [weak self] _ in
            self?.load(force: true)
        })
        refresh.accessibilityLabel = String(localized: "Refresh")
        navigationItem.rightBarButtonItem = refresh
        dataSource.headerTitle = { section in
            section == 1 ? String(localized: "Account Priority") : nil
        }
        rebuild()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        load(force: false)
        statusWatcher?.cancel()
        statusWatcher = Task { [weak self] in
            while !Task.isCancelled {
                do {
                    try await Task.sleep(for: .seconds(5))
                    guard let self, !Task.isCancelled else { return }
                    await refreshActiveAccount()
                } catch { return }
            }
        }
    }

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        generation += 1
        loader?.cancel()
        statusWatcher?.cancel()
    }

    private var snapshot: RelayAccountSnapshot {
        .init(configuration: configuration, primaryKey: values["apiKey"] ?? "", groupID: groupID, activeAccountID: activeAccountID)
    }

    @objc private dynamic func load(force: Bool) {
        loader?.cancel()
        generation += 1
        let generation = generation
        loading = true
        failures.removeAll()
        dataSource.beginLoad()
        rebuild()
        loader = Task { [weak self] in
            guard let self else { return }
            do {
                let saved = try await ApelinService.app.agentAPIConfiguration(provider: provider)
                let configuration = try saved.values["relayConfiguration"].map(AgentRelayConfiguration.decode) ?? AgentRelayConfiguration()
                guard !Task.isCancelled, self.generation == generation else { return }
                let configurationChanged = self.configuration != configuration
                    || values["apiKey"] != saved.values["apiKey"] || values["baseUrl"] != saved.values["baseUrl"]
                if configurationChanged {
                    balances.removeAll()
                }
                values = saved.values
                self.configuration = configuration
                await refreshActiveAccount()
                let meta = ProviderMetaStore.meta(for: provider.rawValue)
                for account in snapshot.accounts where account.enabled && meta.balanceEnabled {
                    let identity = balanceIdentity(account.id)
                    guard force || configurationChanged || ProviderBalanceHistory.cachedText(identity) == nil
                        || ProviderBalanceHistory.needsRefresh(identity, every: meta.refreshMinutes) else { continue }
                    guard !Task.isCancelled, self.generation == generation else { return }
                    do {
                        let balance = try await ProviderBalanceLookup.fetch(
                            baseURL: values["baseUrl"] ?? "", apiKey: key(for: account.id), using: meta.balanceProtocol,
                        )
                        guard !Task.isCancelled, self.generation == generation else { return }
                        balances[account.id] = balance
                        ProviderBalanceHistory.cache(balance, for: identity)
                    } catch {
                        guard !Task.isCancelled, self.generation == generation else { return }
                        failures.insert(account.id)
                        balances[account.id] = nil
                    }
                    rebuild()
                }
            } catch {
                guard !Task.isCancelled, self.generation == generation else { return }
                activeAccountID = nil
                statusUnavailable = true
            }
            guard !Task.isCancelled, self.generation == generation else { return }
            loading = false
            rebuild()
        }
    }

    private func refreshActiveAccount() async {
        let generation = generation
        do {
            let response = try await ApelinService.app.agentAPIConfiguration(
                provider: provider, relayGroupID: groupID, useActiveAccount: true,
            )
            guard !Task.isCancelled, self.generation == generation else { return }
            activeAccountID = response.relayAccountID
            statusUnavailable = false
        } catch {
            guard !Task.isCancelled, self.generation == generation else { return }
            activeAccountID = nil
            statusUnavailable = true
        }
        rebuild()
    }

    @objc private dynamic func key(for id: String) -> String {
        id == "primary" ? values["apiKey"] ?? "" : configuration.accounts.first { $0.id == id }?.apiKey ?? ""
    }

    @objc private dynamic func balanceIdentity(_ id: String) -> String {
        ProviderBalanceHistory.identity(providerRawValue: provider.rawValue, baseURL: values["baseUrl"] ?? "", accountID: id)
    }

    @objc private dynamic func rebuild() {
        let snapshot = snapshot
        let count = String(localized: "\(snapshot.accounts.count) Accounts")
        let context = Content(row: .context, text: "\(ProviderLabel.displayName(of: provider)) · \(count)", detail: "\(snapshot.groupName) · \(model)")
        let continuation = Content(
            row: .continuation, text: String(localized: "Automatic Continuation"),
            detail: snapshot.hasStandbyAccount ? String(localized: "Enabled") : String(localized: "No Standby Account"),
        )
        let meta = ProviderMetaStore.meta(for: provider.rawValue)
        let accounts = snapshot.accounts.map { account -> Content in
            let balance = balances[account.id]
            let text: String
            if !meta.balanceEnabled || failures.contains(account.id) {
                text = String(localized: "Balance Unavailable")
            } else if let balance {
                text = ProviderBalanceLookup.displayText(for: balance)
            } else {
                text = ProviderBalanceHistory.cachedText(balanceIdentity(account.id))
                    ?? String(localized: loading && account.enabled ? "Checking Balance…" : "Balance Unavailable")
            }
            let active = account.id == snapshot.activeAccountID
            let status = !account.enabled ? String(localized: "Disabled")
                : active ? String(localized: "In Use")
                : balance.map { !$0.unlimited && $0.remaining <= 0 } == true ? String(localized: "Balance Exhausted")
                : String(localized: "Standby")
            let priority = account.priority.map { String(localized: "Priority \($0)") } ?? String(localized: "Disabled")
            let suffix = String(localized: "Key ending \(account.keySuffix)")
            return Content(row: .account(account.id), text: account.name, detail: "\(priority) · \(suffix)", account: account, balance: text, status: status, active: active)
        }
        let current = snapshot.accounts.first { $0.id == snapshot.activeAccountID }?.name
        let footer = Content(
            row: .current, text: String(localized: "Current Account"),
            detail: statusUnavailable ? String(localized: "Account Status Unavailable") : current ?? String(localized: "Waiting"),
        )
        let manage = Content(row: .manage, text: String(localized: "Accounts & API Groups"), detail: "")
        dataSource.update([(0, [context, continuation]), (1, accounts), (2, [footer, manage])])
    }

    private func cell(for content: Content) -> UITableViewCell {
        if content.account != nil { return accountCell(content) }
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        cell.backgroundColor = .clear
        var labels = UIListContentConfiguration.subtitleCell()
        labels.text = content.text
        labels.secondaryText = content.detail
        labels.textProperties.numberOfLines = 0
        labels.secondaryTextProperties.numberOfLines = 0
        labels.image = UIImage(systemName: content.row == .continuation ? "arrow.triangle.2.circlepath" : content.row == .manage ? "slider.horizontal.3" : "person.crop.circle")
        labels.imageProperties.tintColor = ChatPalette.accent
        cell.contentConfiguration = labels
        cell.selectionStyle = content.row == .manage ? .default : .none
        cell.accessoryType = content.row == .manage ? .disclosureIndicator : .none
        if content.row == .manage { cell.accessibilityTraits.insert(.button) }
        return cell
    }

    private func accountCell(_ content: Content) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.backgroundColor = .clear
        let left = UIStackView(arrangedSubviews: [label(content.text, style: .headline), label(content.detail, style: .caption1, color: .secondaryLabel)])
        left.axis = .vertical
        left.spacing = 5
        let right = UIStackView(arrangedSubviews: [
            label(content.balance, style: .subheadline),
            label(content.status, style: .caption1, color: content.active ? ChatPalette.accent : .secondaryLabel),
        ])
        right.axis = .vertical
        right.spacing = 5
        let accessibleSize = traitCollection.preferredContentSizeCategory.isAccessibilityCategory
        right.alignment = .fill
        for case let label as UILabel in right.arrangedSubviews {
            label.textAlignment = accessibleSize ? .natural : .right
        }
        let stack = UIStackView(arrangedSubviews: [left, right])
        stack.axis = accessibleSize ? .vertical : .horizontal
        stack.alignment = accessibleSize ? .fill : .top
        stack.spacing = 12
        stack.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
            stack.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 18),
            stack.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -18),
        ])
        if !accessibleSize {
            right.widthAnchor.constraint(equalTo: stack.widthAnchor, multiplier: 0.38).isActive = true
        }
        cell.isAccessibilityElement = true
        cell.accessibilityLabel = "\(content.text), \(content.detail)"
        cell.accessibilityValue = "\(content.balance), \(content.status)"
        cell.accessibilityTraits = content.active ? [.button, .selected] : .button
        cell.accessoryType = content.active ? .checkmark : .none
        return cell
    }

    @objc private dynamic func label(_ text: String, style: UIFont.TextStyle, color: UIColor = .label) -> UILabel {
        let label = UILabel()
        label.text = text
        label.font = .preferredFont(forTextStyle: style)
        label.adjustsFontForContentSizeCategory = true
        label.numberOfLines = 0
        label.textColor = color
        return label
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard let content = dataSource.value(at: indexPath) else { return }
        if case let .account(id) = content.row {
            let page = ProviderBalanceScreen(
                name: content.text, baseURL: values["baseUrl"] ?? "", apiKey: key(for: id),
                rawValue: provider.rawValue, meta: ProviderMetaStore.meta(for: provider.rawValue), accountID: id,
            )
            page.loadViewIfNeeded()
            page.tableView.backgroundColor = .clear
            page.tableView.backgroundView = ChatGlassView(style: .systemMaterial)
            navigationController?.pushViewController(page, animated: true)
        } else if content.row == .manage {
            let account = AgentAccount(provider: provider, method: .apiKey, signedIn: true, usesAPIKey: true)
            navigationController?.pushViewController(ProviderLoginController(account: account), animated: true)
        }
    }
}
