import ApelinProtocol
import Foundation

/// How much of a model's window a conversation has taken.
///
/// The count is an estimate, not the tokenizer's: the app never sees the
/// system prompt, the tool catalogue or the provider's own accounting, and
/// asking the agent for them would need a round trip the page cannot wait
/// on. `TokenEstimate` is the same four-characters-to-a-token guess the
/// agent itself counts streamed output with, so a number from here and one
/// from a run are at least measured the same way.
///
/// What it is good for is the shape: a conversation at 12% and one at 88%
/// are visibly different, and that is what decides whether to compact.
struct ChatContextUsage {
    /// Used only before a session has published the resolved SDK model.
    static let defaultWindow: Double = 131_072
    let window: Double

    /// What every request carries whether or not the conversation is long:
    /// the system prompt, the tool catalogue and any memory the agent
    /// injects. None of it is visible from here — the agent assembles it
    /// after the app hands over the messages — so these are the design's own
    /// figures, marked as estimates wherever they are shown.
    static let systemPromptEstimate: Double = 2_140
    static let toolCatalogEstimate: Double = 8_900
    static let memoryEstimate: Double = 1_200

    let tokens: Double
    /// What each kind of row contributes, for the inspector.
    let byRole: [Kind: Double]

    enum Kind: String, CaseIterable, Hashable {
        case prompt
        case reply
        case tool
        case activity
    }

    var fraction: Double {
        min(1, tokens / window)
    }

    var isLarge: Bool { fraction >= 0.75 }
    var isCritical: Bool { fraction >= 0.9 }

    /// `76%` — the number the bar is read with.
    var percentText: String {
        "\(Int((fraction * 100).rounded()))%"
    }

    /// `76% · 98.7k` — what the composer's bar says.
    var meterText: String {
        "\(percentText) · \(Self.abbreviated(tokens))"
    }

    /// Everything that is not a message: the same for every conversation,
    /// so it is a constant of the type rather than of one measurement.
    static var overhead: Double {
        Self.systemPromptEstimate + Self.toolCatalogEstimate + Self.memoryEstimate
    }

    static func measure(
        _ messages: [ChatMessage],
        adding draft: ComposerDraft? = nil,
        window: Double? = nil,
    ) -> ChatContextUsage {
        var byRole: [Kind: Double] = [:]
        var total: Double = 0
        if let compacted = messages.lastIndex(where: { $0.role == .compaction }) {
            let summary = messages[compacted]
            if let effectiveContextTokens = summary.effectiveContextTokens {
                total = effectiveContextTokens
                byRole[.activity] = effectiveContextTokens
                for message in messages.dropFirst(compacted + 1)
                    where message.eventTime.map({ $0 > (summary.eventTime ?? .distantPast) }) ?? true
                {
                    let counted = Self.cost(of: message)
                    guard counted > 0 else { continue }
                    total += counted
                    byRole[Self.kind(of: message.role), default: 0] += counted
                }
            } else {
                // Old markers have no retained-context measurement. Count the
                // visible history conservatively rather than silently discarding
                // recent turns that the model may still carry.
                for message in messages {
                    let counted = Self.cost(of: message)
                    guard counted > 0 else { continue }
                    total += counted
                    byRole[Self.kind(of: message.role), default: 0] += counted
                }
            }
        } else {
            for message in messages {
                let counted = Self.cost(of: message)
                guard counted > 0 else { continue }
                total += counted
                byRole[Self.kind(of: message.role), default: 0] += counted
            }
        }
        if let draft {
            total += TokenEstimate.tokens(in: draft.text)
            total += draft.attachments.reduce(0) { subtotal, attachment in
                subtotal + TokenEstimate.tokens(in: attachment.name)
                    + (attachment.text.map(TokenEstimate.tokens(in:)) ?? 0)
            }
        }
        // the fixed part is what a request carries before the first word of
        // the conversation, so a total that leaves it out reads low by a page
        return ChatContextUsage(
            window: window.flatMap { $0 > 0 ? $0 : nil } ?? Self.defaultWindow,
            tokens: total + Self.overhead,
            byRole: byRole,
        )
    }

    /// The model carries the summary and its recent context, not every row
    /// that remains visible in the transcript. Old compacted rows stay
    /// browseable but do not inflate the next request estimate.
    static func effectiveMessages(_ messages: [ChatMessage]) -> [ChatMessage] {
        guard let index = messages.lastIndex(where: { $0.role == .compaction }) else { return messages }
        return Array(messages[index...])
    }

    /// One model-visible row. Folded thinking text is already in its parent;
    /// tool arguments and results remain model context in the trace.
    static func cost(of message: ChatMessage) -> Double {
        var total = TokenEstimate.tokens(in: message.text)
        switch message.role {
        case .tool:
            total += TokenEstimate.tokens(in: message.detail)
        case .thinking:
            total += message.trace
                .filter { $0.role == .tool }
                .reduce(0) { $0 + TokenEstimate.tokens(in: $1.detail) }
        case .approval:
            break
        case .user, .assistant, .compaction:
            break
        }
        if case .compaction = message.role, let effectiveContextTokens = message.effectiveContextTokens {
            total = max(total, effectiveContextTokens)
        }
        return total
    }

    /// The three rows taking the most room, which is the question a total
    /// cannot answer: a conversation that is one build log wants the log
    /// folded, not the whole history summarised.
    static func largest(_ messages: [ChatMessage], limit: Int = 3) -> [Largest] {
        messages
            .map { Largest(message: $0, tokens: cost(of: $0)) }
            .filter { $0.tokens > 0 }
            .sorted { $0.tokens > $1.tokens }
            .prefix(limit)
            .map { $0 }
    }

    struct Largest {
        let title: String
        let tokens: Double
        let preview: String

        init(message: ChatMessage, tokens: Double) {
            self.tokens = tokens
            if case .tool = message.role, !message.detail.isEmpty {
                title = message.detail
            } else {
                title = Self.roleTitle(message.role)
            }
            let text = message.text.trimmingCharacters(in: .whitespacesAndNewlines)
            preview = text.isEmpty ? message.detail : String(text.prefix(80))
        }

        private static func roleTitle(_ role: ChatMessage.Role) -> String {
            switch role {
            case .user: String(localized: "You")
            case .assistant: String(localized: "Assistant")
            case .tool: String(localized: "Tool")
            case .thinking: String(localized: "Thinking")
            case .approval: String(localized: "Approval")
            case .compaction: String(localized: "Summary")
            }
        }
    }

    private static func kind(of role: ChatMessage.Role) -> Kind {
        switch role {
        case .user: .prompt
        case .assistant: .reply
        case .tool: .tool
        case .thinking, .approval, .compaction: .activity
        }
    }

    /// `18.4k` — a count at the size a reader compares, not reads.
    static func abbreviated(_ tokens: Double) -> String {
        if tokens >= 1000 {
            let thousands = tokens / 1000
            return thousands >= 100
                ? "\(Int(thousands.rounded()))k"
                : String(format: "%.1fk", thousands)
        }
        return "\(Int(tokens.rounded()))"
    }

    var summary: String {
        "\(Self.abbreviated(tokens)) / \(Self.abbreviated(window))"
    }
}
