import UIKit

/// Chat-only colours keep the existing Settings appearance independent.
enum ChatPalette {
    static let background = UIColor(light: UIColor(hex: 0xEDF2F1), dark: UIColor(hex: 0x192122))
    static let accent = UIColor(light: UIColor(hex: 0x287558), dark: UIColor(hex: 0x84CBA7))
    static let edge = UIColor(light: .white.withAlphaComponent(0.85), dark: .white.withAlphaComponent(0.12))
    static let wash = UIColor(light: .white.withAlphaComponent(0.18), dark: .black.withAlphaComponent(0.08))
}

/// A real backdrop on every supported OS, with an opaque accessibility fallback.
class ChatGlassView: UIView {
    private let backdrop = UIVisualEffectView(effect: nil)
    private let style: UIBlurEffect.Style

    init(style: UIBlurEffect.Style = .systemThinMaterial) {
        self.style = style
        super.init(frame: .zero)
        backdrop.isUserInteractionEnabled = false
        backdrop.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(backdrop)
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(refreshMaterial),
            name: UIAccessibility.reduceTransparencyStatusDidChangeNotification,
            object: nil,
        )
        refreshMaterial()
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("Use init(style:)")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        backdrop.frame = bounds
    }

    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        refreshMaterial()
    }

    @objc private dynamic func refreshMaterial() {
        let opaque = UIAccessibility.isReduceTransparencyEnabled
        backdrop.effect = opaque ? nil : UIBlurEffect(style: style)
        backgroundColor = opaque ? ChatPalette.background : .clear
        backdrop.contentView.backgroundColor = opaque ? .clear : ChatPalette.wash
        layer.borderColor = ChatPalette.edge.resolvedColor(with: traitCollection).cgColor
    }
}
