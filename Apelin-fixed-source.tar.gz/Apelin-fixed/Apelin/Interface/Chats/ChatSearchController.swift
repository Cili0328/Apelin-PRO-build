import SnapKit
import Then
import UIKit

/// Looks through the conversation that is open for a line of text.
///
/// A session that has run for hours can only be read back by scrolling it,
/// and the line someone wants is usually far above the newest one. This lists
/// every message whose text holds the query, with the line the hit sits on,
/// and which side said it — the same words read differently as a question and
/// as an answer.
///
/// Only what a person or the model wrote is searched by default: an activity
/// row is a tool call, and a compaction row is the summary's own prose. The
/// chips can widen that to tools, which is where a build log's error text
/// actually lives.
final class ChatSearchController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    private let allMessages: [ChatMessage]
    private var searchableMessages: [ChatMessage] {
        allMessages.flatMap(Self.flatten).filter { !$0.role.isApproval }
    }
    private static func flatten(_ message: ChatMessage) -> [ChatMessage] {
        [message] + message.trace.flatMap(Self.flatten)
    }

    private static func searchText(of message: ChatMessage) -> String {
        if message.role == .tool {
            return message.text + "\n" + ToolCallDetail(detail: message.detail, title: message.text).text
        }
        return message.text
    }

    private var matches: [Match] = []
    private var query = ""
    private var filter: Filter = .all
    private var current = 0

    /// Opens the conversation at this message, if the reader picks one.
    var onOpen: ((UUID) -> Void)?

    private let table = UITableView(frame: .zero, style: .insetGrouped)
    private let field = UITextField()
    private let count = UILabel()
    private let chips = UIStackView()
    private let emptyLabel = UILabel()
    private var chipsHeader: UIView?
    private var previousItem: UIBarButtonItem?
    private var nextItem: UIBarButtonItem?

    private enum Filter: Int, CaseIterable {
        case all, mine, assistant, tool

        var title: String {
            switch self {
            case .all: String(localized: "All")
            case .mine: String(localized: "Me")
            case .assistant: String(localized: "Assistant")
            case .tool: String(localized: "Tools")
            }
        }
    }

    private struct Match {
        let message: ChatMessage
        /// Where it sits in the conversation, counting from the top — the
        /// design's "第 N 条", which is what a person scrolls by.
        let position: Int
        let excerpt: NSAttributedString
    }

    init(messages: [ChatMessage]) {
        allMessages = messages
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("Use init(messages:)")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGroupedBackground
        installSearchField()
        installTable()
        installChips()
        updateMatches(keepingCurrent: false)
    }

    /// A table header is laid out by frame: width 0 at `viewDidLoad` would
    /// squeeze the chips to nothing, so it follows the table once it has one.
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        guard let header = chipsHeader, table.bounds.width > 0 else { return }
        if abs(header.frame.width - table.bounds.width) > 0.5 {
            header.frame.size.width = table.bounds.width
            table.tableHeaderView = header
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // The page exists to take a query; a reader who opened it and has to
        // tap the field first is one tap from closing it again instead.
        field.becomeFirstResponder()
    }

    // MARK: - Chrome

    /// The design puts the field in the navigation bar, with the count at the
    /// end of it: typing and finding out how many is one gesture.
    private func installSearchField() {
        let container = UIView()

        let icon = UIImageView(image: UIImage(systemName: "magnifyingglass"))
        icon.tintColor = .secondaryLabel
        icon.setContentHuggingPriority(.required, for: .horizontal)

        field.placeholder = String(localized: "Search")
        field.font = .systemFont(ofSize: 16)
        field.autocapitalizationType = .none
        field.autocorrectionType = .no
        field.spellCheckingType = .no
        field.clearButtonMode = .whileEditing
        field.returnKeyType = .search
        field.accessibilityLabel = String(localized: "Search")
        field.addAction(UIAction { [weak self] _ in
            guard let self else { return }
            query = field.text ?? ""
            updateMatches(keepingCurrent: false)
        }, for: .editingChanged)
        field.addAction(UIAction { [weak self] _ in self?.advance(by: 1) }, for: .editingDidEndOnExit)

        count.font = .monospacedDigitSystemFont(ofSize: 13, weight: .regular)
        count.textColor = .secondaryLabel
        count.setContentHuggingPriority(.required, for: .horizontal)

        let row = UIStackView(arrangedSubviews: [icon, field, count])
        row.axis = .horizontal
        row.spacing = 6
        row.alignment = .center
        row.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(row)
        NSLayoutConstraint.activate([
            row.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            row.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            row.topAnchor.constraint(equalTo: container.topAnchor),
            row.bottomAnchor.constraint(equalTo: container.bottomAnchor),
            container.widthAnchor.constraint(equalToConstant: 280),
            container.heightAnchor.constraint(equalToConstant: 36),
        ])
        navigationItem.titleView = container

        previousItem = UIBarButtonItem(
            image: UIImage(systemName: "chevron.up"),
            primaryAction: UIAction { [weak self] _ in self?.advance(by: -1) },
        )
        nextItem = UIBarButtonItem(
            image: UIImage(systemName: "chevron.down"),
            primaryAction: UIAction { [weak self] _ in self?.advance(by: 1) },
        )
        previousItem?.accessibilityLabel = String(localized: "Previous")
        nextItem?.accessibilityLabel = String(localized: "Next")
        navigationItem.rightBarButtonItems = [nextItem, previousItem].compactMap { $0 }
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            title: String(localized: "Cancel"),
            primaryAction: UIAction { [weak self] _ in self?.dismiss(animated: true) },
        )
    }

    private func installTable() {
        table.dataSource = self
        table.delegate = self
        table.rowHeight = UITableView.automaticDimension
        table.estimatedRowHeight = 68
        table.keyboardDismissMode = .interactive
        table.register(ChatSearchResultCell.self, forCellReuseIdentifier: ChatSearchResultCell.reuseIdentifier)
        view.addSubview(table)
        table.snp.makeConstraints { make in
            make.edges.equalTo(view)
        }

        emptyLabel.text = String(localized: "No Results")
        emptyLabel.font = .preferredFont(forTextStyle: .body)
        emptyLabel.textColor = .secondaryLabel
        emptyLabel.textAlignment = .center
        emptyLabel.numberOfLines = 0
        emptyLabel.isHidden = true
        // the table's own background rather than a subview of it: a label
        // added to a table view scrolls with the rows
        table.backgroundView = emptyLabel
    }

    /// The chips the design puts above the results: one per kind of row, each
    /// with how many of them the query hits.
    private func installChips() {
        chips.axis = .horizontal
        chips.spacing = 7
        chips.translatesAutoresizingMaskIntoConstraints = false
        // a table header is laid out by frame, so it is given one: the chips
        // inside it still use constraints against its edges
        let header = UIView(frame: CGRect(x: 0, y: 0, width: view.bounds.width > 0 ? view.bounds.width : 360, height: 46))
        header.addSubview(chips)
        NSLayoutConstraint.activate([
            chips.leadingAnchor.constraint(equalTo: header.leadingAnchor, constant: 16),
            chips.trailingAnchor.constraint(lessThanOrEqualTo: header.trailingAnchor, constant: -16),
            chips.topAnchor.constraint(equalTo: header.topAnchor, constant: 10),
            chips.bottomAnchor.constraint(equalTo: header.bottomAnchor, constant: -4),
        ])
        table.tableHeaderView = header
        self.chipsHeader = header
        rebuildChips()
    }

    private func rebuildChips() {
        chips.arrangedSubviews.forEach { $0.removeFromSuperview() }
        let counts = countsByFilter()
        for filter in Filter.allCases {
            let chip = UIButton(type: .system)
            var configuration = UIButton.Configuration.plain()
            var title = AttributedString("\(filter.title) \(counts[filter, default: 0])")
            title.font = .systemFont(ofSize: 13, weight: filter == self.filter ? .semibold : .regular)
            configuration.attributedTitle = title
            configuration.contentInsets = NSDirectionalEdgeInsets(top: 5, leading: 12, bottom: 5, trailing: 12)
            configuration.background.cornerRadius = 999
            configuration.baseForegroundColor = filter == self.filter ? .white : .label
            configuration.background.backgroundColor = filter == self.filter
                ? .label
                : UIColor.secondarySystemFill
            chip.configuration = configuration
            chip.addAction(UIAction { [weak self] _ in
                guard let self else { return }
                self.filter = filter
                rebuildChips()
                updateMatches(keepingCurrent: false)
            }, for: .touchUpInside)
            chips.addArrangedSubview(chip)
        }
    }

    // MARK: - Searching

    private func countsByFilter() -> [Filter: Int] {
        var counts: [Filter: Int] = [:]
        let found = search(query)
        counts[.all] = found.count
        counts[.mine] = found.filter { $0.role == .user }.count
        counts[.assistant] = found.filter { $0.role == .assistant }.count
        counts[.tool] = found.filter { $0.role == .tool }.count
        return counts
    }

    private func search(_ text: String) -> [ChatMessage] {
        guard !text.isEmpty else { return [] }
        return searchableMessages.filter { message in
            Self.searchText(of: message).range(of: text, options: [.caseInsensitive, .diacriticInsensitive]) != nil
        }
    }

    private func updateMatches(keepingCurrent: Bool) {
        let previous = keepingCurrent && matches.indices.contains(current) ? matches[current].message.id : nil
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            matches = []
            count.text = ""
            emptyLabel.isHidden = true
            table.reloadData()
            updateArrows()
            return
        }
        let found = search(trimmed).filter { message in
            switch filter {
            case .all: true
            case .mine: message.role == .user
            case .assistant: message.role == .assistant
            case .tool: message.role == .tool
            }
        }
        matches = found.compactMap { message in
            let text = Self.searchText(of: message)
            guard let range = text.range(
                of: trimmed,
                options: [.caseInsensitive, .diacriticInsensitive],
            ) else { return nil }
            let position = (allMessages.firstIndex { row in
                Self.flatten(row).contains(where: { $0.id == message.id })
            } ?? 0) + 1
            return Match(
                message: message,
                position: position,
                excerpt: Self.excerpt(of: text, around: range, marking: trimmed),
            )
        }
        current = previous.flatMap { id in matches.firstIndex { $0.message.id == id } } ?? 0
        count.text = matches.isEmpty ? "" : "\(current + 1)/\(matches.count)"
        emptyLabel.isHidden = !matches.isEmpty
        table.reloadData()
        updateArrows()
    }

    private func updateArrows() {
        let enabled = matches.count > 1
        previousItem?.isEnabled = enabled
        nextItem?.isEnabled = enabled
    }

    /// Walks the hits without leaving the page. Wrapping is what a person
    /// pressing down at the last one expects.
    private func advance(by step: Int) {
        guard !matches.isEmpty else { return }
        current = (current + step + matches.count) % matches.count
        count.text = "\(current + 1)/\(matches.count)"
        let indexPath = IndexPath(row: current, section: 0)
        table.scrollToRow(at: indexPath, at: .middle, animated: true)
        table.selectRow(at: indexPath, animated: true, scrollPosition: .none)
        table.deselectRow(at: indexPath, animated: true)
    }

    /// The words around `range`, at most `limit` characters to each side, on
    /// one line, with an ellipsis where it was cut and the query marked in it.
    @MainActor
    private static func excerpt(
        of text: String,
        around range: Range<String.Index>,
        marking query: String,
        limit: Int = 90,
    ) -> NSAttributedString {
        let lower = text.index(range.lowerBound, offsetBy: -limit, limitedBy: text.startIndex)
            ?? text.startIndex
        let upper = text.index(range.upperBound, offsetBy: limit, limitedBy: text.endIndex)
            ?? text.endIndex
        var piece = String(text[lower ..< upper])
            .replacingOccurrences(of: "\n", with: " ")
            .replacingOccurrences(of: "\t", with: " ")
        while piece.contains("  ") {
            piece = piece.replacingOccurrences(of: "  ", with: " ")
        }
        piece = piece.trimmingCharacters(in: .whitespaces)
        if lower > text.startIndex { piece = "…" + piece }
        if upper < text.endIndex { piece += "…" }
        return marked(piece, query: query)
    }

    /// `piece` with every occurrence of `query` picked out.
    @MainActor
    private static func marked(_ piece: String, query: String) -> NSAttributedString {
        let attributed = NSMutableAttributedString(string: piece)
        guard !query.isEmpty else { return attributed }
        var remaining = piece.startIndex ..< piece.endIndex
        while let found = piece.range(
            of: query,
            options: [.caseInsensitive, .diacriticInsensitive],
            range: remaining,
        ) {
            attributed.addAttributes(
                [
                    .backgroundColor: UIColor.systemYellow.withAlphaComponent(0.55),
                    .foregroundColor: UIColor.label,
                ],
                range: NSRange(found, in: piece),
            )
            remaining = found.upperBound ..< piece.endIndex
        }
        return attributed
    }

    // MARK: - Listing

    func tableView(_: UITableView, numberOfRowsInSection _: Int) -> Int {
        matches.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(
            withIdentifier: ChatSearchResultCell.reuseIdentifier,
            for: indexPath,
        )
        guard let cell = cell as? ChatSearchResultCell else { return cell }
        let match = matches[indexPath.row]
        cell.show(
            who: Self.who(for: match.message),
            position: match.position,
            excerpt: match.excerpt,
        )
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard matches.indices.contains(indexPath.row) else { return }
        let id = matches[indexPath.row].message.id
        let onOpen = onOpen
        dismiss(animated: true) { onOpen?(id) }
    }

    private static func who(for message: ChatMessage) -> String {
        switch message.role {
        case .user: String(localized: "You")
        case .assistant: String(localized: "Assistant")
        case .tool: String(localized: "Tool")
        default: String(localized: "Assistant")
        }
    }
}

/// One hit: who said it, where it sits, and the line with the query in it.
final class ChatSearchResultCell: UITableViewCell {
    static let reuseIdentifier = "ChatSearchResultCell"

    private let who = UILabel()
    private let position = UILabel()
    private let excerpt = UILabel()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .default

        who.font = .systemFont(ofSize: 11.5, weight: .semibold)
        who.setContentHuggingPriority(.required, for: .horizontal)

        position.font = .systemFont(ofSize: 11.5)
        position.textColor = .tertiaryLabel
        position.textAlignment = .right
        position.setContentHuggingPriority(.required, for: .horizontal)

        excerpt.font = .systemFont(ofSize: 13.5)
        excerpt.textColor = .secondaryLabel
        excerpt.numberOfLines = 3

        let meta = UIStackView(arrangedSubviews: [who, UIView(), position])
        meta.axis = .horizontal
        meta.alignment = .center

        let stack = UIStackView(arrangedSubviews: [meta, excerpt])
        stack.axis = .vertical
        stack.spacing = 5
        stack.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.trailingAnchor),
            stack.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 12),
            stack.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -12),
        ])
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    func show(who name: String, position index: Int, excerpt text: NSAttributedString) {
        who.text = name
        position.text = String(localized: "Message \(index)")
        excerpt.attributedText = text
    }
}

/// One message, whole, as a page that can be read and copied.
final class ChatSearchTextController: UIViewController {
    private let text: String
    private let textView = UITextView()

    init(text: String) {
        self.text = text
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("Use init(text:)")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = String(localized: "Contents")
        view.backgroundColor = .systemGroupedBackground

        textView.text = text
        textView.font = .preferredFont(forTextStyle: .body)
        textView.adjustsFontForContentSizeCategory = true
        textView.isEditable = false
        textView.alwaysBounceVertical = true
        textView.backgroundColor = .clear
        textView.textContainerInset = UIEdgeInsets(top: 8, left: 0, bottom: 24, right: 0)
        view.addSubview(textView)
        textView.snp.makeConstraints { make in
            make.edges.equalTo(view.safeAreaLayoutGuide).inset(16)
        }

        navigationItem.rightBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "doc.on.doc"),
            primaryAction: UIAction { [weak self] _ in
                guard let self else { return }
                UIPasteboard.general.string = text
            },
        ).then { $0.accessibilityLabel = String(localized: "Copy") }
    }
}
