import UIKit

final class ChatModelHeader: ChatGlassView {
    let modelButton = UIButton(type: .system)
    let balanceButton = UIButton(type: .system)
    private let divider = UIView()

    init() {
        super.init(style: .systemThinMaterial)
        tintColor = ChatPalette.accent
        var model = UIButton.Configuration.plain()
        model.image = UIImage(systemName: "cpu")
        model.imagePadding = 10
        model.titleAlignment = .leading
        model.titleLineBreakMode = .byTruncatingMiddle
        model.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 12, bottom: 10, trailing: 4)
        model.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { attributes in
            var attributes = attributes
            attributes.font = UIFont.preferredFont(forTextStyle: .subheadline)
            return attributes
        }
        model.subtitleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { attributes in
            var attributes = attributes
            attributes.font = UIFont.preferredFont(forTextStyle: .caption2)
            attributes.foregroundColor = UIColor.secondaryLabel
            return attributes
        }
        modelButton.configuration = model
        modelButton.contentHorizontalAlignment = .leading
        modelButton.titleLabel?.lineBreakMode = .byTruncatingMiddle
        modelButton.accessibilityLabel = String(localized: "Select Model")

        var balance = UIButton.Configuration.plain()
        balance.image = UIImage(systemName: "creditcard")
        balance.imagePadding = 5
        balance.titleLineBreakMode = .byTruncatingTail
        balance.contentInsets = NSDirectionalEdgeInsets(top: 12, leading: 4, bottom: 12, trailing: 12)
        balance.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer { attributes in
            var attributes = attributes
            attributes.font = UIFont.preferredFont(forTextStyle: .caption1)
            return attributes
        }
        balanceButton.configuration = balance
        balanceButton.accessibilityLabel = String(localized: "Balance")

        let stack = UIStackView(arrangedSubviews: [modelButton, balanceButton])
        stack.alignment = .center
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)
        modelButton.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        balanceButton.setContentCompressionResistancePriority(.defaultHigh, for: .horizontal)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: safeAreaLayoutGuide.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: safeAreaLayoutGuide.trailingAnchor),
            stack.topAnchor.constraint(equalTo: topAnchor),
            stack.bottomAnchor.constraint(equalTo: bottomAnchor),
            balanceButton.widthAnchor.constraint(lessThanOrEqualTo: stack.widthAnchor, multiplier: 0.4),
            modelButton.heightAnchor.constraint(greaterThanOrEqualToConstant: 56),
        ])
        divider.backgroundColor = ChatPalette.edge
        addSubview(divider)
        show(model: nil, provider: nil)
        showBalance(String(localized: "Balance Unavailable"))
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("Use init()")
    }

    @objc dynamic func show(model: String?, provider: String?) {
        modelButton.configuration?.title = model ?? String(localized: "Select Model")
        modelButton.configuration?.subtitle = provider
        modelButton.accessibilityValue = [model, provider].compactMap(\.self).joined(separator: ", ")
    }

    @objc dynamic func showBalance(_ text: String) {
        balanceButton.configuration?.title = text
        balanceButton.accessibilityValue = text
    }

    @objc override dynamic func layoutSubviews() {
        super.layoutSubviews()
        divider.frame = CGRect(x: 0, y: bounds.height - 1, width: bounds.width, height: 1)
    }
}
