// Lakr233's Inhouse Code, from FlowDown.
// I CAN DO WHAT THE FUCK I WANT.

import Foundation

/// What a conversation has typed and attached but not sent; saved with its ChatRecord.
struct ComposerDraft: Codable, Sendable {
    var id = UUID()
    var text = ""
    var attachments: [ComposerAttachment] = []
    var submittedAt: Date? = nil
}

struct ComposerAttachment: Identifiable, Hashable, Codable, Sendable {
    var id = UUID()
    var name: String
    let data: Data
    var text: String?
    var isImage = false

    // An ID identifies one immutable byte snapshot. Transcript diffs must not
    // hash an entire large archive every time another text delta arrives.
    static func == (lhs: Self, rhs: Self) -> Bool {
        lhs.id == rhs.id && lhs.name == rhs.name && lhs.text == rhs.text && lhs.isImage == rhs.isImage
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
        hasher.combine(name)
        hasher.combine(text)
        hasher.combine(isImage)
    }
}
