import ApelinProtocol
import ListViewKit
import SnapKit
import SPIndicator
import UIKit

/// The conversation page, the detail column's root while one is picked.
/// There is one, made once: picking another conversation hands it that
/// conversation (`use(_:)`), which rolls the title on the bar to the new
/// name, replaces the message list and restores that conversation’s draft.
/// Each conversation gets a fresh list and its own scrolling state.
///
/// The messages fill the page across its safe area; the composer sits at
/// its foot, on the keyboard when it is up, no wider than 750 pt and centred
/// in the safe area, and the list scrolls clear of it. Each side keeps its
/// own inset: a vertical bar (iPhone Duo) takes one side and not the other.
final class ChatController: UIViewController {
    /// The conversation shown, nil until the first is picked.
    private(set) var chat: ChatSummary?

    var runtime: ChatRuntime!
    /// Delete Conversation… in the `…` menu: the sidebar asks and deletes,
    /// as its own Delete does.
    @objc dynamic var onDelete: ((UUID) -> Void)?
    private let titleView = ChatTitleView()
    private var messageList = ListView<ChatMessage>()
    private let composer = ComposerView()
    /// Measures the region covered by the composer without hiding its backdrop.
    private let composerBackground = UIView()
    private let topBlur = ChatTopBlurView()
    private let modelHeader = ChatModelHeader()
    private let latestMessageButton = UIButton(type: .system)
    /// How full the window is, under the navigation bar. It sits above the
    /// list rather than in it, so following a reply does not move it.
    private let contextBar = ContextMeterView()
    @objc private dynamic weak var tracePage: TraceController?
    /// Builds the rows again once a running turn has gone quiet.
    private let quietWatch = ChatQuietWatch()

    /// The shown conversation's rows as last applied.
    private var messages: [ChatMessage] = []
    /// The message the shown conversation's latest turn started with; a
    /// different one starts a new turn.
    @objc private dynamic var turnMessage: UUID?
    /// The turn whose output the list follows (`TurnFollowing`): nil once
    /// a fast reply has brought its message to the top of the visible area,
    /// or the reader dragged, until the next turn.
    @objc private dynamic var followedTurn: UUID?
    /// How fast the followed turn's reply streams.
    private var turnPace = TurnFollowing.Pace()
    /// The request the composer shows in place of the input, and the
    /// conversation its Stop stops. Each change to either lays the whole
    /// window out on the composer's spring, so the composer is told only of
    /// a change, never again on every streamed batch.
    private var shownApproval: ChatMessage?
    /// A root request whose owner check is on screen: a second tap on
    /// Approve does not ask again.
    @objc private dynamic var checkingOwner: UUID?
    @objc private dynamic var stoppableChat: UUID?
    /// While `use(_:)` swaps another conversation in: nothing animates, and
    /// the list's opening scroll waits for its rows.
    @objc private dynamic var isSwitchingChat = false
    /// The keyboard waits for the page to be on screen (`beginTyping`).
    @objc private dynamic var typesOnAppear = false
    /// Conversations whose queued messages went back to the composer, said
    /// once the reader sees them (`sayUnsent`).
    private var unsent: [UUID: (messages: Int, attachmentsLeftOut: Int)] = [:]
    @objc private dynamic var needsInitialScroll = false
    private var pendingSearchMessageID: ChatMessage.ID?
    /// Whether the reader was at the latest message when the page last
    /// changed width — the sidebar opening or closing. The rows wrap again
    /// and the content's height changes under the list, so the list is put
    /// back at its end, and kept there as the rows above are measured again,
    /// until the reader drags it.
    @objc private dynamic var holdsLatestMessage = false
    /// Where a reader elsewhere in the conversation was when the page last
    /// changed width: the row at the top of what they saw, under the bar,
    /// and how far into it. The rows wrap again, and a long reply grows or
    /// shrinks around the line the reader was on, so the list is put back
    /// at the same point in that row rather than at the same offset.
    private var readingPlace: (row: ChatMessage.ID, fraction: CGFloat)?
    @objc private dynamic var lastLayoutWidth: CGFloat = 0
    private var modelLoader: Task<Void, Never>?
    private var balanceLoader: Task<Void, Never>?
    private var balanceGeneration = 0
    private var composerBalanceLoader: Task<Void, Never>?
    private var balanceDetailLoader: Task<Void, Never>?
    private var composerBalanceGeneration = 0
    @objc private dynamic var composerBalanceProvider: String?
    private var selectionCheck: Task<Void, Never>?
    private struct PendingContextSubmission {
        var chatID: UUID
        var draft: ComposerDraft
        var completion: @MainActor () -> Void
        var ownsComposer: Bool
    }

    private var pendingContextSubmissions: [UUID: PendingContextSubmission] = [:]
    private var contextSubmissionOrder: [UUID] = []
    private var contextSubmissionChat: [UUID: UUID] = [:]
    private var contextSubmissionInFlight: UUID?
    private var contextCompactionTasks: [UUID: Task<Void, Never>] = [:]
    private var activeContextDecision: UUID?
    private var contextSubmissionsSuspended = false
    private var deferredContextProcessing = false
    private var restoringContextDraftFor: UUID?
    private weak var contextDecisionAlert: UIAlertController?

    deinit {
        balanceLoader?.cancel()
        composerBalanceLoader?.cancel()
        balanceDetailLoader?.cancel()
        modelLoader?.cancel()
    }

    @objc private dynamic var attachmentImport: ComposerAttachmentImport?
    @objc private dynamic var modelButton: UIButton {
        modelHeader.modelButton
    }

    @objc private dynamic var attachmentHeightLimit: CGFloat {
        (view.window?.bounds.height ?? view.bounds.height) * 0.3
    }

    /// The scale a message row measures and lays out its images at.
    @objc private dynamic var displayScale: CGFloat {
        (view.window ?? view).traitCollection.displayScale
    }

    init() {
        super.init(nibName: nil, bundle: nil)
        navigationItem.titleView = titleView
        navigationItem.largeTitleDisplayMode = .never
        let more = UIBarButtonItem(image: UIImage(systemName: "ellipsis"), menu: nil)
        more.menu = UIMenu(children: [UIDeferredMenuElement.uncached { [weak self, weak more] completion in
            guard let self, let more, let chat else { completion([]); return }
            ChatActions.menu(
                for: chat,
                runtime: runtime,
                from: self,
                anchor: more,
                onPrepareDistribution: { [weak self] prompt in self?.sendPrompt(prompt) },
                onDelete: { [weak self] id in self?.onDelete?(id) },
                completion: { [weak self] items in
                    // Search comes first: a conversation long enough to need
                    // this menu's other entries is one long enough to search.
                    guard let self else { completion(items); return }
                    var all: [UIMenuElement] = [
                        UIAction(
                            title: String(localized: "Search"),
                            image: UIImage(systemName: "magnifyingglass"),
                        ) { [weak self] _ in self?.searchConversation() },
                        UIAction(
                            title: String(localized: "Context"),
                            image: UIImage(systemName: "gauge"),
                        ) { [weak self] _ in self?.showContext() },
                    ]
                    all.append(contentsOf: items)
                    completion(all)
                },
            )
        }])
        more.accessibilityLabel = String(localized: "More")
        // the design puts the magnifier in the bar next to `…`: a conversation
        // long enough to want the menu is one long enough to search
        let magnifier = UIBarButtonItem(
            image: UIImage(systemName: "magnifyingglass"),
            primaryAction: UIAction { [weak self] _ in self?.searchConversation() },
        )
        magnifier.accessibilityLabel = String(localized: "Search")
        navigationItem.rightBarButtonItems = [magnifier, more]
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("Use init()")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ChatPalette.background
        view.tintColor = ChatPalette.accent

        replaceMessageList()
        view.addSubview(topBlur)
        view.addSubview(modelHeader)
        modelHeader.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(view.safeAreaLayoutGuide)
        }
        modelHeader.balanceButton.addAction(UIAction { [weak self] _ in self?.showCallingAccounts() }, for: .touchUpInside)
        composerBackground.backgroundColor = .clear
        composerBackground.isUserInteractionEnabled = false
        view.addSubview(composerBackground)

        composer.delegate = self
        composer.modelBar.setModelControlVisible(false)
        composer.approvalSection.onDecision = { [weak self] request, decision in
            guard let self, let chat else { return }
            Task { await self.decide(request, decision, in: chat.id) }
        }
        composer.modelBar.onEffortChanged = { ComposerModelPreferences.effort = $0 }
        composer.modelBar.onTierChanged = { ComposerModelPreferences.tier = $0 }
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(updateModelSelection),
            name: .composerModelSelectionChanged,
            object: nil,
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(enabledModelsChanged),
            name: .enabledModelsChanged,
            object: nil,
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(withdrawNotifications),
            name: UIApplication.didBecomeActiveNotification,
            object: nil,
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(sayUnsent),
            name: UIApplication.didBecomeActiveNotification,
            object: nil,
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(refreshComposerBalance),
            name: UIApplication.didBecomeActiveNotification,
            object: nil,
        )
        updateModelSelection()
        modelButton.addAction(UIAction { [weak self] _ in self?.showModelPicker() }, for: .touchUpInside)
        view.addSubview(composer)
        composer.snp.makeConstraints { make in
            if #available(iOS 17.0, *) {
                // Above a keyboard, the gap the bands keep between
                // themselves; without one, the safe area's own edge.
                view.keyboardLayoutGuide.usesBottomSafeArea = false
                make.bottom.lessThanOrEqualTo(view.keyboardLayoutGuide.snp.top).offset(-composer.spacing)
                make.bottom.lessThanOrEqualTo(view.safeAreaLayoutGuide)
                make.bottom.equalTo(view.safeAreaLayoutGuide).priority(.high)
            } else {
                make.bottom.equalTo(view.keyboardLayoutGuide.snp.top)
            }
            // Centred in the safe area, not on the page: a vertical bar
            // insets one side only, and centring on the page would take the
            // same width off the other side as well.
            make.centerX.equalTo(view.safeAreaLayoutGuide)
            make.width.lessThanOrEqualTo(750)
            make.leading.greaterThanOrEqualTo(view.safeAreaLayoutGuide)
            make.trailing.lessThanOrEqualTo(view.safeAreaLayoutGuide)
            make.width.equalTo(view.safeAreaLayoutGuide).priority(.low)
        }
        composerBackground.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview()
            // past the bottom, for the keyboard's bounce
            make.bottom.equalToSuperview().offset(128)
            make.top.equalTo(composer.snp.top).offset(-4)
        }

        var latestConfiguration: UIButton.Configuration
        if #available(iOS 26, *) {
            latestConfiguration = .glass()
        } else {
            latestConfiguration = .plain()
            latestConfiguration.background.customView = UIVisualEffectView(
                effect: UIBlurEffect(style: .systemMaterial),
            )
        }
        latestConfiguration.image = UIImage(systemName: "chevron.down")
        latestConfiguration.preferredSymbolConfigurationForImage = UIImage.SymbolConfiguration(
            pointSize: 17,
            weight: .semibold,
        )
        latestConfiguration.baseForegroundColor = .label
        latestConfiguration.cornerStyle = .capsule
        latestMessageButton.configuration = latestConfiguration
        latestMessageButton.accessibilityLabel = String(localized: "Scroll to latest message")
        latestMessageButton.isHidden = true
        latestMessageButton.alpha = 0
        latestMessageButton.addAction(UIAction { [weak self] _ in
            self?.revealLatestMessage()
        }, for: .touchUpInside)
        view.addSubview(latestMessageButton)
        latestMessageButton.snp.makeConstraints { make in
            make.centerX.equalTo(view.safeAreaLayoutGuide)
            make.bottom.equalTo(composerBackground.snp.top).offset(-8)
            make.size.equalTo(44)
        }
        // last: the meter is pinned to the composer's top edge, and a
        // constraint between two views with no common ancestor throws when it
        // is activated. Before this point the composer has no superview.
        installContextBar()
    }

    /// The open conversation, looked through by text.
    private func searchConversation() {
        let page = ChatSearchController(messages: messages)
        page.onOpen = { [weak self] id in self?.revealSearchResult(id) }
        presentPageAsFormSheet(page)
    }

    private func revealSearchResult(_ id: ChatMessage.ID) {
        func find(_ message: ChatMessage) -> ChatMessage? {
            if message.id == id {
                return message
            }
            return message.trace.lazy.compactMap { find($0) }.first
        }
        guard let row = messageList.content.first(where: { find($0) != nil }),
              let hit = find(row) else { return }
        if hit.role.isActivity {
            let page = TraceStepController(step: hit, title: hit.role == .tool ? String(localized: "Tool") : String(localized: "Thinking"))
            presentPageAsFormSheet(page)
        }
        pendingSearchMessageID = row.id
        needsInitialScroll = false
        holdsLatestMessage = false
        readingPlace = nil
        followedTurn = nil
        view.setNeedsLayout()
        DispatchQueue.main.async { [weak self] in self?.scrollToSearchResultIfReady() }
    }

    private func scrollToSearchResultIfReady() {
        guard let id = pendingSearchMessageID else { return }
        messageList.layoutIfNeeded()
        let frame = messageList.rectForRow(with: id)
        guard frame.height > 0, messageList.bounds.height > 0 else { return }
        pendingSearchMessageID = nil
        let topInset = max(messageList.adjustedContentInset.top, topBlur.frame.maxY)
        let target = min(
            max(frame.minY - topInset - 8, messageList.minimumContentOffset.y),
            messageList.maximumContentOffset.y,
        )
        messageList.setContentOffset(
            CGPoint(x: messageList.contentOffset.x, y: target),
            animated: !UIAccessibility.isReduceMotionEnabled,
        )
    }

    /// What the conversation is made of, by size, and what to do about it.
    ///
    /// The failure card is shown only while the conversation is actually near
    /// the limit: an error from a compaction three hours ago is history, and
    /// offering to trim for it would be advice about a problem that is gone.
    private func showContext() {
        let usage = ChatContextUsage.measure(messages, window: chat.map { runtime.transcript($0.id).contextWindow } ?? nil)
        let failure = messages.last { $0.failure != nil }?.text
        let page = ChatContextController(
            usage: usage,
            messages: messages,
            messageCount: messages.count,
            failure: usage.isLarge ? failure : nil,
        )
        page.onTrimAndRetry = { [weak self] in
            guard let self, let chat else { return }
            // a manual compaction runs the same retreat: kwwk's planner still
            // pins the cut, and the session folds the tool output before it
            // gives up
            Task { _ = try? await self.runtime.compact(chat.id) }
        }
        presentPageAsFormSheet(page)
    }

    @objc private dynamic func replaceMessageList() {
        let contentInset = messageList.contentInset
        let indicatorInset = messageList.verticalScrollIndicatorInsets
        messageList.delegate = nil
        messageList.layer.mask = nil
        messageList.removeFromSuperview()
        messageList = ListView<ChatMessage>()
        messageList.frame = messageListFrame
        messageList.contentInset = contentInset
        messageList.verticalScrollIndicatorInsets = indicatorInset
        messageList.backgroundColor = .clear
        messageList.keyboardDismissMode = .interactive
        messageList.delegate = self
        messageList.rows {
            ListRow(ChatActivityRow.self)
                .when { $0.role.isActivity }
                .height { message, context in ChatActivityRow.height(for: message, width: context.width) }
                .configure { [weak self] row, message, _ in
                    row.show(message)
                    row.onToggle = { [weak self] in
                        guard let self else { return }
                        if case .thinking = message.role {
                            let page = TraceController(message: message)
                            tracePage = page
                            presentPageAsFormSheet(page)
                        }
                    }
                }
            ListRow(ChatCompactionRow.self)
                .when { $0.role == .compaction }
                .height { message, context in ChatCompactionRow.height(for: message, width: context.width) }
                .configure { [weak self] row, message, _ in
                    row.show(message)
                    row.onOpen = { [weak self] in
                        self?.presentPageAsFormSheet(ChatCompactionController(summary: message.text))
                    }
                }
            ListRow(ChatFailureRow.self)
                .when { $0.failure != nil }
                .height { message, context in ChatFailureRow.height(for: message, width: context.width) }
                .configure { row, message, _ in row.show(message) }
            ListRow(ChatMessageRow.self)
                .height { [weak self] message, context in
                    ChatMessageRow.height(
                        for: message,
                        width: context.width,
                        maximumAttachmentHeight: self?.attachmentHeightLimit ?? 0,
                        displayScale: self?.displayScale ?? 0,
                    )
                }
                .configure { [weak self] row, message, _ in
                    let chatID = self?.chat?.id
                    row.attachmentHeightLimit = self?.attachmentHeightLimit ?? 0
                    row.displayScale = self?.displayScale ?? 0
                    row.show(message, isStreaming: self?.chat?.isWorking == true)
                    row.onAttachmentLayoutChanged = { [weak self] in
                        guard let self, chat?.id == chatID else { return }
                        messageList.reconfigureRow(with: message.id)
                        messageList.invalidateLayout(forRowWith: message.id)
                    }
                    row.onPreview = { [weak self] item in self?.onComposerPreviewAttachment(item) }
                    row.onPreviewImages = { [weak self] images, selectedID in
                        do {
                            try self?.present(
                                ComposerAttachmentPreview(attachments: images, selectedID: selectedID),
                                animated: true,
                            )
                        } catch {
                            self?.presentNotice(title: "Unable to Preview Attachment", message: error.readableMessage)
                        }
                    }
                }
        }
        view.insertSubview(messageList, at: 0)
        // The composer is another overlay; explicitly identify the list
        // whose scroll position drives the navigation bar's edge treatment.
        setContentScrollView(messageList, for: .top)
        if #available(iOS 26, *) {
            messageList.topEdgeEffect.isHidden = true
        }
        // Top to bottom of the page, so it scrolls under the bar and the
        // composer, but side to side only across the safe area: a row lays
        // itself out across the list's whole width, and a vertical bar's
        // strip is the bar's. The margins inside it still scroll.
        messageList.snp.makeConstraints { make in
            make.top.bottom.equalToSuperview()
            make.leading.trailing.equalTo(view.safeAreaLayoutGuide)
        }
    }

    /// Where the constraints put the list: the page, less the safe area's
    /// sides.
    @objc private dynamic var messageListFrame: CGRect {
        let insets = view.safeAreaInsets
        return view.bounds.inset(by: UIEdgeInsets(top: 0, left: insets.left, bottom: 0, right: insets.right))
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if typesOnAppear {
            typesOnAppear = false
            composer.beginEditing()
        }
        sayUnsent()
        processNextContextSubmission()
    }

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        // read before the list takes the new width
        let width = messageListFrame.width
        guard width != lastLayoutWidth else { return }
        if lastLayoutWidth > 0, !needsInitialScroll, pendingSearchMessageID == nil {
            if distanceFromLatestMessage <= 2 {
                holdsLatestMessage = true
            } else if !holdsLatestMessage, readingPlace == nil {
                readingPlace = currentReadingPlace()
            }
        }
        lastLayoutWidth = width
    }

    /// The row the line under the bar crosses, and the fraction of its
    /// height above that line.
    private func currentReadingPlace() -> (row: ChatMessage.ID, fraction: CGFloat)? {
        let line = messageList.contentOffset.y + messageList.adjustedContentInset.top
        for index in messageList.indicesForVisibleRows.sorted() {
            let frame = messageList.rectForRow(at: index)
            guard frame.height > 0, frame.maxY > line else { continue }
            let fraction = min(max((line - frame.minY) / frame.height, 0), 1)
            return (messageList.content[index].id, fraction)
        }
        return nil
    }

    /// Puts the reader back on the line `readingPlace` kept, now that the
    /// rows have their new width.
    @objc private dynamic func restoreReadingPlace() {
        guard let place = readingPlace else { return }
        readingPlace = nil
        guard !messageList.isTracking, !messageList.isDecelerating else { return }
        messageList.layoutIfNeeded()
        let frame = messageList.rectForRow(with: place.row)
        guard frame.height > 0 else { return }
        let line = frame.minY + place.fraction * frame.height
        let target = min(
            max(line - messageList.adjustedContentInset.top, messageList.minimumContentOffset.y),
            messageList.maximumContentOffset.y,
        )
        guard abs(target - messageList.contentOffset.y) > 0.5 else { return }
        // inside the sidebar's animation the list rides it, as the latest
        // message does (`holdLatestMessage`)
        messageList.contentOffset = CGPoint(x: messageList.contentOffset.x, y: target)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        updateMessageListInsets()
        // Not while `use(_:)` is still swapping the conversation in:
        // restoring its draft lays the window out before its rows are in the
        // list, and a pass then would find the new list empty, take that for
        // its end, and leave the page where the estimated heights put the
        // end — a long chat's middle. `use(_:)` asks for the pass after.
        if needsInitialScroll, !isSwitchingChat, view.window != nil, messageList.bounds.width > 0,
           messageList.bounds.height > 0
        {
            needsInitialScroll = false
            // The list measures newly visible rows during layout. Settle
            // those measurements at the end too, before the page is revealed.
            // Each advancing pass measures another row. A clamp or an
            // asynchronous attachment must not keep the main thread here;
            // leave the request pending for its next real layout instead.
            for _ in 0 ... messageList.content.count {
                let previousOffset = messageList.contentOffset.y
                let previousEnd = messageList.maximumContentOffset.y
                messageList.scrollToBottom(animated: false)
                messageList.layoutIfNeeded()
                if abs(messageList.contentOffset.y - messageList.maximumContentOffset.y) <= 0.5 {
                    break
                }
                if abs(messageList.contentOffset.y - previousOffset) <= 0.5,
                   abs(messageList.maximumContentOffset.y - previousEnd) <= 0.5
                {
                    break
                }
            }
            needsInitialScroll = abs(messageList.contentOffset.y - messageList.maximumContentOffset.y) > 0.5
        }
        scrollToSearchResultIfReady()
        if holdsLatestMessage {
            messageList.layoutIfNeeded()
            holdLatestMessage()
        } else {
            restoreReadingPlace()
        }
        updateLatestMessageButton()
        topBlur.frame = CGRect(
            x: 0,
            y: 0,
            width: view.bounds.width,
            height: min(view.bounds.height, view.safeAreaInsets.top),
        )
    }

    /// Shows `chat`. The same conversation again only takes its new name;
    /// another one also swaps the messages and the draft.
    func use(_ chat: ChatSummary) {
        loadViewIfNeeded()
        let previous = self.chat
        if previous?.id != chat.id, let previous {
            // Snapshot the visible draft before returning deferred drafts:
            // restoration may also merge attachments imported while waiting.
            runtime.saveDraft(composer.draft, for: previous.id)
        }
        self.chat = chat
        let leavingSubmissions = contextSubmissionOrder.filter { id in
            pendingContextSubmissions[id]?.chatID != chat.id
        }
        if !leavingSubmissions.isEmpty {
            let hadContextDecisionAlert = contextDecisionAlert != nil
            contextSubmissionsSuspended = true
            deferredContextProcessing = true
            dismissContextDecisionAlert()
            for submissionID in leavingSubmissions.reversed() {
                contextCompactionTasks[submissionID]?.cancel()
                finishContextDecision(submissionID, restore: true, advance: false)
            }
            contextSubmissionsSuspended = false
            deferredContextProcessing = !hadContextDecisionAlert
        }
        ConversationNotices.shared.withdraw(session: runtime.records[chat.id]?.sessionID)
        updateModelSelection()
        ensureModelSelection()
        title = chat.displayTitle
        // rolled only on screen; a page coming back shows its name at once
        titleView.setTitle(chat.displayTitle, animated: previous != nil && view.window != nil)
        guard previous?.id != chat.id else { return }
        isSwitchingChat = true
        pendingSearchMessageID = nil
        needsInitialScroll = true
        holdsLatestMessage = false
        readingPlace = nil
        defer { isSwitchingChat = false }
        replaceMessageList()

        let draft = runtime.records[chat.id]?.draft ?? ComposerDraft()
        composer.restore(draft: draft)
        messages = runtime.transcript(chat.id).messages
        // A turn still running is followed again, its pace measured afresh.
        turnMessage = TurnFollowing.turnMessage(in: messages)
        followedTurn = runtime.records[chat.id]?.summary.isWorking == true ? turnMessage : nil
        turnPace = TurnFollowing.Pace()
        showTranscript(messages)
        refreshRuntime()
        messageList.scrollToBottom(animated: false)
        updateLatestMessageButton()
        // the opening pass, now that the rows are in (`viewDidLayoutSubviews`)
        view.setNeedsLayout()
        sayUnsent()
        if deferredContextProcessing {
            DispatchQueue.main.async { [weak self] in self?.processNextContextSubmission() }
        }
    }

    /// Back in front with this conversation on screen: its banners have
    /// said what they had to.
    @objc private dynamic func withdrawNotifications() {
        guard let chat, view.window != nil else { return }
        ConversationNotices.shared.withdraw(session: runtime.records[chat.id]?.sessionID)
    }

    @objc dynamic func refreshRuntime() {
        guard let chat else { return }
        if let summary = runtime.records[chat.id]?.summary {
            self.chat = summary
            if title != summary.displayTitle {
                // a rename, or the agent's title: the back button's too
                title = summary.displayTitle
            }
            titleView.setTitle(summary.displayTitle, animated: view.window != nil)
            let transcript = runtime.transcript(chat.id)
            updateMessages(transcript.messages)
            quietWatch.wake(at: transcript.quietDeadline) { [weak self] in self?.refreshRuntime() }
            // also when the session stopped, or a turn began, with no event
            // that redraws the request
            showApproval(waitingApproval(in: messages))
            processNextContextSubmission()
            let stoppable = summary.isWorking ? chat.id : nil
            if stoppable != stoppableChat {
                if stoppable == nil, stoppableChat != nil {
                    loadComposerBalance(force: true)
                }
                stoppableChat = stoppable
                composer.modelBar.setOutputCancellation(summary.isWorking ? { [weak self] in
                    guard let self else { return }
                    Task {
                        do { try await self.runtime.stop(chat.id) }
                        catch { self.presentNotice(title: "Unable to Stop", message: error.readableMessage) }
                    }
                } : nil)
            }
        }
    }

    /// Sends the reader's decision. Approving a command as root first asks
    /// for Face ID, Touch ID or the passcode (`DeviceOwnerCheck`); when that
    /// does not pass, nothing is sent and the request goes on waiting.
    private func decide(_ request: ChatMessage, _ decision: ApprovalDecision, in chatID: UUID) async {
        var ownerVerified: Bool?
        if decision == .approve, request.runsAsRoot {
            guard checkingOwner == nil else { return }
            checkingOwner = request.id
            let confirmed = await DeviceOwnerCheck.confirm(
                reason: String(localized: "Approve a command that runs as root on this device."),
            )
            checkingOwner = nil
            guard confirmed else {
                SPIndicator.present(
                    title: String(localized: "Not Approved"),
                    message: String(localized: "The request is still waiting."),
                    preset: .error,
                    haptic: .error,
                )
                return
            }
            ownerVerified = true
        }
        do {
            try await runtime.approve(request.id, in: chatID, decision: decision, ownerVerified: ownerVerified)
        } catch {
            presentNotice(title: "Unable to Send Decision", message: error.readableMessage)
        }
    }

    private func showApproval(_ request: ChatMessage?) {
        guard request != shownApproval else { return }
        shownApproval = request
        composer.showApproval(request)
    }

    /// A new user message starts a turn, whose output the list then follows
    /// (`followTurn`), timing its reply as it streams.
    private func updateMessages(_ items: [ChatMessage]) {
        guard messages != items else { return }
        // A compaction's row comes between turns, with none to follow: a
        // reader at the latest message is shown it.
        let revealsCompaction = pendingSearchMessageID == nil
            && followedTurn == nil && distanceFromLatestMessage <= 2
            && items.last?.role == .compaction && items.last?.id != messages.last?.id
        messages = items
        let message = TurnFollowing.turnMessage(in: items)
        if message != turnMessage {
            turnMessage = message
            followedTurn = message
            turnPace = TurnFollowing.Pace()
        }
        if let followedTurn {
            turnPace.observe(tokens: TurnFollowing.replyTokens(in: items, after: followedTurn), at: CACurrentMediaTime())
        }
        showTranscript(items)
        followTurn()
        if revealsCompaction {
            revealLatestMessage()
        }
        updateLatestMessageButton()
    }

    /// Moves the list with the followed turn's output: to its end while the
    /// reply streams no faster than a reader keeps up with. A faster one is
    /// followed until the turn's message reaches the top of the visible
    /// area, under the bar's blur, and the list then holds still for the
    /// rest of the turn.
    @objc private dynamic func followTurn() {
        guard pendingSearchMessageID == nil,
              let followed = followedTurn,
              !messageList.isTracking,
              !messageList.isDecelerating
        else { return }
        let animated = !isSwitchingChat && !needsInitialScroll && !UIAccessibility.isReduceMotionEnabled
        let move = TurnFollowing.move(
            pace: turnPace,
            offset: messageList.contentOffset.y,
            latest: messageList.maximumContentOffset.y,
            messageTop: messageList.rectForRow(with: followed).minY,
            topInset: max(messageList.adjustedContentInset.top, topBlur.frame.maxY),
        )
        switch move {
        case .latest:
            messageList.scrollToBottom(animated: animated)
        case let .stop(offset):
            followedTurn = nil
            messageList.setContentOffset(CGPoint(x: messageList.contentOffset.x, y: offset), animated: animated)
        }
    }

    /// Shows the newest content, once: the turn is not followed again.
    @objc private dynamic func revealLatestMessage() {
        messageList.scrollToBottom(animated: !UIAccessibility.isReduceMotionEnabled)
        updateLatestMessageButton()
    }

    private func showTranscript(_ items: [ChatMessage]) {
        if let page = tracePage, let message = items.first(where: { $0.id == page.messageID }) {
            page.show(message)
        }
        let visible = items.filter { !$0.role.isApproval }
        messageList.apply(visible, animated: !isSwitchingChat && !UIAccessibility.isReduceMotionEnabled)
        showApproval(waitingApproval(in: items))
        contextBar.show(ChatContextUsage.measure(items, window: chat.map { runtime.transcript($0.id).contextWindow } ?? nil))
    }

    /// Puts the window meter above the composer, as the design draws it: a
    /// line between the last message and the field, where the eye already is
    /// when deciding whether to keep going.
    ///
    /// It is a subview of the page rather than of the list: the list is
    /// rebuilt when the conversation changes, and a subview of it would be
    /// thrown away with the old one.
    private func installContextBar() {
        guard contextBar.superview == nil, composerBackground.superview != nil else { return }
        contextBar.onTap = { [weak self] in self?.showContext() }
        view.addSubview(contextBar)
        contextBar.snp.makeConstraints { make in
            make.leading.trailing.equalToSuperview().inset(12)
            make.bottom.equalTo(composerBackground.snp.top).offset(-8)
            make.height.equalTo(32)
        }
    }

    /// The request among `items` the composer asks about: one the session's
    /// running turn waits on. A request its stopped session left can no
    /// longer be answered, and a message on its way to a conversation at
    /// rest makes it work before any turn runs (`ChatRuntime.runsTurn`).
    private func waitingApproval(in items: [ChatMessage]) -> ChatMessage? {
        guard let chat, runtime.runsTurn(chat.id) else { return nil }
        return items.first { $0.role.needsApproval }
    }

    @objc private dynamic func updateModelSelection() {
        let selection = ComposerModelSelection.current
        modelHeader.show(model: selection?.model, provider: selection.map {
            let name = ProviderLabel.displayName(of: $0.provider)
            return $0.relayGroupName.map { "\(name) · \($0)" } ?? name
        })
        modelHeader.showBalanceAction(callingAccounts: selection?.provider.kind == .openAICompatible)
        composer.modelBar.setModelName(selection?.model)
        composer.modelBar.setEfforts(selection?.supportedEfforts ?? [], selected: selection?.effort)
        composer.modelBar.setTiers(selection?.supportedTiers ?? [], selected: selection?.tier)
        loadComposerBalance(force: false)
    }

    @objc private dynamic func refreshComposerBalance() {
        loadComposerBalance(force: false)
    }

    @objc private dynamic func showComposerBalance(_ text: String) {
        composer.inputEditor.showBalance(text)
        modelHeader.showBalance(text)
    }

    @objc private dynamic func loadComposerBalance(force: Bool) {
        let selection = ComposerModelSelection.current
        let provider = selection?.provider
        let balanceChoice = provider.map { $0.rawValue + "|" + (selection?.relayGroupID ?? "") }
        let changed = composerBalanceProvider != balanceChoice
        composerBalanceProvider = balanceChoice
        composerBalanceLoader?.cancel()
        composerBalanceGeneration += 1
        let generation = composerBalanceGeneration
        if changed || provider == nil {
            showComposerBalance(String(localized: "Balance Unavailable"))
        }
        guard let provider else { return }
        let meta = ProviderMetaStore.meta(for: provider.rawValue)
        guard meta.balanceEnabled else {
            showComposerBalance(String(localized: "Balance Unavailable"))
            return
        }
        composerBalanceLoader = Task { [weak self] in
            guard let self else { return }
            do {
                let accounts = try await ApelinService.app.agentAccountList().accounts
                guard !Task.isCancelled, generation == composerBalanceGeneration,
                      let account = accounts.first(where: { $0.provider == provider && $0.signedIn })
                else { return }
                let configuration = try await ApelinService.app.agentAPIConfiguration(
                    provider: provider, relayGroupID: selection?.relayGroupID, useActiveAccount: true,
                )
                guard !Task.isCancelled, generation == composerBalanceGeneration else { return }
                let identity = ProviderBalanceHistory.identity(
                    providerRawValue: provider.rawValue, baseURL: account.account ?? "",
                    accountID: configuration.relayAccountID,
                )
                if let text = ProviderBalanceHistory.cachedText(identity) {
                    showComposerBalance("\(String(localized: "Balance")): \(text)")
                } else {
                    showComposerBalance(String(localized: "Balance Unavailable"))
                }
                guard meta.refreshMinutes > 0,
                      force || ProviderBalanceHistory.needsRefresh(identity, every: meta.refreshMinutes)
                else { return }
                let key = (configuration.values["apiKey"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                let baseURL = (configuration.values["baseUrl"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                guard !key.isEmpty, !baseURL.isEmpty else { return }
                if ProviderBalanceHistory.cachedText(identity) == nil {
                    showComposerBalance(String(localized: "Checking Balance…"))
                }
                let balance = try await ProviderBalanceLookup.fetch(
                    baseURL: baseURL, apiKey: key, using: meta.balanceProtocol,
                )
                guard !Task.isCancelled, generation == composerBalanceGeneration else { return }
                ProviderBalanceHistory.cache(balance, for: identity)
                showComposerBalance(
                    "\(String(localized: "Balance")): \(ProviderBalanceLookup.displayText(for: balance))",
                )
            } catch {
                guard !Task.isCancelled, generation == composerBalanceGeneration else { return }
                showComposerBalance(String(localized: "Balance Unavailable"))
            }
        }
    }

    /// A model disabled in Settings stops being the one the next message uses.
    @objc private dynamic func enabledModelsChanged() {
        ensureModelSelection()
    }

    /// The list scrolls clear of the composer, and of the keyboard under it.
    @objc private dynamic func updateMessageListInsets() {
        let top = max(modelHeader.frame.maxY - view.safeAreaInsets.top, 0) + 12
        if messageList.contentInset.top != top {
            messageList.contentInset.top = top
            messageList.verticalScrollIndicatorInsets.top = top
        }
        let covered = max(view.bounds.height - composerBackground.frame.minY, 0)
        let bottom = max(covered - view.safeAreaInsets.bottom, 0)
        if messageList.contentInset.bottom != bottom + 16 {
            // a reader at the latest message, or following a turn, stays there
            let keepsLatest = pendingSearchMessageID == nil
                && (followedTurn != nil || distanceFromLatestMessage <= 2)
            messageList.contentInset.bottom = bottom + 16
            if keepsLatest, !messageList.isTracking, !messageList.isDecelerating {
                if UIView.inheritedAnimationDuration > 0 {
                    // The composer is springing to a new height: the list
                    // rides the same animation. `scrollToBottom(animated:
                    // false)` would jump there ahead of it, since ListView
                    // keeps its own placements out of a caller's animation;
                    // the public setter is the one it leaves to the host.
                    messageList.contentOffset = messageList.maximumContentOffset
                } else {
                    // Opening and keyboard layout place the list immediately;
                    // only a new transcript update animates following output.
                    messageList.scrollToBottom(animated: false)
                }
            }
        }
        if messageList.verticalScrollIndicatorInsets.bottom != bottom {
            messageList.verticalScrollIndicatorInsets.bottom = bottom
        }
    }

    private static func balanceIdentity(for account: AgentAccount) -> String {
        ProviderBalanceHistory.identity(
            providerRawValue: account.provider.rawValue,
            baseURL: account.account ?? "",
        )
    }

    private func refreshBalances(for accounts: [AgentAccount]) {
        balanceLoader?.cancel()
        balanceGeneration += 1
        let generation = balanceGeneration
        let endpoints = accounts.compactMap { account -> (AgentAccount, ProviderMeta, String)? in
            guard account.signedIn,
                  account.provider.kind == .openAICompatible
            else {
                return nil
            }
            let meta = ProviderMetaStore.meta(for: account.provider.rawValue)
            guard meta.balanceEnabled, meta.refreshMinutes > 0 else { return nil }
            let identity = Self.balanceIdentity(for: account)
            return ProviderBalanceHistory.needsRefresh(identity, every: meta.refreshMinutes)
                ? (account, meta, identity)
                : nil
        }
        guard !endpoints.isEmpty else {
            balanceLoader = nil
            return
        }
        balanceLoader = Task { [weak self] in
            for (account, meta, identity) in endpoints {
                guard !Task.isCancelled, self?.balanceGeneration == generation else { return }
                do {
                    let configuration = try await ApelinService.app.agentAPIConfiguration(provider: account.provider)
                    let key = (configuration.values["apiKey"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                    let baseURL = (configuration.values["baseUrl"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !key.isEmpty, !baseURL.isEmpty else { continue }
                    let balance = try await ProviderBalanceLookup.fetch(
                        baseURL: baseURL,
                        apiKey: key,
                        using: meta.balanceProtocol,
                    )
                    guard !Task.isCancelled, self?.balanceGeneration == generation else { return }
                    ProviderBalanceHistory.cache(balance, for: identity)
                } catch {
                    continue
                }
            }
        }
    }

    /// Re-read the real enabled catalogue each time, including after setup.
    @objc private dynamic func showModelPicker() {
        guard let chat, presentedViewController == nil else { return }
        view.endEditing(true)
        modelLoader?.cancel()
        balanceLoader?.cancel()
        balanceGeneration += 1
        balanceLoader = nil
        modelLoader = Task { [weak self] in
            guard let self else { return }
            do {
                let accounts = try await EnabledModels.accounts(from: ApelinService.app.agentAccountList().accounts)
                guard !Task.isCancelled, self.chat?.id == chat.id, presentedViewController == nil else { return }
                guard !accounts.isEmpty else {
                    presentPageAsFormSheet(ModelProvidersController())
                    return
                }
                refreshBalances(for: accounts)
                let page = ChatModelPickerController(accounts: accounts, selected: ComposerModelSelection.current) { model, account in
                    ComposerModelSelection.current = Self.selection(of: model, in: account)
                }
                presentPageAsFormSheet(page)
            } catch {
                guard !Task.isCancelled, self.chat?.id == chat.id else { return }
                presentNotice(title: "Models Unavailable", message: error.readableMessage)
            }
        }
    }

    @objc private dynamic func showCallingAccounts() {
        guard let provider = ComposerModelSelection.current?.provider, presentedViewController == nil else { return }
        let selection = ComposerModelSelection.current
        balanceDetailLoader?.cancel()
        balanceDetailLoader = Task { [weak self] in
            guard let self else { return }
            do {
                let configuration = try await ApelinService.app.agentAPIConfiguration(provider: provider)
                guard !Task.isCancelled, ComposerModelSelection.current?.provider == provider,
                      ComposerModelSelection.current?.relayGroupID == selection?.relayGroupID,
                      ComposerModelSelection.current?.model == selection?.model,
                      presentedViewController == nil else { return }
                let key = (configuration.values["apiKey"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                let url = (configuration.values["baseUrl"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                guard !key.isEmpty, !url.isEmpty else {
                    presentPageAsFormSheet(ModelProvidersController())
                    return
                }
                if provider.kind == .openAICompatible {
                    let page = try RelayAccountController(
                        provider: provider, groupID: selection?.relayGroupID,
                        model: selection?.model ?? "", values: configuration.values,
                    )
                    presentPageAsFormSheet(page)
                } else {
                    let page = ProviderBalanceScreen(
                        name: ProviderLabel.displayName(of: provider), baseURL: url, apiKey: key,
                        rawValue: provider.rawValue, meta: ProviderMetaStore.meta(for: provider.rawValue),
                        accountID: configuration.relayAccountID,
                    )
                    page.loadViewIfNeeded()
                    page.tableView.backgroundColor = .clear
                    page.tableView.backgroundView = ChatGlassView(style: .systemMaterial)
                    presentPageAsFormSheet(page)
                }
            } catch {
                guard !Task.isCancelled else { return }
                presentNotice(title: "Balance Unavailable", message: error.readableMessage)
            }
        }
    }
}

extension ChatController {
    /// `model` of `account` with what the catalog says it offers. The
    /// reader's effort and speed are kept apart (`ComposerModelPreferences`),
    /// so picking a model that lacks them does not lose them.
    private static func selection(of model: String, in account: AgentAccount) -> ComposerModelSelection {
        ComposerModelSelection(
            provider: account.provider,
            model: model,
            supportedEfforts: (account.reasoningEfforts?[model] ?? []).filter { [.low, .high, .max].contains($0) },
            supportedTiers: account.serviceTiers?[model] ?? [],
            relayGroupID: account.relayGroupID,
            relayGroupName: account.modelGroups?.first {
                $0.id == (account.relayGroupID ?? AgentRelayConfiguration.defaultGroupID)
            }?.name,
        )
    }

    /// With no model picked, or one no longer enabled, the first enabled
    /// model is picked; with none enabled the bar keeps asking. A model
    /// still enabled takes the catalog's efforts and tiers again. A
    /// signed-in account whose sign-in did not read this time lists no
    /// models; its model is kept rather than swapped for another's.
    @objc dynamic func ensureModelSelection() {
        selectionCheck?.cancel()
        selectionCheck = Task {
            guard let listed = try? await ApelinService.app.agentAccountList().accounts,
                  !Task.isCancelled
            else { return }
            let accounts = EnabledModels.accounts(from: listed)
            if let current = ComposerModelSelection.current {
                if let account = accounts.first(where: { account in
                    account.provider == current.provider && account.relayGroupID == current.relayGroupID
                        && (account.models ?? []).contains(current.model)
                }) {
                    let refreshed = Self.selection(of: current.model, in: account)
                    if refreshed != current {
                        ComposerModelSelection.current = refreshed
                    }
                    return
                }
                if listed.contains(where: { $0.provider == current.provider && $0.signedIn && $0.models == nil }) {
                    return
                }
            }
            guard let account = accounts.first, let model = account.models?.first else { return }
            ComposerModelSelection.current = Self.selection(of: model, in: account)
        }
    }

    /// The runtime put `id`'s draft back, or emptied it: a message its run
    /// never took, a send that failed, or a returned one the host had taken.
    @objc dynamic func restoreDraft(for id: UUID) {
        guard chat?.id == id, restoringContextDraftFor != id,
              !contextSubmissionOrder.contains(where: { pendingContextSubmissions[$0]?.chatID == id }),
              let draft = runtime.records[id]?.draft
        else { return }
        composer.restore(draft: draft)
    }

    /// A stopped run's queued messages went back to `id`'s composer: the
    /// reader is told when they next see the conversation, now if they do.
    func unsentReturned(_ returned: DroppedMessages.Returned, to id: UUID) {
        let earlier = unsent[id] ?? (0, 0)
        unsent[id] = (earlier.messages + returned.messages, earlier.attachmentsLeftOut + returned.attachmentsLeftOut)
        sayUnsent()
    }

    /// Says what went back to the composer of the conversation on screen,
    /// spoken too: nothing else marks it.
    @objc private dynamic func sayUnsent() {
        guard let chat, view.window != nil, UIApplication.shared.applicationState == .active,
              let returned = unsent.removeValue(forKey: chat.id)
        else { return }
        let title = String(localized: "\(returned.messages) Messages Not Sent")
        let message = returned.attachmentsLeftOut > 0
            ? String(localized: "\(returned.attachmentsLeftOut) attachments could not be put back")
            : String(localized: "Back in the input box")
        SPIndicator.present(title: title, message: message, preset: .error, haptic: .warning)
        UIAccessibility.post(notification: .announcement, argument: [title, message].joined(separator: ", "))
    }

    /// The keyboard up in the composer, now if the page is on screen, else
    /// once it is: a link's prompt waits there for the reader's Send.
    @objc dynamic func beginTyping() {
        guard view.window != nil else {
            typesOnAppear = true
            return
        }
        composer.beginEditing()
    }

    /// `text` as the reader's next message, as if typed and sent; during a
    /// reply, the run takes it at its next step.
    @objc dynamic func sendPrompt(_ text: String) {
        guard chat != nil else { return }
        _ = onComposerSubmit(draft: ComposerDraft(text: text), submissionID: UUID(), completion: {})
    }
}

extension ChatController: ComposerView.Delegate {
    func onComposerSubmit(
        draft: ComposerDraft,
        submissionID: UUID,
        completion: @escaping @MainActor () -> Void,
    ) -> ComposerView.SubmissionDisposition {
        guard let chat else {
            completion()
            return .sentImmediately
        }
        let chatID = chat.id
        let ownsComposer = composer.tracksSubmission(submissionID)
        let usage = ChatContextUsage.measure(runtime.transcript(chatID).messages, adding: draft, window: runtime.transcript(chatID).contextWindow)
        let chatHasQueuedSubmission = contextSubmissionOrder.contains {
            pendingContextSubmissions[$0]?.chatID == chatID
        } || contextSubmissionInFlight.map { contextSubmissionChat[$0] == chatID } == true
        guard usage.isLarge || chatHasQueuedSubmission else {
            send(
                draft,
                to: chatID,
                submissionID: submissionID,
                completion: completion,
                ownsComposer: ownsComposer,
            )
            return .sentImmediately
        }
        pendingContextSubmissions[submissionID] = PendingContextSubmission(
            chatID: chatID,
            draft: draft,
            completion: completion,
            ownsComposer: ownsComposer,
        )
        contextSubmissionOrder.append(submissionID)
        contextSubmissionChat[submissionID] = chatID
        if ownsComposer {
            composer.deferSubmission(submissionID)
        }
        processNextContextSubmission()
        return .waitingForDecision
    }

    private func processNextContextSubmission() {
        guard view.window != nil, !contextSubmissionsSuspended else {
            deferredContextProcessing = true
            return
        }
        guard activeContextDecision == nil, contextSubmissionInFlight == nil, presentedViewController == nil else { return }
        deferredContextProcessing = false
        while let submissionID = contextSubmissionOrder.first {
            guard let pending = pendingContextSubmissions[submissionID] else {
                contextSubmissionOrder.removeFirst()
                continue
            }
            guard chat?.id == pending.chatID else { return }
            activeContextDecision = submissionID
            guard runtime.records[pending.chatID] != nil else {
                sendContextSubmission(submissionID)
                return
            }
            let usage = ChatContextUsage.measure(runtime.transcript(pending.chatID).messages, adding: pending.draft, window: runtime.transcript(pending.chatID).contextWindow)
            guard usage.isLarge, runtime.records[pending.chatID]?.sessionID != nil else {
                sendContextSubmission(submissionID)
                return
            }
            if runtime.isCompacting(pending.chatID) {
                activeContextDecision = nil
                return
            }
            guard runtime.canCompact(pending.chatID) else {
                sendContextSubmission(submissionID)
                return
            }
            guard CompactionTuning.autoCompact else {
                presentContextDecision(for: submissionID, usage: usage)
                return
            }
            compactThenSend(submissionID)
            return
        }
    }

    private func presentContextDecision(for submissionID: UUID, usage: ChatContextUsage) {
        guard let pending = pendingContextSubmissions[submissionID], chat?.id == pending.chatID else {
            finishContextDecision(submissionID, restore: true)
            return
        }
        activeContextDecision = submissionID
        let alert = UIAlertController(
            title: String(localized: "Context Near Limit"),
            message: String.localizedStringWithFormat(
                String(localized: "The estimated context is at %@. This estimate includes your draft and attachments; the provider's actual token count may differ. Choose how to continue."),
                usage.percentText,
            ),
            preferredStyle: .alert,
        )
        alert.addAction(UIAlertAction(title: String(localized: "Compact and Send"), style: .default) { [weak self, weak alert] _ in
            self?.contextDecisionAlert = nil
            alert?.dismiss(animated: true) { [weak self] in
                self?.compactThenSend(submissionID)
            }
        })
        alert.addAction(UIAlertAction(title: String(localized: "Compact and Enable Automatic Compaction"), style: .default) { [weak self, weak alert] _ in
            CompactionTuning.setAutoCompact(true)
            self?.contextDecisionAlert = nil
            alert?.dismiss(animated: true) { [weak self] in
                self?.compactThenSend(submissionID)
            }
        })
        alert.addAction(UIAlertAction(title: String(localized: "Cancel"), style: .cancel) { [weak self, weak alert] _ in
            self?.contextDecisionAlert = nil
            alert?.dismiss(animated: true) { [weak self] in
                self?.finishContextDecision(submissionID, restore: true)
            }
        })
        contextDecisionAlert = alert
        present(alert, animated: true) { [weak self] in
            guard let self, contextDecisionAlert === alert else { return }
            if alert.isBeingDismissed || alert.presentingViewController == nil {
                contextDecisionAlert = nil
                finishContextDecision(submissionID, restore: true)
            } else {
                processNextContextSubmission()
            }
        }
    }

    private func dismissContextDecisionAlert() {
        guard let alert = contextDecisionAlert else { return }
        contextDecisionAlert = nil
        alert.dismiss(animated: false) { [weak self] in
            self?.processNextContextSubmission()
        }
    }

    private func compactThenSend(_ submissionID: UUID) {
        guard let pending = pendingContextSubmissions[submissionID],
              activeContextDecision == submissionID
        else { return }
        guard runtime.canCompact(pending.chatID) else {
            if runtime.isCompacting(pending.chatID) {
                activeContextDecision = nil
            } else {
                sendContextSubmission(submissionID)
            }
            return
        }
        let task = Task { [weak self] in
            guard let self else { return }
            defer {
                self.contextCompactionTasks[submissionID] = nil
                self.processNextContextSubmission()
            }
            do {
                let result = try await ProgressCard.run(
                    title: String(localized: "Compacting Chat"),
                    message: String(localized: "Summarizing the earlier messages…"),
                    cancellable: true,
                    from: self,
                ) { _ in try await self.runtime.compact(pending.chatID) }
                guard pendingContextSubmissions[submissionID] != nil,
                      chat?.id == pending.chatID,
                      activeContextDecision == submissionID
                else {
                    finishContextDecision(submissionID, restore: true)
                    return
                }
                switch result.outcome {
                case .compacted:
                    break
                case .cancelled:
                    finishContextDecision(submissionID, restore: true)
                    return
                case .tooShort, .failed:
                    finishContextDecision(submissionID, restore: true, advance: false)
                    let message = result.message ?? String(localized: "The draft was not sent because compaction did not finish.")
                    presentNotice(title: "Unable to Compact Chat", message: message) { [weak self] in
                        self?.processNextContextSubmission()
                    }
                    return
                }
                sendContextSubmission(submissionID)
            } catch is CancellationError {
                finishContextDecision(submissionID, restore: true)
            } catch {
                finishContextDecision(submissionID, restore: true, advance: false)
                ConversationJournal.compactFailed(error, session: runtime.records[pending.chatID]?.sessionID)
                presentNotice(title: "Unable to Compact Chat", message: error.readableMessage) { [weak self] in
                    self?.processNextContextSubmission()
                }
            }
        }
        contextCompactionTasks[submissionID] = task
    }

    private func sendContextSubmission(_ submissionID: UUID) {
        guard let pending = pendingContextSubmissions[submissionID],
              activeContextDecision == submissionID
        else { return }
        activeContextDecision = nil
        pendingContextSubmissions[submissionID] = nil
        contextSubmissionOrder.removeAll { $0 == submissionID }
        contextSubmissionChat[submissionID] = pending.chatID
        contextSubmissionInFlight = submissionID
        send(
            pending.draft,
            to: pending.chatID,
            submissionID: submissionID,
            completion: { [weak self] in
                pending.completion()
                if self?.contextSubmissionInFlight == submissionID {
                    self?.contextSubmissionInFlight = nil
                    self?.contextSubmissionChat[submissionID] = nil
                }
                self?.processNextContextSubmission()
            },
            ownsComposer: pending.ownsComposer,
        )
    }

    private func finishContextDecision(_ submissionID: UUID, restore: Bool, advance: Bool = true) {
        guard let pending = pendingContextSubmissions.removeValue(forKey: submissionID) else { return }
        contextSubmissionOrder.removeAll { $0 == submissionID }
        contextSubmissionChat[submissionID] = nil
        if activeContextDecision == submissionID {
            activeContextDecision = nil
        }
        if contextDecisionAlert != nil {
            dismissContextDecisionAlert()
        }
        contextCompactionTasks[submissionID]?.cancel()
        contextCompactionTasks[submissionID] = nil
        if restore {
            restoringContextDraftFor = pending.chatID
            runtime.restoreUnsentDraft(pending.draft, to: pending.chatID)
            restoringContextDraftFor = nil
        }
        if pending.ownsComposer, composer.tracksSubmission(submissionID) {
            if restore, chat?.id == pending.chatID, let restored = runtime.records[pending.chatID]?.draft {
                composer.restore(draft: restored)
            } else if chat?.id == pending.chatID {
                composer.acceptSubmission(submissionID)
            }
        }
        contextCompactionTasks[submissionID] = nil
        pending.completion()
        if advance {
            processNextContextSubmission()
        }
    }

    private func send(
        _ draft: ComposerDraft,
        to chatID: UUID,
        submissionID: UUID,
        completion: @escaping @MainActor () -> Void,
        ownsComposer: Bool = false,
    ) {
        guard runtime.records[chatID] != nil else {
            completion()
            return
        }
        ConversationNotices.shared.requestAuthorizationIfNeeded()
        let sending = runtime.submit(draft, to: chatID)
        if chat?.id == chatID, let row = messages.last, row.id == draft.id, row.isQueued {
            revealLatestMessage()
        }
        Task {
            defer {
                if ownsComposer, self.composer.tracksSubmission(submissionID) {
                    self.composer.acceptSubmission(submissionID)
                }
                completion()
            }
            do {
                try await sending.value
            } catch is CancellationError {
                // stopped by the reader: the draft is back in its conversation
            } catch {
                if self.chat?.id == chatID {
                    self.saySendFailed(error)
                }
            }
        }
    }

    /// Says why a message was not sent; its draft is back in the composer
    /// by now. A failure the agent named (no network, a provider out of
    /// reach) is a passing line, spoken too, since nothing else marks it;
    /// any other keeps its own words in an alert.
    private func saySendFailed(_ error: any Error) {
        guard let reason = (error as? ApelinError)?.reason, let cause = ChatFailure.title(for: reason) else {
            presentNotice(title: "Unable to Send Message", message: error.readableMessage)
            return
        }
        let title = String(localized: "Message Not Sent")
        SPIndicator.present(title: title, message: cause, preset: .error, haptic: .error)
        UIAccessibility.post(notification: .announcement, argument: [title, cause].joined(separator: ", "))
    }

    @objc dynamic func onComposerBeginEditing() {
        ensureModelSelection()
    }

    func onComposerUpdateDraft(_ draft: ComposerDraft) {
        guard let chat else { return }
        let hasPendingSubmissions = contextSubmissionOrder.contains {
            pendingContextSubmissions[$0]?.chatID == chat.id
        }
        if hasPendingSubmissions, draft.text.isEmpty, draft.attachments.isEmpty {
            return
        }
        runtime.saveDraft(draft, for: chat.id)
    }

    @objc dynamic func onComposerCameraTapped() {
        importer()?.camera()
    }

    @objc dynamic func onComposerPhotoTapped() {
        importer()?.photos()
    }

    @objc dynamic func onComposerFileTapped() {
        importer()?.files()
    }

    @objc dynamic func onComposerWebTapped() {
        importer()?.web()
    }

    @objc dynamic func onComposerPasteAsAttachmentTapped() {
        importer()?.paste()
    }

    @objc dynamic func onComposerPastedLongText(_ text: String) {
        importer()?.importText(text)
    }

    @objc dynamic func onComposerPastedImage(_ image: UIImage) {
        importer()?.importImage(image)
    }

    @objc dynamic func onComposerDropped(_ providers: [NSItemProvider]) {
        importer()?.drop(providers)
    }

    func onComposerPreviewAttachment(_ attachment: ComposerAttachment) {
        do { try present(ComposerAttachmentPreview(attachment: attachment), animated: true) }
        catch { presentNotice(title: "Unable to Preview Attachment", message: error.readableMessage) }
    }

    @objc private dynamic func importer() -> ComposerAttachmentImport? {
        guard let chat, presentedViewController == nil else { return nil }
        let draftID = composer.draft.id
        let importer = ComposerAttachmentImport(presenter: self) { [weak self] item in
            guard let self else { return }
            if self.chat?.id == chat.id, composer.draft.id == draftID {
                composer.insertAttachment(item)
            } else if var draft = runtime.records[chat.id]?.draft, draft.id == draftID {
                draft.attachments.append(item)
                runtime.saveDraft(draft, for: chat.id)
            }
        }
        attachmentImport = importer
        return importer
    }
}

extension ChatController: UIScrollViewDelegate {
    @objc dynamic func scrollViewWillBeginDragging(_: UIScrollView) {
        holdsLatestMessage = false
        readingPlace = nil
        // The reader has the list: only the next turn is followed again.
        followedTurn = nil
    }

    @objc dynamic func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if !scrollView.isTracking, !scrollView.isDecelerating {
            holdLatestMessage()
        }
        updateLatestMessageButton()
    }

    @objc private dynamic func holdLatestMessage() {
        guard holdsLatestMessage, !messageList.isTracking, !messageList.isDecelerating,
              distanceFromLatestMessage > 0.5 else { return }
        if UIView.inheritedAnimationDuration > 0 {
            // inside the sidebar's animation, which ListView leaves to the
            // host when the offset is set directly
            messageList.contentOffset = messageList.maximumContentOffset
        } else {
            messageList.scrollToBottom(animated: false)
        }
    }

    @objc private dynamic var distanceFromLatestMessage: CGFloat {
        max(0, messageList.maximumContentOffset.y - messageList.contentOffset.y)
    }

    @objc private dynamic func updateLatestMessageButton() {
        let alpha: CGFloat = followedTurn == nil && distanceFromLatestMessage > 2 ? 1 : 0
        guard latestMessageButton.alpha != alpha else { return }
        if alpha > 0 {
            latestMessageButton.isHidden = false
        }
        UIView.animate(
            withDuration: UIAccessibility.isReduceMotionEnabled ? 0 : 0.18,
            delay: 0,
            options: [.beginFromCurrentState, .allowUserInteraction],
        ) {
            self.latestMessageButton.alpha = alpha
        } completion: { _ in
            self.latestMessageButton.isHidden = self.latestMessageButton.alpha == 0
        }
    }
}
