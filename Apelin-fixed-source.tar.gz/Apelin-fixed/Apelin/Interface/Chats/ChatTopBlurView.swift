import UIKit

final class ChatTopBlurView: ChatGlassView {
    init() {
        super.init(style: .systemThinMaterial)
        isUserInteractionEnabled = false
        isAccessibilityElement = false
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("Use init()")
    }
}
