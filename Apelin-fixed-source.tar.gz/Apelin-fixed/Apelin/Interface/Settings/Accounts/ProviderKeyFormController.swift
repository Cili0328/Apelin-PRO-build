import ApelinProtocol
import UIKit

/// The editable part of an API-key sign-in. The parent owns the sign-in
/// task; this native grouped form owns only the user's unsent field values.
///
/// Three groups, as the design draws them: what the endpoint is called and
/// which shelf it sits on, how to reach it, and how much of its balance to ask
/// about. Only the middle one is a credential — the other two are presentation
/// and never leave the device.
final class ProviderKeyFormController: TableController {
    var onSubmit: (([AgentSignInField: String]) -> Void)?
    var onSwitchMethod: ((AgentSignInMethod) -> Void)?
    /// Called with what the Name row holds when the form is sent. A name is
    /// not a sign-in field: it goes nowhere near the credential.
    var onLabelChange: ((String) -> Void)?
    /// Called with the colour picked, as it is picked: a colour is readable
    /// on the row behind this form, and waiting for a submit to show it would
    /// hide the one thing it is for.
    var onTintChange: ((Int?) -> Void)?
    /// Called as the group is picked, for the same reason as the colour.
    var onGroupChange: ((String?) -> Void)?
    /// Called with the balance settings as they are changed. They are choices
    /// about requests this app makes itself, not credentials.
    var onBalanceSettingsChange: ((ProviderMeta) -> Void)?
    /// Asks the parent to prove the key works without leaving the form.
    var onTestConnection: (() -> Void)?
    /// Asks the parent to remove this endpoint. Only offered once a key is in
    /// place, which is the only time there is anything to remove.
    var onDelete: (() -> Void)?

    @objc dynamic var isSubmitting = false {
        didSet {
            if isViewLoaded {
                updateSubmit()
            }
        }
    }

    var isTestingConnection = false {
        didSet {
            if isViewLoaded {
                updateSubmit()
            }
        }
    }

    private let keys: [SignInProgress.KeyField]
    private var defaultModelID: String?
    private let offersAPIFormat: Bool
    private let alternatives: [AgentSignInMethod]
    private let initialValues: [String: String]
    /// The name this endpoint was given before, shown in the Name row.
    private let labelValue: String?
    /// Whether the identity and balance groups belong here at all: only an
    /// OpenAI-compatible endpoint can be one of several with one name.
    private let showsLabel: Bool
    /// The platform's own name, shown read-only in the connection group.
    private let platformName: String
    private var meta: ProviderMeta
    private let provider: AgentProvider
    @objc private dynamic var relayConfigurationText: String?

    private var fields: [AgentSignInField: UITextField] = [:]
    private var cells: [AgentSignInField: UITableViewCell] = [:]
    private var apiFormat = AgentAPIFormat.chatCompletions
    private var apiFormatCell: UITableViewCell?
    private var apiFormatControl: UISegmentedControl?
    private var labelField: UITextField?
    private var labelCell: UITableViewCell?
    /// The colour this endpoint draws in the list, as chosen; `nil` is the
    /// one it picks for itself.
    private var tintIndex: Int?
    private var tintCell: UITableViewCell?
    private weak var tintRow: ProviderTintPicker?
    private var groupCell: UITableViewCell?
    private var protocolCell: UITableViewCell?
    private var refreshCell: UITableViewCell?
    private var balanceSwitch: UISwitch?
    private var warnField: UITextField?
    private var warnCell: UITableViewCell?
    private var testCell: UITableViewCell?
    private let testSpinner = UIActivityIndicatorView(style: .medium)

    private enum Row: Hashable {
        case label
        case tint
        case group
        case relayAccounts
        case platform
        case apiFormat
        case field(AgentSignInField)
        case balanceEnabled
        case balanceProtocol
        case balanceRefresh
        case balanceWarn
        case test
        case delete
        case method(AgentSignInMethod)
    }

    private enum Section: Hashable {
        case identity
        case connection
        case balance
        case methods
        case actions
    }

    private lazy var dataSource = TableDataSource<Section, Row, Row>(
        tableView: tableView,
        identifier: { $0 },
    ) { [weak self] _, _, row in
        self?.cell(for: row)
    }

    @objc dynamic lazy var submitItem = UIBarButtonItem(
        title: String(localized: "Fetch Models"),
        primaryAction: UIAction { [weak self] _ in self?.submit() },
    )

    init(
        keys: [SignInProgress.KeyField],
        alternatives: [AgentSignInMethod],
        initialValues: [String: String] = [:],
        label: String? = nil,
        showsLabel: Bool = false,
        tint: Int? = nil,
        platform: String = "",
        meta: ProviderMeta = ProviderMeta(),
        provider: AgentProvider = .openAICompatible,
    ) {
        let modelField = keys.first { $0.field == .defaultModel }
        let formatField = keys.first { $0.field == .apiFormat }
        self.keys = keys.filter { $0.field != .defaultModel && $0.field != .apiFormat && $0.field != .relayConfiguration }
        defaultModelID = initialValues[AgentSignInField.defaultModel.rawValue] ?? modelField?.defaultValue
        offersAPIFormat = formatField != nil && showsLabel
        apiFormat = AgentAPIFormat(
            rawValue: initialValues[AgentSignInField.apiFormat.rawValue] ?? formatField?.defaultValue ?? "",
        ) ?? .chatCompletions
        self.alternatives = alternatives
        self.initialValues = initialValues
        labelValue = label
        self.showsLabel = showsLabel
        tintIndex = tint
        platformName = platform
        self.meta = meta
        self.provider = provider
        relayConfigurationText = initialValues[AgentSignInField.relayConfiguration.rawValue]
        super.init(style: .insetGrouped)
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("Use init(keys:alternatives:)")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.keyboardDismissMode = .interactive
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 46
        // Several OpenAI-compatible endpoints share one name, and this is
        // where one is added. The name is kept out of `fields`: it is not a
        // sign-in field and must not be sent to apelin-agent with the key.
        if showsLabel {
            labelField = makeTextField(
                accessibility: "Name",
                placeholder: String(localized: "\(String(localized: "Name")) (Optional)"),
                secure: false,
                url: false,
            )
            labelField?.text = labelValue
            labelField?.autocapitalizationType = .words
            labelField?.addAction(UIAction { [weak self] _ in self?.focusFirstField() }, for: .editingDidEndOnExit)
            if let labelField {
                labelCell = makeKeyedCell(title: String(localized: "Name"), field: labelField)
            }
            tintCell = makeTintCell()
            groupCell = makeValueCell(title: String(localized: "Group"), value: groupTitle)
        }
        for (index, key) in keys.enumerated() {
            let field = makeTextField(
                accessibility: key.field.title,
                placeholder: key.placeholder
                    ?? (key.required ? key.field.title : String(localized: "\(key.field.title) (Optional)")),
                secure: key.secure,
                url: key.field == .baseURL,
            )
            field.keyboardType = key.field == .baseURL ? .URL : .asciiCapable
            field.textContentType = key.field == .baseURL ? .URL : nil
            field.returnKeyType = index == keys.count - 1 ? .go : .next
            field.text = initialValues[key.field.rawValue] ?? key.defaultValue
            field.addAction(UIAction { [weak self] _ in self?.updateSubmit() }, for: .editingChanged)
            field.addAction(UIAction { [weak self] _ in self?.advance(from: index) }, for: .editingDidEndOnExit)
            fields[key.field] = field
            cells[key.field] = makeKeyedCell(title: key.field.title, field: field)
        }
        if offersAPIFormat {
            apiFormatCell = makeAPIFormatCell()
        }
        if showsLabel {
            makeBalanceCells()
            testCell = actionCell(String(localized: "Test Connection"), tint: .tintColor)
            testCell?.accessoryView = testSpinner
        }
        submitItem.tintColor = .tintColor
        submitItem.accessibilityLabel = String(localized: "Fetch Models")
        updateSubmit()
        dataSource.headerTitle = { section in
            switch section {
            case .identity: String(localized: "Identity")
            case .connection: String(localized: "Connection")
            case .balance: String(localized: "Balance")
            case .methods, .actions: nil
            }
        }
        dataSource.footerTitle = { section in
            switch section {
            case .identity:
                String(localized: "The name replaces the platform in the list, the conversation header and the model picker.")
            case .balance:
                String(localized: "Detects New-API, One-API, OpenRouter and DeepSeek automatically.")
            default:
                nil
            }
        }
        var sections: [(Section, [Row])] = []
        if showsLabel {
            sections.append((.identity, [.label, .tint, .group, .relayAccounts]))
        }
        sections.append((.connection, [.platform] + (offersAPIFormat ? [.apiFormat] : []) + keys
                .map { .field($0.field) }))
        if showsLabel {
            sections.append((.balance, [.balanceEnabled, .balanceProtocol, .balanceRefresh, .balanceWarn]))
        }
        if !alternatives.isEmpty {
            sections.append((.methods, alternatives.map(Row.method)))
        }
        if showsLabel {
            sections.append((.actions, [.test, .delete]))
        }
        dataSource.update(sections)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        guard !isSubmitting else { return }
        // The Name row comes first and is the only one here that is not a
        // credential: fill that, then the key.
        if let labelField, (labelField.text ?? "").isEmpty {
            labelField.becomeFirstResponder()
        } else {
            focusFirstField()
        }
    }

    private func focusFirstField() {
        guard let first = keys.first else { return }
        fields[first.field]?.becomeFirstResponder()
    }

    // MARK: - Rows

    private func makeTextField(accessibility: String, placeholder: String, secure: Bool, url: Bool) -> UITextField {
        let field = UITextField()
        field.font = .systemFont(ofSize: 16.5)
        field.adjustsFontForContentSizeCategory = false
        field.autocapitalizationType = .none
        field.autocorrectionType = .no
        field.spellCheckingType = .no
        field.smartDashesType = .no
        field.smartQuotesType = .no
        field.clearButtonMode = .whileEditing
        field.isSecureTextEntry = secure
        field.accessibilityLabel = accessibility
        field.placeholder = placeholder
        field.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        if url {
            field.textContentType = .URL
        }
        return field
    }

    /// A row with its name at a fixed 88 points, as the design draws it, and
    /// the field taking the rest.
    private func makeKeyedCell(title: String, field: UITextField) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.selectionStyle = .none
        cell.isAccessibilityElement = false

        let key = UILabel()
        key.text = title
        key.numberOfLines = 0
        key.font = .systemFont(ofSize: 16.5)
        key.adjustsFontForContentSizeCategory = false
        key.setContentHuggingPriority(.required, for: .horizontal)
        key.setContentCompressionResistancePriority(.required, for: .horizontal)
        key.translatesAutoresizingMaskIntoConstraints = false
        key.widthAnchor.constraint(equalToConstant: 88).isActive = true

        let row = UIStackView(arrangedSubviews: [key, field])
        row.axis = .horizontal
        row.spacing = 10
        row.alignment = .center
        row.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(row)
        NSLayoutConstraint.activate([
            row.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
            row.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
            row.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 11),
            row.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -11),
            cell.contentView.heightAnchor.constraint(greaterThanOrEqualToConstant: 46),
        ])
        return cell
    }

    /// A row that reads out a value. Tapping it opens a choice — the whole
    /// table routes through `didSelectRowAt`, so the cell only has to look
    /// the part.
    private func makeValueCell(title: String, value: String?) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var content = UIListContentConfiguration.valueCell()
        content.text = title
        content.textProperties.font = .systemFont(ofSize: 16.5)
        content.secondaryText = value
        content.secondaryTextProperties.font = .systemFont(ofSize: 16.5)
        content.secondaryTextProperties.color = .secondaryLabel
        cell.contentConfiguration = content
        cell.accessoryType = .disclosureIndicator
        cell.selectionStyle = .default
        cell.accessibilityTraits.insert(.button)
        cell.accessibilityLabel = title
        cell.accessibilityValue = value
        return cell
    }

    private func makeAPIFormatCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.selectionStyle = .none
        let title = UILabel()
        title.text = String(localized: "API Format")
        title.font = .systemFont(ofSize: 16.5)
        title.adjustsFontForContentSizeCategory = false
        let control = UISegmentedControl(items: AgentAPIFormat.allCases.map(\.localizedDisplayTitle))
        control.selectedSegmentIndex = AgentAPIFormat.allCases.firstIndex(of: apiFormat) ?? 0
        control.accessibilityLabel = String(localized: "API Format")
        control.accessibilityValue = apiFormat.localizedDisplayTitle
        control.addAction(UIAction { [weak self, weak control] _ in
            guard let self, let control,
                  AgentAPIFormat.allCases.indices.contains(control.selectedSegmentIndex)
            else { return }
            apiFormat = AgentAPIFormat.allCases[control.selectedSegmentIndex]
            control.accessibilityValue = apiFormat.localizedDisplayTitle
        }, for: .valueChanged)
        apiFormatControl = control
        let stack = UIStackView(arrangedSubviews: [title, control])
        stack.axis = .vertical
        stack.spacing = 8
        stack.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
            stack.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 10),
            stack.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -10),
            control.heightAnchor.constraint(greaterThanOrEqualToConstant: 32),
        ])
        return cell
    }

    private func makeTintCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.selectionStyle = .none
        cell.isAccessibilityElement = false

        let picker = ProviderTintPicker(index: tintIndex)
        picker.onPick = { [weak self] index in self?.select(tint: index) }
        picker.translatesAutoresizingMaskIntoConstraints = false

        let key = UILabel()
        key.text = String(localized: "Color")
        key.font = .systemFont(ofSize: 16.5)
        key.adjustsFontForContentSizeCategory = false
        key.setContentHuggingPriority(.required, for: .horizontal)
        key.translatesAutoresizingMaskIntoConstraints = false
        key.widthAnchor.constraint(equalToConstant: 88).isActive = true

        let row = UIStackView(arrangedSubviews: [key, UIView(), picker])
        row.axis = .horizontal
        row.spacing = 10
        row.alignment = .center
        row.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(row)
        NSLayoutConstraint.activate([
            row.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
            row.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
            row.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 10),
            row.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -10),
            cell.contentView.heightAnchor.constraint(greaterThanOrEqualToConstant: 46),
        ])
        tintRow = picker
        return cell
    }

    private func makeBalanceCells() {
        let toggle = UISwitch()
        toggle.isOn = meta.balanceEnabled
        toggle.addAction(UIAction { [weak self] _ in
            guard let self else { return }
            meta.balanceEnabled = toggle.isOn
            onBalanceSettingsChange?(meta)
        }, for: .valueChanged)
        balanceSwitch = toggle

        let toggleCell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var toggleContent = UIListContentConfiguration.valueCell()
        toggleContent.text = String(localized: "Enabled")
        toggleContent.textProperties.font = .systemFont(ofSize: 16.5)
        toggleCell.contentConfiguration = toggleContent
        toggleCell.selectionStyle = .none
        toggleCell.accessoryView = toggle
        // `balanceSwitchCell` is the same cell the row asks for later
        balanceSwitchCell = toggleCell

        protocolCell = makeValueCell(
            title: String(localized: "Protocol"),
            value: ProviderBalanceProtocol.title(meta.balanceProtocol),
        )
        refreshCell = makeValueCell(
            title: String(localized: "Refresh"),
            value: Self.refreshTitle(meta.refreshMinutes),
        )

        let warn = makeTextField(
            accessibility: String(localized: "Warning Threshold"),
            placeholder: "5.00",
            secure: false,
            url: false,
        )
        warn.keyboardType = .decimalPad
        warn.text = String(format: "%.2f", meta.warnThreshold)
        warn.addAction(UIAction { [weak self] _ in
            guard let self, let text = warn.text, let value = Double(text) else { return }
            meta.warnThreshold = value
            onBalanceSettingsChange?(meta)
        }, for: .editingDidEnd)
        warnField = warn
        warnCell = makeKeyedCell(title: String(localized: "Warning Threshold"), field: warn)
    }

    private var balanceSwitchCell: UITableViewCell?

    private var groupTitle: String? {
        ProviderGroup.title(meta.group)
    }

    private static func refreshTitle(_ minutes: Int) -> String {
        switch minutes {
        case 0: String(localized: "Never")
        case 15: String(localized: "Every 15 minutes")
        case 30: String(localized: "Every 30 minutes")
        case 60: String(localized: "Every hour")
        case 120: String(localized: "Every 2 hours")
        default: String(localized: "Every \(minutes) minutes")
        }
    }

    // MARK: - Choosing

    private func chooseGroup() {
        presentChoice(
            title: String(localized: "Group"),
            options: [String?](arrayLiteral: nil) + ProviderGroup.all.map { Optional($0) },
            current: meta.group,
            label: { ProviderGroup.title($0) ?? String(localized: "None") },
        ) { [weak self] picked in
            guard let self else { return }
            meta.group = picked
            refresh(groupCell, value: groupTitle)
            onGroupChange?(picked)
        }
    }

    private func chooseProtocol() {
        presentChoice(
            title: String(localized: "Protocol"),
            options: ProviderBalanceProtocol.all,
            current: meta.balanceProtocol,
            label: { ProviderBalanceProtocol.title($0) },
        ) { [weak self] picked in
            guard let self else { return }
            meta.balanceProtocol = picked
            refresh(protocolCell, value: ProviderBalanceProtocol.title(picked))
            onBalanceSettingsChange?(meta)
        }
    }

    private func chooseRefresh() {
        presentChoice(
            title: String(localized: "Refresh"),
            options: [0, 15, 30, 60, 120],
            current: meta.refreshMinutes,
            label: { Self.refreshTitle($0) },
        ) { [weak self] picked in
            guard let self else { return }
            meta.refreshMinutes = picked
            refresh(refreshCell, value: Self.refreshTitle(meta.refreshMinutes))
            onBalanceSettingsChange?(meta)
        }
    }

    /// A sheet of words, one ticked. Used for every choice here so they all
    /// behave the same way and none of them needs its own menu plumbing.
    private func presentChoice<Value: Equatable>(
        title: String,
        options: [Value],
        current _: Value,
        label: @escaping (Value) -> String,
        pick: @escaping (Value) -> Void,
    ) {
        let sheet = UIAlertController(title: title, message: nil, preferredStyle: .actionSheet)
        for option in options {
            // the row behind the sheet already reads out the current value,
            // so no tick is needed to say which one it is
            sheet.addAction(UIAlertAction(title: label(option), style: .default) { _ in pick(option) })
        }
        sheet.addAction(UIAlertAction(title: String(localized: "Cancel"), style: .cancel))
        sheet.popoverPresentationController?.sourceView = view
        sheet.popoverPresentationController?.sourceRect = CGRect(
            x: view.bounds.midX, y: view.bounds.midY, width: 0, height: 0,
        )
        present(sheet, animated: true)
    }

    private func refresh(_ cell: UITableViewCell?, value: String?) {
        guard let cell, var content = cell.contentConfiguration as? UIListContentConfiguration else { return }
        content.secondaryText = value
        cell.contentConfiguration = content
    }

    private var values: [AgentSignInField: String] {
        // The model selector owns defaultModel; editing a key or endpoint
        // must preserve that saved field even though this form hides it.
        var result: [AgentSignInField: String] = [:]
        if let defaultModelID {
            result[.defaultModel] = defaultModelID
        }
        if offersAPIFormat {
            result[.apiFormat] = apiFormat.rawValue
        }
        if let relayConfigurationText {
            result[.relayConfiguration] = relayConfigurationText
        }
        return result.merging(fields.mapValues { $0.text ?? "" }) { _, edited in edited }
    }

    /// What the fields hold right now, for a test that needs the key before
    /// the form has been sent anywhere.
    var draftValues: [AgentSignInField: String] {
        values
    }

    func useTestedModel(_ modelID: String) {
        defaultModelID = modelID
    }

    @objc private dynamic var isReady: Bool {
        keys.allSatisfy {
            !$0.required || !(fields[$0.field]?.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
    }

    @objc private dynamic func updateSubmit() {
        submitItem.isEnabled = isReady && !isSubmitting && !isTestingConnection
        tableView.isUserInteractionEnabled = !isSubmitting && !isTestingConnection
        fields.values.forEach { $0.isEnabled = !isSubmitting && !isTestingConnection }
        balanceSwitch?.isEnabled = !isSubmitting && !isTestingConnection
        warnField?.isEnabled = !isSubmitting && !isTestingConnection
        tableView.visibleCells.forEach { $0.isUserInteractionEnabled = !isSubmitting && !isTestingConnection }
        // a name is not required, so it cannot make the form ready or not
        labelField?.isEnabled = !isSubmitting && !isTestingConnection
        apiFormatControl?.isEnabled = !isSubmitting && !isTestingConnection
        if isTestingConnection {
            testSpinner.startAnimating()
        } else {
            testSpinner.stopAnimating()
        }
    }

    @objc private dynamic func advance(from index: Int) {
        if index + 1 < keys.count {
            fields[keys[index + 1].field]?.becomeFirstResponder()
        } else {
            submit()
        }
    }

    @objc private dynamic func submit() {
        guard isReady, !isSubmitting else { return }
        view.endEditing(true)
        if showsLabel {
            onLabelChange?(labelField?.text ?? "")
        }
        onSubmit?(values)
    }

    private func cell(for row: Row) -> UITableViewCell? {
        switch row {
        case .label: labelCell
        case .tint: tintCell
        case .group: groupCell
        case .relayAccounts:
            makeValueCell(title: String(localized: "Accounts & API Groups"), value: nil)
        case .platform: platformCell()
        case .apiFormat: apiFormatCell
        case let .field(field): cells[field]
        case .balanceEnabled: balanceSwitchCell
        case .balanceProtocol: protocolCell
        case .balanceRefresh: refreshCell
        case .balanceWarn: warnCell
        case .test: testCell
        case .delete: actionCell(String(localized: "Delete Instance"), tint: .systemRed)
        case let .method(method): methodCell(method)
        }
    }

    private func platformCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        var content = UIListContentConfiguration.valueCell()
        content.text = String(localized: "Platform")
        content.textProperties.font = .systemFont(ofSize: 16.5)
        content.secondaryText = platformName
        content.secondaryTextProperties.font = .systemFont(ofSize: 16.5)
        content.secondaryTextProperties.color = .secondaryLabel
        cell.contentConfiguration = content
        cell.selectionStyle = .none
        return cell
    }

    private func methodCell(_ method: AgentSignInMethod) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        var content = cell.defaultContentConfiguration()
        content.text = method.switchTitle
        content.textProperties.color = .tintColor
        content.textProperties.font = .systemFont(ofSize: 16.5)
        cell.contentConfiguration = content
        cell.accessibilityTraits.insert(.button)
        return cell
    }

    private func actionCell(_ title: String, tint: UIColor) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        var content = cell.defaultContentConfiguration()
        content.text = title
        content.textProperties.color = tint
        content.textProperties.font = .systemFont(ofSize: 16.5, weight: .medium)
        content.textProperties.alignment = .center
        cell.contentConfiguration = content
        cell.accessibilityTraits.insert(.button)
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard let row = dataSource.value(at: indexPath) else { return }
        switch row {
        case .label: labelField?.becomeFirstResponder()
        case .tint: break // the swatches are buttons of their own
        case .group: chooseGroup()
        case .relayAccounts: editRelayAccounts()
        case .platform: break
        case let .field(field): fields[field]?.becomeFirstResponder()
        case .apiFormat, .balanceEnabled: break
        case .balanceProtocol: chooseProtocol()
        case .balanceRefresh: chooseRefresh()
        case .balanceWarn: warnField?.becomeFirstResponder()
        case .test:
            guard !isSubmitting, !isTestingConnection else { return }
            view.endEditing(true)
            onTestConnection?()
        case .delete:
            confirmDelete()
        case let .method(method):
            if !isSubmitting {
                onSwitchMethod?(method)
            }
        }
    }

    private func confirmDelete() {
        let alert = UIAlertController(
            title: String(localized: "Delete Instance?"),
            message: String(localized: "Agent sessions that use it stop working until you add it again."),
            preferredStyle: .alert,
        )
        alert.addAction(UIAlertAction(title: String(localized: "Cancel"), style: .cancel))
        alert.addAction(UIAlertAction(title: String(localized: "Delete"), style: .destructive) { [weak self] _ in
            self?.onDelete?()
        })
        present(alert, animated: true)
    }

    @objc private dynamic func editRelayAccounts() {
        do {
            let configuration = try relayConfigurationText.map(AgentRelayConfiguration.decode) ?? AgentRelayConfiguration()
            let page = RelayConfigurationController(configuration: configuration, provider: provider, values: values) { [weak self] configuration in
                self?.relayConfigurationText = try? configuration.encoded()
            }
            navigationController?.pushViewController(page, animated: true)
        } catch {
            presentNotice(title: "Unable to Load Configuration", message: error.readableMessage)
        }
    }

    // MARK: - Colour

    private func select(tint index: Int?) {
        tintIndex = index
        tintRow?.select(index)
        onTintChange?(index)
    }
}

/// The five colours the design draws with, side by side, one ringed.
///
/// Drawn rather than listed in a menu: the design puts them in the row so a
/// colour is one tap away and the choice is visible without opening anything.
final class ProviderTintPicker: UIView {
    var onPick: ((Int?) -> Void)?

    private var buttons: [UIButton] = []
    private var selected: Int?

    init(index: Int?) {
        selected = index
        super.init(frame: .zero)
        let stack = UIStackView()
        stack.axis = .horizontal
        stack.spacing = 9
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)
        for (position, tone) in ProviderTint.palette.enumerated() {
            let button = UIButton(type: .custom)
            button.tag = position
            button.setImage(Self.dot(tone), for: .normal)
            button.accessibilityLabel = String(localized: "Color \(position + 1)")
            button.addAction(UIAction { [weak self] _ in self?.onPick?(position) }, for: .touchUpInside)
            button.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                button.widthAnchor.constraint(equalToConstant: 30),
                button.heightAnchor.constraint(equalToConstant: 30),
            ])
            buttons.append(button)
            stack.addArrangedSubview(button)
        }
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: trailingAnchor),
            stack.topAnchor.constraint(equalTo: topAnchor),
            stack.bottomAnchor.constraint(equalTo: bottomAnchor),
            heightAnchor.constraint(equalToConstant: 30),
        ])
        select(index)
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    func select(_ index: Int?) {
        selected = index
        for (position, button) in buttons.enumerated() {
            button.setImage(position == index ? Self.dot(ProviderTint.palette[position], ringed: true)
                : Self.dot(ProviderTint.palette[position]), for: .normal)
            button.accessibilityTraits = position == index ? [.button, .selected] : .button
        }
    }

    /// One swatch: a gradient disc, with the design's ring around the chosen
    /// one — the ring is drawn inside the 30-point button so nothing clips.
    private static func dot(_ tone: ProviderTint.Tone, ringed: Bool = false) -> UIImage {
        let size = CGSize(width: 30, height: 30)
        let image = UIGraphicsImageRenderer(size: size).image { context in
            let inset: CGFloat = ringed ? 4 : 1
            let rect = CGRect(origin: .zero, size: size).insetBy(dx: inset, dy: inset)
            let path = UIBezierPath(ovalIn: rect)
            context.cgContext.saveGState()
            path.addClip()
            let colours = [tone.top.cgColor, tone.bottom.cgColor] as CFArray
            if let gradient = CGGradient(
                colorsSpace: CGColorSpaceCreateDeviceRGB(),
                colors: colours,
                locations: [0, 1],
            ) {
                context.cgContext.drawLinearGradient(
                    gradient,
                    start: CGPoint(x: 0, y: 0),
                    end: CGPoint(x: size.width, y: size.height),
                    options: [],
                )
            }
            context.cgContext.restoreGState()
            if ringed {
                UIColor.label.setStroke()
                let ring = UIBezierPath(ovalIn: rect.insetBy(dx: -3, dy: -3))
                ring.lineWidth = 2
                ring.stroke()
            }
        }
        return image.withRenderingMode(.alwaysOriginal)
    }
}
