import Foundation

/// What an endpoint's balance was on a given day.
///
/// Kept because the only useful thing to say about a remaining amount is how
/// fast it is going: a bar per day is what turns `¥42.80` into a burn rate.
/// One entry per day, overwritten as the day goes on.
struct ProviderBalanceSnapshot: Codable, Equatable {
    /// `yyyy-MM-dd` in the device's own calendar: a day is what the person
    /// reading it calls a day.
    let day: String
    let remaining: Double
    let currency: String
    /// Optional so snapshots written before the refresh cache was added still decode.
    var updatedAt: Date? = nil
}

enum ProviderBalanceHistory {
    private static let storageKey = "provider.balance.history"
    private static let cacheStorageKey = "provider.balance.cache"

    private struct CacheEntry: Codable {
        var text: String
        var updatedAt: Date
    }

    private static var cachedEntries: [String: CacheEntry] {
        guard let data = UserDefaults.standard.data(forKey: cacheStorageKey),
              let decoded = try? JSONDecoder().decode([String: CacheEntry].self, from: data)
        else { return [:] }
        return decoded
    }

    static func cache(_ balance: ProviderBalance, for identity: String) {
        var entries = cachedEntries
        for legacy in Array(entries.keys) where legacy != identity && canonicalStoredIdentity(legacy) == identity {
            entries[legacy] = nil
        }
        entries[identity] = CacheEntry(text: ProviderBalanceLookup.displayText(for: balance), updatedAt: Date())
        guard let data = try? JSONEncoder().encode(entries) else { return }
        UserDefaults.standard.set(data, forKey: cacheStorageKey)
        if !balance.unlimited {
            record(balance, for: identity)
        }
    }

    static func cachedText(_ identity: String) -> String? {
        cachedEntry(for: identity)?.text
    }

    static func needsRefresh(_ identity: String, every minutes: Int) -> Bool {
        guard minutes > 0 else { return false }
        guard let updatedAt = cachedEntry(for: identity)?.updatedAt else { return true }
        return Date().timeIntervalSince(updatedAt) >= TimeInterval(minutes) * 60
    }

    private static func cachedEntry(for identity: String) -> CacheEntry? {
        let entries = cachedEntries
        if let entry = entries[identity] {
            return entry
        }
        let legacy = entries
            .filter { canonicalStoredIdentity($0.key) == identity }
            .max { $0.value.updatedAt < $1.value.updatedAt }
        return legacy?.value
    }

    /// A full month and its opening balance must survive until month end.
    private static let keepDays = 93

    private static var all: [String: [ProviderBalanceSnapshot]] {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([String: [ProviderBalanceSnapshot]].self, from: data)
        else { return [:] }
        return decoded
    }

    /// The account list carries an endpoint's host and provider ID, while the
    /// detail screen has its full base URL. Path and port are omitted here so
    /// both views address the same credential identity.
    static func identity(providerRawValue: String, baseURL: String, accountID: String? = nil) -> String {
        let baseURL = baseURL.trimmingCharacters(in: .whitespacesAndNewlines)
        let candidate = baseURL.contains("://") ? baseURL : "https://" + baseURL
        guard let components = URLComponents(string: candidate),
              let host = components.host?.lowercased(), !host.isEmpty
        else { return providerRawValue }

        let account = accountID.flatMap { $0 == "primary" ? nil : $0 }
        return "\(providerRawValue)|\(host)" + (account.map { "#account=\($0)" } ?? "")
    }

    private static func canonicalStoredIdentity(_ stored: String) -> String? {
        guard let separator = stored.firstIndex(of: "|") else { return nil }
        let provider = String(stored[..<separator])
        let endpoint = String(stored[stored.index(after: separator)...])
        guard !endpoint.isEmpty else { return nil }
        if let split = endpoint.range(of: "#account=") {
            return identity(
                providerRawValue: provider, baseURL: String(endpoint[..<split.lowerBound]),
                accountID: String(endpoint[split.upperBound...]),
            )
        }
        return identity(providerRawValue: provider, baseURL: endpoint)
    }

    static func record(_ balance: ProviderBalance, for identity: String) {
        var every = all
        var entries = snapshots(for: identity)
        for legacy in Array(every.keys) where legacy != identity && canonicalStoredIdentity(legacy) == identity {
            every[legacy] = nil
        }
        let today = Self.dayKey(for: Date())
        let snapshot = ProviderBalanceSnapshot(
            day: today,
            remaining: balance.remaining,
            currency: balance.unit == .quota ? "quota" : balance.currency,
            updatedAt: Date(),
        )
        if let index = entries.firstIndex(where: { $0.day == today }) {
            entries[index] = snapshot
        } else {
            entries.append(snapshot)
        }
        entries.sort { $0.day < $1.day }
        if entries.count > keepDays {
            entries.removeFirst(entries.count - keepDays)
        }
        every[identity] = entries
        guard let data = try? JSONEncoder().encode(every) else { return }
        UserDefaults.standard.set(data, forKey: storageKey)
    }

    private static func snapshots(for identity: String) -> [ProviderBalanceSnapshot] {
        let entries = all.filter { stored, _ in canonicalStoredIdentity(stored) == identity }
            .values.flatMap(\.self)
        let byDay = Dictionary(entries.map { ($0.day + "|" + $0.currency, $0) }, uniquingKeysWith: { first, second in
            (first.updatedAt ?? .distantPast) > (second.updatedAt ?? .distantPast) ? first : second
        })
        return byDay.values.sorted { $0.day < $1.day }
    }

    static func latest(_ identity: String) -> ProviderBalanceSnapshot? {
        snapshots(for: identity).max { $0.day < $1.day }
    }

    static func summary(_ snapshot: ProviderBalanceSnapshot) -> String {
        if snapshot.currency == "quota" {
            let formatter = NumberFormatter()
            formatter.numberStyle = .decimal
            formatter.maximumFractionDigits = 2
            return "\(formatter.string(from: NSNumber(value: snapshot.remaining)) ?? "\(snapshot.remaining)") quota"
        }
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = snapshot.currency
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2
        return formatter.string(from: NSNumber(value: snapshot.remaining))
            ?? "\(snapshot.currency) \(snapshot.remaining)"
    }

    /// The last `days` days, oldest first, with a `nil` for a day nothing was
    /// recorded — a gap is a gap, not a zero.
    static func recent(_ identity: String, days: Int, currency: String? = nil) -> [ProviderBalanceSnapshot?] {
        let entries = snapshots(for: identity).filter { currency == nil || $0.currency == currency }
        let byDay = Dictionary(entries.map { ($0.day, $0) }, uniquingKeysWith: { _, last in last })
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        return (0 ..< days).reversed().map { offset in
            guard let date = calendar.date(byAdding: .day, value: -offset, to: today) else { return nil }
            return byDay[Self.dayKey(for: date)]
        }
    }

    /// What was spent today, when yesterday is known. `nil` on the first day,
    /// where there is nothing to compare against and a guess would be worse
    /// than a dash.
    static func spentToday(_ identity: String, currency: String? = nil) -> Double? {
        let entries = snapshots(for: identity).filter { currency == nil || $0.currency == currency }
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        guard let yesterday = calendar.date(byAdding: .day, value: -1, to: today),
              let previous = entries.first(where: { $0.day == Self.dayKey(for: yesterday) }),
              let current = entries.first(where: { $0.day == Self.dayKey(for: today) })
        else { return nil }
        return max(0, previous.remaining - current.remaining)
    }

    /// Estimated spend from observed balance decreases this month. Increases
    /// are top-ups, not negative spending. Unobserved intra-day use/top-ups
    /// cannot be reconstructed from a balance-only endpoint.
    static func spentThisMonth(_ identity: String, currency: String? = nil) -> Double? {
        let entries = snapshots(for: identity).filter { currency == nil || $0.currency == currency }
        let calendar = Calendar.current
        let now = Date()
        guard let firstOfMonth = calendar.date(from: calendar.dateComponents([.year, .month], from: now))
        else { return nil }
        let start = calendar.startOfDay(for: firstOfMonth)
        var observations = entries.filter { entry in
            guard let date = Self.date(from: entry.day) else { return false }
            return date >= start && date <= now
        }
        // Only the previous calendar day's close is a valid month opening.
        if let previousDay = calendar.date(byAdding: .day, value: -1, to: start),
           let opening = entries.last(where: { $0.day == Self.dayKey(for: previousDay) })
        {
            observations.insert(opening, at: 0)
        }
        guard observations.count >= 2 else { return nil }
        return zip(observations, observations.dropFirst()).reduce(0) { spent, pair in
            guard pair.0.currency == pair.1.currency else { return spent }
            return spent + max(0, pair.0.remaining - pair.1.remaining)
        }
    }

    /// `11/10` — the design's axis label, short enough for seven of them.
    static func axisLabel(for offsetFromToday: Int) -> String {
        let calendar = Calendar.current
        guard let date = calendar.date(byAdding: .day, value: -offsetFromToday, to: Date()) else { return "" }
        let formatter = DateFormatter()
        formatter.setLocalizedDateFormatFromTemplate("Md")
        return formatter.string(from: date)
    }

    private static func dayKey(for date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }

    private static func date(from key: String) -> Date? {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.date(from: key)
    }
}
