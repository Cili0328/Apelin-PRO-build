import ApelinProtocol
import Then
import UIKit

/// Settings ▸ Model Providers: every provider apelin-agent can sign in to,
/// in Apelin's display order. Signed-in ones first, each with who
/// it is signed in as under its name and a `…` menu (Edit Configuration or Sign In Again, Sign
/// Out); then the rest, those signed in to with an account apart from those
/// that take a typed key. A search field narrows the list by name. The
/// OpenAI-compatible login is there once for each endpoint signed in to,
/// told apart by its host, and once more among the keys to add another.
final class ModelProvidersController: TableController, UISearchResultsUpdating {
    private enum Group: Hashable {
        case signedIn
        case keys

        var title: String {
            switch self {
            case .signedIn: String(localized: "Signed In")
            case .keys: String(localized: "Add a Provider")
            }
        }
    }

    private enum Status: Equatable {
        case loading
        case unavailable(String)
        case noResults
    }

    private enum Section: Hashable {
        case group(Group)
        case status
    }

    private enum Row: Equatable {
        case account(AgentAccount)
        case status(Status)
        var id: String {
            switch self {
            case let .account(account): account.provider.rawValue
            case .status: "status"
            }
        }
    }

    private lazy var dataSource = TableDataSource<Section, String, Row>(
        tableView: tableView,
        identifier: { $0.id },
    ) { [weak self] _, _, row in
        guard let self else { return nil }
        switch row {
        case let .account(account): return accountCell(account)
        case let .status(status): return statusCell(status)
        }
    }

    /// The accounts as apelin-agent last listed them.
    private var accounts: [AgentAccount] = []
    @objc private dynamic var loaded = false
    @objc private dynamic var failure: Error?
    @objc private dynamic var query = ""
    private var sections: [(Section, [Row])] = [(.status, [.status(.loading)])]
    private var loader: Task<Void, Never>?
    /// What each endpoint said was left on its key, by `rawValue`. Kept for
    /// the life of this screen so a row can be redrawn from it without asking
    /// again.
    private var balances: [String: BalanceState] = [:]
    private var balanceLoader: Task<Void, Never>?
    private let search = UISearchController(searchResultsController: nil)

    /// What tells one row's balance from another's.
    ///
    /// A platform is not an account: every relay on the OpenAI-compatible
    /// shelf shares one `provider.rawValue`, so keying by it let the last
    /// answer overwrite the first and left one row showing another relay's
    /// number. The host is what distinguishes an endpoint without a secret,
    /// which is exactly what a balance belongs to.
    private static func balanceKey(for account: AgentAccount) -> String {
        ProviderBalanceHistory.identity(
            providerRawValue: account.provider.rawValue,
            baseURL: account.account ?? "",
        )
    }

    /// What asking one endpoint came back with.
    private enum BalanceState {
        case checking
        case balance(ProviderBalance)
        /// The route answered, with nothing in it that reads as a balance.
        case unsupported
        /// The ask itself did not get through.
        case failed
    }

    init() {
        super.init(style: .insetGrouped)
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    deinit {
        loader?.cancel()
        balanceLoader?.cancel()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = String(localized: "Model Providers")
        navigationItem.backButtonDisplayMode = .minimal
        search.searchResultsUpdater = self
        search.obscuresBackgroundDuringPresentation = false
        search.searchBar.placeholder = String(localized: "Search tags, platforms or hosts")
        search.searchBar.autocapitalizationType = .none
        navigationItem.searchController = search
        navigationItem.hidesSearchBarWhenScrolling = false
        definesPresentationContext = true
        dataSource.headerTitle = { [weak self] section in
            guard case let .group(group) = section else { return nil }
            // the design counts what is under the heading: four connected
            // endpoints is a fact worth reading before the rows
            let count = self?.sections.first { $0.0 == section }?.1.count ?? 0
            return "\(group.title) · \(count)"
        }
        dataSource.footerTitle = { [weak self] section in
            guard let self, section == sections.last?.0, case .group = section else { return nil }
            // kwwk signs in and talks to every provider here: its version
            // is what a report about one needs.
            guard let kwwk = LinkedPackage.kwwkVersion else {
                return String(localized: "Credentials stay in this device’s keychain.")
            }
            return String(localized: "Credentials stay in this device’s keychain. Currently using kwwk \(kwwk).")
        }
        dataSource.update(sections)
        updateNewInstanceButton()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        load()
    }

    @objc(apelin_load) private dynamic func load() {
        loader?.cancel()
        dataSource.beginLoad()
        loader = Task { [weak self] in
            do {
                let list = try await ApelinService.app.agentAccountList()
                guard !Task.isCancelled, let self else { return }
                accounts = list.accounts
                failure = nil
            } catch {
                guard !Task.isCancelled, let self else { return }
                failure = error
            }
            guard let self else { return }
            loaded = true
            regroup()
            loadBalances()
        }
    }

    /// Asks each signed-in endpoint what is left on its key, and fills the
    /// pills in as the answers arrive.
    ///
    /// One at a time, not all at once: these are somebody else's servers, and
    /// six parallel requests every time the list appears is how a screen ends
    /// up rate limited. An answer stays for the life of the screen, so coming
    /// back from a row asks nothing.
    private func loadBalances() {
        balanceLoader?.cancel()
        let endpoints = accounts.filter {
            $0.signedIn
                && $0.provider.kind == .openAICompatible
                && ProviderMetaStore.meta(for: $0.provider.rawValue).balanceEnabled
        }
        let wanted = Set(endpoints.map { Self.balanceKey(for: $0) })
        balances = balances.filter { wanted.contains($0.key) }
        guard !endpoints.isEmpty else { return }
        balanceLoader = Task { [weak self] in
            for account in endpoints {
                guard !Task.isCancelled, let self else { return }
                let state = await askBalance(account)
                guard !Task.isCancelled else { return }
                let key = Self.balanceKey(for: account)
                balances[key] = state
                if case let .balance(balance) = state {
                    ProviderBalanceHistory.cache(balance, for: key)
                }
                // TableDataSource reconfigures using row identifiers, not the
                // private cache key that separates endpoint balances.
                rebuild(changed: [account.provider.rawValue])
            }
        }
    }

    private func askBalance(_ account: AgentAccount) async -> BalanceState {
        do {
            let configuration = try await ApelinService.app.agentAPIConfiguration(
                provider: account.provider,
            )
            let key = (configuration.values["apiKey"] ?? "")
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let base = (configuration.values["baseUrl"] ?? "")
                .trimmingCharacters(in: .whitespacesAndNewlines)
            guard !key.isEmpty, !base.isEmpty else { return .unsupported }
            return .balance(try await ProviderBalanceLookup.fetch(
                baseURL: base,
                apiKey: key,
                using: ProviderMetaStore.meta(for: account.provider.rawValue).balanceProtocol,
            ))
        } catch ProviderBalanceError.unsupported {
            return .unsupported
        } catch {
            return .failed
        }
    }

    @objc dynamic func updateSearchResults(for searchController: UISearchController) {
        let text = (searchController.searchBar.text ?? "").trimmingCharacters(in: .whitespaces)
        guard text != query else { return }
        query = text
        regroup()
    }

    @objc private dynamic func regroup() {
        rebuild(changed: [])
    }

    /// Rebuilds the sections. `changed` names rows whose visible text changed
    /// while their identity did not: a name lives outside the account, so the
    /// snapshot comes out identical and only this can redraw the row.
    private func rebuild(changed: Set<String>) {
        if !loaded {
            sections = [(.status, [.status(.loading)])]
        } else if let failure, accounts.isEmpty {
            sections = [(.status, [.status(.unavailable(ProviderLoginController.unavailableText(failure)))])]
        } else {
            let shown = query.isEmpty
                ? accounts
                : accounts.filter {
                    // a name the person gave an endpoint is what they will
                    // search for; the provider's own name still matches, and
                    // so does the host it was signed in to
                    ProviderLabel.displayName(of: $0.provider).localizedStandardContains(query)
                        || ($0.account ?? "").localizedStandardContains(query)
                        || (ProviderGroup.title(ProviderMetaStore.meta(for: $0.provider.rawValue).group)?
                            .localizedStandardContains(query) ?? false)
                }
            // Two shelves, as the design draws them: what is connected, and
            // what can be. A provider that takes an account rather than a key
            // is still something to add, so it sits with the keys.
            let groups: [(Group, [AgentAccount])] = [
                (.signedIn, shown.filter(\.signedIn)),
                (.keys, shown.filter { !$0.signedIn }),
            ]
            sections = groups.filter { !$0.1.isEmpty }.map { (.group($0.0), $0.1.map(Row.account)) }
            if sections.isEmpty {
                sections = [(.status, [.status(.noResults)])]
            }
        }
        dataSource.update(sections, changedItems: changed)
        updateNewInstanceButton()
    }

    private func account(at indexPath: IndexPath) -> AgentAccount? {
        guard case let .account(account)? = dataSource.value(at: indexPath) else { return nil }
        return account
    }

    private func statusCell(_ status: Status) -> UITableViewCell {
        switch status {
        case .loading:
            return WaitingCell().then { $0.show(String(localized: "Loading…")) }
        case let .unavailable(message):
            let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
            var content = UIListContentConfiguration.stackedValueCell()
            content.text = String(localized: "Model Providers Unavailable")
            content.secondaryText = message
            content.secondaryTextProperties.color = .secondaryLabel

            cell.contentConfiguration = content
            cell.selectionStyle = .none
            return cell
        case .noResults:
            let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
            var content = UIListContentConfiguration.cell()
            content.text = String(localized: "No Results")
            content.textProperties.color = .secondaryLabel
            content.textProperties.alignment = .center
            cell.contentConfiguration = content
            cell.selectionStyle = .none
            return cell
        }
    }

    /// The mark, the name it answers to, what it points at, and a `…` menu at
    /// the end. A signed-in endpoint carries the name it was given with its
    /// host underneath; one that is only on offer keeps the provider's own
    /// name, so an empty slot cannot read as one that is already set up.
    ///
    /// The mark is drawn rather than the provider's artwork: several endpoints
    /// share one logo, and a colour plus the name's first character is what
    /// tells them apart before the host is read.
    private func accountCell(_ account: AgentAccount) -> UITableViewCell {
        let cell = ProviderAccountCell(style: .default, reuseIdentifier: ProviderAccountCell.reuseIdentifier)
        let name = account.signedIn
            ? ProviderLabel.displayName(of: account.provider)
            : account.provider.displayName
        cell.show(
            title: name,
            detail: Self.detailLine(account),
            initial: Self.initial(for: account),
            tone: ProviderTint.resolvedTone(for: account.provider.rawValue),
            group: account.signedIn
                ? ProviderGroup.title(ProviderMetaStore.meta(for: account.provider.rawValue).group)
                : nil,
            balance: balanceBadge(for: account),
        )
        if account.signedIn {
            cell.accessoryView = menuButton(account)
            cell.accessoryType = .none
            cell.selectionStyle = .none
        } else {
            cell.accessoryView = nil
            cell.accessoryType = .disclosureIndicator
            cell.selectionStyle = .default
        }
        return cell
    }

    /// What the row says under the name.
    ///
    /// An endpoint is known by its host — that is the whole difference between
    /// two relays on the same platform — so the host comes first and the name
    /// of the platform is left out: the mark already says it. Every other
    /// provider is known by its platform and who is signed in.
    private static func detailLine(_ account: AgentAccount) -> String {
        var parts: [String] = []
        let who = account.account ?? ""
        if account.provider.kind == .openAICompatible {
            // the design names the platform and then the host: two relays on
            // the same platform differ only in the second half
            parts.append(account.provider.displayName)
            if !who.isEmpty { parts.append(Self.host(of: who)) }
        } else if account.signedIn {
            parts.append(account.provider.displayName)
            if !who.isEmpty { parts.append(who) }
        } else {
            parts.append(account.provider.displayName)
        }
        if let expiresAt = account.expiresAt {
            let date = expiresAt.formatted(date: .abbreviated, time: .shortened)
            parts.append(expiresAt < Date() ? String(localized: "Expired \(date)") : String(localized: "Until \(date)"))
        }
        return parts.joined(separator: " · ")
    }

    /// `api.yunwu.ai` out of whatever address the endpoint was signed in to,
    /// which is the part a person recognises.
    private static func host(of address: String) -> String {
        guard let host = URL(string: address)?.host, !host.isEmpty else { return address }
        return host
    }

    /// The character the mark draws. A named endpoint draws the name's first;
    /// one that was never named draws its host's, because every unnamed
    /// endpoint shares one name and would otherwise be the same letter.
    private static func initial(for account: AgentAccount) -> String {
        if let name = ProviderLabel.name(of: account.provider) {
            return ProviderTint.initial(for: name)
        }
        if account.provider.kind == .openAICompatible, let who = account.account, !who.isEmpty {
            return ProviderTint.initial(for: Self.host(of: who))
        }
        return ProviderTint.initial(for: account.provider.displayName)
    }

    /// What the row draws in its balance pill, from what is already known.
    ///
    /// A check that was asked for and came back lands in `balances`; until
    /// then a row that can be asked says so, and a row that cannot says
    /// nothing rather than claim a number it does not have.
    private func balanceBadge(for account: AgentAccount) -> ProviderBalanceBadge {
        guard account.signedIn, account.provider.kind == .openAICompatible else { return .hidden }
        guard ProviderMetaStore.meta(for: account.provider.rawValue).balanceEnabled else { return .hidden }
        switch balances[Self.balanceKey(for: account)] {
        case let .some(.balance(balance)):
            if balance.unlimited { return .note("∞") }
            return Self.badge(for: balance)
        case .some(.checking):
            return .checking
        case .some(.unsupported):
            return .note(String(localized: "No Balance"))
        case .some(.failed):
            return .note(String(localized: "Unable to Connect"))
        case .none:
            return .checking
        }
    }

    private static func badge(for balance: ProviderBalance) -> ProviderBalanceBadge {
        let formatter = NumberFormatter()
        let text: String
        switch balance.unit {
        case .currency:
            formatter.numberStyle = .currency
            formatter.currencyCode = balance.currency
            formatter.minimumFractionDigits = 2
            formatter.maximumFractionDigits = 2
            text = formatter.string(from: NSNumber(value: balance.remaining))
                ?? "\(balance.currency) \(balance.remaining)"
        case .quota:
            formatter.numberStyle = .decimal
            formatter.minimumFractionDigits = 0
            formatter.maximumFractionDigits = 2
            let amount = formatter.string(from: NSNumber(value: balance.remaining)) ?? "\(balance.remaining)"
            text = "\(amount) quota"
        }
        return .amount(text, low: balance.remaining < 5)
    }

    /// `…` with no circle, its menu read each time it opens.
    private func menuButton(_ account: AgentAccount) -> UIButton {
        let button = UIButton(type: .system)
        button.setImage(UIImage(systemName: "ellipsis"), for: .normal)
        button.showsMenuAsPrimaryAction = true
        button.menu = UIMenu(children: [UIDeferredMenuElement.uncached { [weak self] completion in
            completion(self?.accountActions(account) ?? [])
        }])
        button.frame = CGRect(x: 0, y: 0, width: 32, height: 44)
        button.accessibilityLabel = String(localized: "\(ProviderLabel.displayName(of: account.provider)) Options")
        return button
    }

    private func accountActions(_ account: AgentAccount) -> [UIMenuElement] {
        var actions: [UIMenuElement] = [
            UIAction(
                title: String(localized: "Edit"),
                image: UIImage(systemName: account.isAPIKeyAccount ? "pencil" : "arrow.clockwise"),
            ) { [weak self] _ in
                self?.signIn(account)
            },
            UIAction(
                title: String(localized: "Models"),
                image: UIImage(systemName: "checklist"),
            ) { [weak self] _ in
                self?.presentPageAsFormSheet(ModelActivationController(account: account))
            },
        ]
        // Only an endpoint can be one of several sharing one name. Every other
        // provider is alone here, so a name would add nothing and would make
        // the name a bug report has to use harder to match.
        if account.provider.kind == .openAICompatible {
            actions.append(UIAction(
                title: String(localized: "Rename"),
                image: UIImage(systemName: "tag"),
            ) { [weak self] _ in
                self?.rename(account)
            })
            actions.append(UIAction(
                title: String(localized: "Balance"),
                image: UIImage(systemName: "creditcard"),
            ) { [weak self] _ in
                self?.checkBalance(account)
            })
        }
        actions.append(UIMenu(options: .displayInline, children: [
            UIAction(
                title: String(localized: "Sign Out"),
                image: UIImage(systemName: "rectangle.portrait.and.arrow.right"),
                attributes: .destructive,
            ) { [weak self] _ in
                self?.confirmSignOut(account)
            },
        ]))
        return actions
    }

    override func tableView(_: UITableView, shouldHighlightRowAt indexPath: IndexPath) -> Bool {
        account(at: indexPath).map { !$0.signedIn } ?? false
    }

    override func tableView(
        _: UITableView,
        contextMenuConfigurationForRowAt indexPath: IndexPath,
        point _: CGPoint,
    ) -> UIContextMenuConfiguration? {
        guard let account = account(at: indexPath), account.signedIn else { return nil }
        return UIContextMenuConfiguration(actionProvider: { [weak self] _ in
            UIMenu(children: self?.accountActions(account) ?? [])
        })
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard let account = account(at: indexPath), !account.signedIn else { return }
        signIn(account)
    }

    // MARK: - Acting

    /// The design's button under the list. It opens the same sign-in the last
    /// row does, one tap sooner: adding an endpoint is why anyone opens this
    /// screen with nothing to check.
    private lazy var newInstanceFooter: UIView = {
        let container = UIView(frame: CGRect(x: 0, y: 0, width: 0, height: 78))

        var configuration = UIButton.Configuration.tinted()
        var title = AttributedString(String(localized: "New Instance"))
        title.font = .systemFont(ofSize: 16.5, weight: .medium)
        configuration.attributedTitle = title
        configuration.image = UIImage(systemName: "plus")
        configuration.imagePadding = 7
        configuration.baseForegroundColor = .label
        configuration.baseBackgroundColor = .label
        configuration.cornerStyle = .fixed
        configuration.background.cornerRadius = 12
        configuration.contentInsets = NSDirectionalEdgeInsets(top: 0, leading: 0, bottom: 0, trailing: 0)

        let button = UIButton(configuration: configuration, primaryAction: UIAction { [weak self] _ in
            self?.startNewInstance()
        })
        button.translatesAutoresizingMaskIntoConstraints = false
        container.addSubview(button)
        NSLayoutConstraint.activate([
            button.leadingAnchor.constraint(equalTo: container.leadingAnchor, constant: 16),
            button.trailingAnchor.constraint(equalTo: container.trailingAnchor, constant: -16),
            button.topAnchor.constraint(equalTo: container.topAnchor, constant: 14),
            button.heightAnchor.constraint(equalToConstant: 50),
        ])
        return container
    }()

    /// The footer follows the list: with nothing left to add, or nothing
    /// listed yet, there is no button to press.
    private func updateNewInstanceButton() {
        let canAdd = accounts.contains { !$0.signedIn }
        tableView.tableFooterView = loaded && failure == nil && canAdd ? newInstanceFooter : nil
    }

    private func startNewInstance() {
        // an endpoint first: several relays on one platform is what this
        // screen exists for, and every one of them is the compatible list
        guard let account = accounts.first(where: { !$0.signedIn && $0.provider.kind == .openAICompatible })
            ?? accounts.first(where: { !$0.signedIn })
        else {
            presentNotice(title: "New Instance", message: "Every provider is already set up.")
            return
        }
        signIn(account)
    }

    private func signIn(_ account: AgentAccount) {
        let page = ProviderLoginController(account: account)
        page.onFinish = { [weak self] in self?.load() }
        // a sheet of its own over Settings, kept up until it is closed: a
        // stray swipe would end a sign-in waiting on Safari
        page.isModalInPresentation = true
        presentPageAsFormSheet(page)
    }

    /// An OpenAI-compatible endpoint answers to the name it was given, then
    /// to its host: there can be several, all with the provider's one name.
    private func confirmSignOut(_ account: AgentAccount) {
        let provider = account.provider
        let name = ProviderLabel.name(of: provider)
            ?? (provider.kind == .openAICompatible ? account.account : nil)
            ?? provider.displayName
        presentConfirmation(
            title: "Sign Out of \(name)?",
            message: "Agent sessions that use it stop working until you sign in again.",
            confirmTitle: "Sign Out",
            destructive: true,
        ) { [weak self] in
            self?.signOut(provider)
        }
    }

    private func signOut(_ provider: AgentProvider) {
        Task { [weak self] in
            do {
                try await ApelinService.app.agentSignOut(provider: provider)
                EnabledModels.remove(for: provider)
                self?.load()
            } catch {
                self?.presentNotice(title: "Unable to Sign Out", message: error.readableMessage)
            }
        }
    }

    /// Gives an endpoint a name of its own, or takes the name away again. The
    /// host stays under the name either way, so a name that turns out to be
    /// wrong is readable next to what it actually points at.
    private func rename(_ account: AgentAccount) {
        let alert = UIAlertController(title: String(localized: "Rename"), message: nil, preferredStyle: .alert)
        alert.addTextField { field in
            field.text = ProviderLabel.name(of: account.provider)
            field.placeholder = account.account ?? account.provider.displayName
            field.autocapitalizationType = .words
            field.clearButtonMode = .whileEditing
            field.accessibilityLabel = String(localized: "Name")
        }
        alert.addAction(UIAlertAction(title: String(localized: "Cancel"), style: .cancel))
        alert.addAction(UIAlertAction(title: String(localized: "Save"), style: .default) { [weak self, weak alert] _ in
            guard let self else { return }
            ProviderLabel.setName(alert?.textFields?.first?.text, for: account.provider)
            // The row keeps its identity — that is the provider — so the name
            // has to be named as the change or the cell is never drawn again.
            self.rebuild(changed: [account.provider.rawValue])
        })
        present(alert, animated: true)
    }

    /// What the endpoint says is left on the key this endpoint was signed in
    /// with.
    ///
    /// The key is read back through the same configuration the editing form
    /// opens with — it never leaves the host except to the provider it
    /// belongs to, and it is not written anywhere by this. A route that keeps
    /// balance behind a login answers nothing to a key, which is said as no
    /// balance rather than as a failure, so a relay that cannot be asked does
    /// not read as one that broke.
    private func checkBalance(_ account: AgentAccount) {
        Task { [weak self] in
            guard let self else { return }
            do {
                let configuration = try await ApelinService.app.agentAPIConfiguration(
                    provider: account.provider,
                )
                let key = (configuration.values["apiKey"] ?? "")
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                let base = (configuration.values["baseUrl"] ?? "")
                    .trimmingCharacters(in: .whitespacesAndNewlines)
                guard !key.isEmpty, !base.isEmpty else {
                    presentNotice(title: "Balance", message: "This endpoint does not report a balance.")
                    return
                }
                // a page, not an alert: the amount is worth seeing next to
                // what it is out of, and worth asking for again
                navigationController?.pushViewController(
                    ProviderBalanceScreen(
                        name: ProviderLabel.displayName(of: account.provider),
                        baseURL: base,
                        apiKey: key,
                        rawValue: account.provider.rawValue,
                        meta: ProviderMetaStore.meta(for: account.provider.rawValue),
                    ),
                    animated: true,
                )
            } catch {
                presentNotice(title: "Balance", message: "This endpoint does not report a balance.")
            }
        }
    }
}
