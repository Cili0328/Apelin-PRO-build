import UIKit

/// What a mark says before the name is read: a colour, and one character.
///
/// The shape is the design's: a small rounded square, 29 points, filled with a
/// two-stop gradient that runs corner to corner.
final class ProviderMarkView: UIView {
    private let gradient = CAGradientLayer()
    private let letter = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        layer.cornerRadius = 7.5
        layer.cornerCurve = .continuous
        layer.masksToBounds = true
        // the design's hairline, so a pale tone keeps an edge on a pale cell
        layer.borderWidth = 0.5
        layer.borderColor = UIColor.black.withAlphaComponent(0.08).cgColor

        gradient.startPoint = CGPoint(x: 0.15, y: 0)
        gradient.endPoint = CGPoint(x: 0.85, y: 1)
        layer.addSublayer(gradient)

        letter.font = .systemFont(ofSize: 13, weight: .bold)
        letter.textColor = .white
        letter.textAlignment = .center
        letter.adjustsFontSizeToFitWidth = true
        letter.minimumScaleFactor = 0.7
        letter.translatesAutoresizingMaskIntoConstraints = false
        addSubview(letter)
        NSLayoutConstraint.activate([
            letter.centerXAnchor.constraint(equalTo: centerXAnchor),
            letter.centerYAnchor.constraint(equalTo: centerYAnchor),
            letter.widthAnchor.constraint(lessThanOrEqualTo: widthAnchor, multiplier: 0.82),
        ])
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        // a resize must not animate the fill from its old bounds
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        gradient.frame = bounds
        CATransaction.commit()
    }

    override var intrinsicContentSize: CGSize {
        CGSize(width: 29, height: 29)
    }

    func show(initial: String, tone: ProviderTint.Tone) {
        letter.text = initial
        gradient.colors = [tone.top.cgColor, tone.bottom.cgColor]
    }
}

/// What a row says about an endpoint's balance once it has been asked.
enum ProviderBalanceBadge: Equatable {
    /// Nothing has been asked yet, or there is nothing to ask.
    case hidden
    case checking
    /// A number, and whether it is low enough to read as a warning.
    case amount(String, low: Bool)
    /// A word instead of a number: a subscription, or a route that cannot be asked.
    case note(String)
}

/// A pill with its own padding, which a plain `UILabel` does not have.
///
/// `intrinsicContentSize` is overridden rather than the label being wrapped in
/// a view, so a cell can size itself from one constraint.
final class ProviderPillLabel: UILabel {
    var insets = UIEdgeInsets(top: 3, left: 8, bottom: 3, right: 8) {
        didSet { invalidateIntrinsicContentSize() }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        font = .systemFont(ofSize: 12.5, weight: .semibold)
        adjustsFontForContentSizeCategory = false
        layer.cornerRadius = 7
        layer.cornerCurve = .continuous
        layer.masksToBounds = true
        textAlignment = .center
        setContentHuggingPriority(.required, for: .horizontal)
        setContentCompressionResistancePriority(.required, for: .horizontal)
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    override func drawText(in rect: CGRect) {
        super.drawText(in: rect.inset(by: insets))
    }

    override var intrinsicContentSize: CGSize {
        let size = super.intrinsicContentSize
        return CGSize(
            width: size.width + insets.left + insets.right,
            height: max(20, size.height + insets.top + insets.bottom),
        )
    }

    override func sizeThatFits(_ size: CGSize) -> CGSize {
        let fitted = super.sizeThatFits(size)
        return CGSize(
            width: fitted.width + insets.left + insets.right,
            height: max(20, fitted.height + insets.top + insets.bottom),
        )
    }
}

/// The word that says which shelf an endpoint sits on, drawn next to the name.
///
/// A dot carries the endpoint's own colour so the chip is read with the mark
/// rather than as a second label: two relays both marked `Relay` are told
/// apart by the dot before the text is read.
final class ProviderGroupChip: UIView {
    private let dot = UIView()
    private let text = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        layer.cornerRadius = 6
        layer.cornerCurve = .continuous
        setContentHuggingPriority(.required, for: .horizontal)
        setContentCompressionResistancePriority(.required, for: .horizontal)

        dot.layer.cornerRadius = 3
        dot.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            dot.widthAnchor.constraint(equalToConstant: 6),
            dot.heightAnchor.constraint(equalToConstant: 6),
        ])

        text.font = .systemFont(ofSize: 11.5, weight: .semibold)
        text.setContentCompressionResistancePriority(.required, for: .horizontal)

        let row = UIStackView(arrangedSubviews: [dot, text])
        row.axis = .horizontal
        row.alignment = .center
        row.spacing = 5
        row.isUserInteractionEnabled = false
        row.translatesAutoresizingMaskIntoConstraints = false
        addSubview(row)
        NSLayoutConstraint.activate([
            row.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 7),
            row.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -7),
            row.centerYAnchor.constraint(equalTo: centerYAnchor),
            heightAnchor.constraint(equalToConstant: 20),
        ])
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    func show(_ title: String?, tone: ProviderTint.Tone) {
        guard let title, !title.isEmpty else {
            isHidden = true
            return
        }
        isHidden = false
        text.text = title
        text.textColor = tone.ink
        dot.backgroundColor = tone.top
        backgroundColor = tone.wash
        isAccessibilityElement = true
        accessibilityLabel = title
    }
}

/// One provider in Settings ▸ Model Providers.
///
/// The design's row: the mark, the name it answers to with its group beside it
/// and its host underneath, then — at the end, where the eye goes to compare —
/// what is left on the key. The `…` menu is the table's accessory, set by the
/// controller.
final class ProviderAccountCell: UITableViewCell {
    static let reuseIdentifier = "ProviderAccountCell"

    private let mark = ProviderMarkView()
    private let title = UILabel()
    private let subtitle = UILabel()
    private let group = ProviderGroupChip()
    private let balance = ProviderPillLabel()
    private let titleRow = UIStackView()
    private let texts = UIStackView()
    private let row = UIStackView()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)

        // 16.5pt at -0.28 tracking is the design's row title; a text style
        // would move with Dynamic Type and break the fixed 56pt row it sits in
        title.font = .systemFont(ofSize: 16.5)
        title.adjustsFontForContentSizeCategory = false
        title.numberOfLines = 1
        title.lineBreakMode = .byTruncatingTail
        title.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)

        subtitle.font = .systemFont(ofSize: 13)
        subtitle.adjustsFontForContentSizeCategory = false
        subtitle.textColor = .secondaryLabel
        subtitle.numberOfLines = 1
        subtitle.lineBreakMode = .byTruncatingTail
        subtitle.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)

        balance.isHidden = true

        titleRow.axis = .horizontal
        titleRow.alignment = .center
        titleRow.spacing = 6
        titleRow.addArrangedSubview(title)
        titleRow.addArrangedSubview(group)
        titleRow.addArrangedSubview(UIView())

        texts.axis = .vertical
        texts.spacing = 2
        texts.addArrangedSubview(titleRow)
        texts.addArrangedSubview(subtitle)

        row.axis = .horizontal
        row.alignment = .center
        row.spacing = 12
        row.addArrangedSubview(mark)
        row.addArrangedSubview(texts)
        row.addArrangedSubview(balance)

        contentView.addSubview(row)
        row.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            mark.widthAnchor.constraint(equalToConstant: 29),
            mark.heightAnchor.constraint(equalToConstant: 29),
            row.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 14),
            row.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -2),
            row.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
            row.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10),
            contentView.heightAnchor.constraint(greaterThanOrEqualToConstant: 56),
        ])
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    override func prepareForReuse() {
        super.prepareForReuse()
        balance.isHidden = true
        balance.text = nil
        group.isHidden = true
    }

    /// Draws the row. `detail` is the host (or who is signed in), `initial`
    /// and `tone` are the mark, `group` is the shelf it sits on, and `balance`
    /// arrives later for a row whose endpoint is being asked.
    func show(
        title name: String,
        detail: String,
        initial: String,
        tone: ProviderTint.Tone,
        group groupTitle: String? = nil,
        balance badge: ProviderBalanceBadge = .hidden,
    ) {
        title.text = name
        subtitle.text = detail
        subtitle.isHidden = detail.isEmpty
        mark.show(initial: initial, tone: tone)
        group.show(groupTitle, tone: tone)
        show(badge)
    }

    /// Fills in the balance pill without touching the rest of the row, so a
    /// slow endpoint does not redraw the name under the finger.
    func show(_ badge: ProviderBalanceBadge) {
        switch badge {
        case .hidden:
            balance.isHidden = true
        case .checking:
            balance.isHidden = false
            balance.text = "···"
            balance.textColor = .secondaryLabel
            balance.backgroundColor = UIColor.tertiarySystemFill
        case let .amount(text, low):
            balance.isHidden = false
            balance.text = text
            if low {
                balance.textColor = UIColor(red: 0.64, green: 0.35, blue: 0, alpha: 1)
                balance.backgroundColor = UIColor(red: 1, green: 0.58, blue: 0, alpha: 0.15)
            } else {
                balance.textColor = UIColor(red: 0.12, green: 0.48, blue: 0.22, alpha: 1)
                balance.backgroundColor = UIColor(red: 0.20, green: 0.78, blue: 0.35, alpha: 0.13)
            }
        case let .note(text):
            balance.isHidden = false
            balance.text = text
            balance.textColor = .secondaryLabel
            balance.backgroundColor = UIColor.tertiarySystemFill
        }
        balance.invalidateIntrinsicContentSize()
    }
}
