import ApelinProtocol
import UIKit

/// An unsaved draft, committed by the existing provider form with its primary key.
final class RelayConfigurationController: TableController {
    private var configuration: AgentRelayConfiguration
    private let provider: AgentProvider
    private let values: [AgentSignInField: String]
    private let onSave: (AgentRelayConfiguration) -> Void

    init(
        configuration: AgentRelayConfiguration, provider: AgentProvider,
        values: [AgentSignInField: String], onSave: @escaping (AgentRelayConfiguration) -> Void,
    ) {
        self.configuration = configuration
        if let index = self.configuration.groups.firstIndex(where: { $0.id == AgentRelayConfiguration.defaultGroupID }) {
            self.configuration.groups[index].models = EnabledModels.ids(for: provider).sorted()
        }
        self.provider = provider
        self.values = values
        self.onSave = onSave
        super.init(style: .insetGrouped)
        title = String(localized: "Accounts & API Groups")
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("Use init(configuration:provider:values:onSave:)")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.rightBarButtonItems = [
            UIBarButtonItem(title: String(localized: "Done"), primaryAction: UIAction { [weak self] _ in self?.save() }),
            UIBarButtonItem(systemItem: .add, menu: UIMenu(children: [
                UIAction(title: String(localized: "Add Account"), image: UIImage(systemName: "person.badge.plus")) { [weak self] _ in
                    self?.editAccount(nil)
                },
                UIAction(title: String(localized: "Add API Group"), image: UIImage(systemName: "folder.badge.plus")) { [weak self] _ in
                    self?.editGroup(nil)
                },
            ])),
        ]
        navigationItem.rightBarButtonItems?.last?.accessibilityLabel = String(localized: "Add")
        navigationItem.leftBarButtonItem = editButtonItem
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 56
    }

    @objc private dynamic func save() {
        do {
            try configuration.validate()
            onSave(configuration)
            navigationController?.popViewController(animated: true)
        } catch {
            presentNotice(title: "Unable to Save", message: error.readableMessage)
        }
    }

    override func numberOfSections(in _: UITableView) -> Int {
        2
    }

    override func tableView(_: UITableView, numberOfRowsInSection section: Int) -> Int {
        section == 0 ? configuration.accounts.count + 1 : groups.count
    }

    private var groups: [AgentRelayGroup] {
        let defaults = configuration.groups.first { $0.id == AgentRelayConfiguration.defaultGroupID }
            ?? AgentRelayGroup(
                id: AgentRelayConfiguration.defaultGroupID, name: String(localized: "Default API Group"),
                models: EnabledModels.ids(for: provider).sorted(),
            )
        return [defaults] + configuration.groups.filter { $0.id != AgentRelayConfiguration.defaultGroupID }
    }

    override func tableView(_: UITableView, titleForHeaderInSection section: Int) -> String? {
        section == 0 ? String(localized: "Account Priority") : String(localized: "API Groups")
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "relay") ?? UITableViewCell(style: .subtitle, reuseIdentifier: "relay")
        var content = cell.defaultContentConfiguration()
        content.textProperties.numberOfLines = 0
        content.secondaryTextProperties.numberOfLines = 0
        cell.accessoryType = .disclosureIndicator
        cell.selectionStyle = indexPath.section == 0 && indexPath.row == 0 ? .none : .default
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                content.text = String(localized: "Primary Account")
                content.secondaryText = groups.first?.name
                content.image = UIImage(systemName: "person.fill")
                cell.accessoryType = .none
            } else {
                let account = configuration.accounts[indexPath.row - 1]
                content.text = account.name
                let group = groups.first { $0.id == account.groupID }?.name ?? ""
                content.secondaryText = account.enabled ? group : "\(group) · \(String(localized: "Disabled"))"
                content.image = UIImage(systemName: account.enabled ? "person" : "person.slash")
            }
        } else {
            let group = groups[indexPath.row]
            content.text = group.name
            content.secondaryText = String(localized: "Models") + ": \(group.models.count)"
            content.image = UIImage(systemName: "folder")
        }
        cell.contentConfiguration = content
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.section == 0 {
            if indexPath.row > 0 {
                editAccount(configuration.accounts[indexPath.row - 1])
            }
        } else {
            editGroup(groups[indexPath.row])
        }
    }

    private func editAccount(_ account: AgentRelayAccount?) {
        let page = RelayAccountEditor(account: account, groups: groups) { [weak self] edited in
            guard let self else { return }
            if let index = configuration.accounts.firstIndex(where: { $0.id == edited.id }) {
                configuration.accounts[index] = edited
            } else {
                configuration.accounts.append(edited)
            }
            tableView.reloadData()
        }
        navigationController?.pushViewController(page, animated: true)
    }

    private func editGroup(_ group: AgentRelayGroup?) {
        let group = group ?? AgentRelayGroup(name: "")
        var draft = values
        draft[.relayConfiguration] = nil
        if group.id != AgentRelayConfiguration.defaultGroupID {
            draft[.apiKey] = configuration.accounts.first { $0.enabled && $0.groupID == group.id }?.apiKey ?? ""
        }
        let page = RelayGroupEditor(group: group, provider: provider, values: draft) { [weak self] edited in
            guard let self else { return }
            if let index = configuration.groups.firstIndex(where: { $0.id == edited.id }) {
                configuration.groups[index] = edited
            } else {
                configuration.groups.append(edited)
            }
            tableView.reloadData()
        }
        navigationController?.pushViewController(page, animated: true)
    }

    override func tableView(_: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        indexPath.section == 0 ? indexPath.row > 0 : groups[indexPath.row].id != AgentRelayConfiguration.defaultGroupID
    }

    override func tableView(_: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        indexPath.section == 0 && indexPath.row > 0
    }

    override func tableView(_: UITableView, targetIndexPathForMoveFromRowAt source: IndexPath, toProposedIndexPath proposed: IndexPath) -> IndexPath {
        guard proposed.section == 0, proposed.row > 0 else { return source }
        return proposed
    }

    override func tableView(_: UITableView, moveRowAt source: IndexPath, to destination: IndexPath) {
        let account = configuration.accounts.remove(at: source.row - 1)
        configuration.accounts.insert(account, at: destination.row - 1)
    }

    override func tableView(_: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        guard editingStyle == .delete else { return }
        if indexPath.section == 0 {
            configuration.accounts.remove(at: indexPath.row - 1)
        } else {
            let id = groups[indexPath.row].id
            guard !configuration.accounts.contains(where: { $0.groupID == id }) else {
                presentNotice(title: "API Groups", message: "Move or remove the accounts in this API group first.")
                return
            }
            configuration.groups.removeAll { $0.id == id }
        }
        tableView.reloadData()
    }
}

final class RelayAccountEditor: TableController {
    private var account: AgentRelayAccount
    private let groups: [AgentRelayGroup]
    private let onSave: (AgentRelayAccount) -> Void
    private let nameField = UITextField()
    private let keyField = UITextField()
    private let enabledSwitch = UISwitch()

    init(account: AgentRelayAccount?, groups: [AgentRelayGroup], onSave: @escaping (AgentRelayAccount) -> Void) {
        self.account = account ?? AgentRelayAccount(name: "", apiKey: "")
        self.groups = groups
        self.onSave = onSave
        super.init(style: .insetGrouped)
        title = String(localized: "Account")
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("Use init(account:groups:onSave:)")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        nameField.text = account.name
        nameField.placeholder = String(localized: "Name")
        nameField.accessibilityLabel = String(localized: "Name")
        keyField.text = account.apiKey
        keyField.placeholder = String(localized: "API Key")
        keyField.accessibilityLabel = String(localized: "API Key")
        keyField.isSecureTextEntry = true
        for field in [nameField, keyField] {
            field.font = .preferredFont(forTextStyle: .body)
            field.autocapitalizationType = .none
            field.autocorrectionType = .no
            field.clearButtonMode = .whileEditing
        }
        enabledSwitch.isOn = account.enabled
        enabledSwitch.accessibilityLabel = String(localized: "Enabled")
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: String(localized: "Save"), primaryAction: UIAction { [weak self] _ in
            self?.save()
        })
        tableView.keyboardDismissMode = .interactive
    }

    @objc private dynamic func save() {
        account.name = (nameField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        account.apiKey = (keyField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        account.enabled = enabledSwitch.isOn
        do {
            try AgentRelayConfiguration(groups: groups, accounts: [account]).validate()
            onSave(account)
            navigationController?.popViewController(animated: true)
        } catch {
            presentNotice(title: "Unable to Save", message: "Enter an account name and a valid API key.")
        }
    }

    override func tableView(_: UITableView, numberOfRowsInSection _: Int) -> Int {
        4
    }

    override func tableView(_: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.selectionStyle = .none
        if indexPath.row < 2 {
            let field = indexPath.row == 0 ? nameField : keyField
            field.translatesAutoresizingMaskIntoConstraints = false
            cell.contentView.addSubview(field)
            NSLayoutConstraint.activate([
                field.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
                field.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
                field.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 12),
                field.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -12),
            ])
        } else {
            var content = UIListContentConfiguration.valueCell()
            content.text = indexPath.row == 2 ? String(localized: "API Group") : String(localized: "Enabled")
            if indexPath.row == 2 {
                content.secondaryText = groups.first { $0.id == account.groupID }?.name
                    ?? String(localized: "Default API Group")
                content.textProperties.numberOfLines = 0
                content.secondaryTextProperties.numberOfLines = 0
                cell.accessoryType = .disclosureIndicator
                cell.selectionStyle = .default
                cell.accessibilityTraits.insert(.button)
            } else {
                cell.accessoryView = enabledSwitch
            }
            cell.contentConfiguration = content
        }
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard indexPath.row == 2 else { return }
        view.endEditing(true)
        let page = RelayAccountGroupPicker(groups: groups, selectedID: account.groupID) { [weak self] id in
            guard let self else { return }
            account.groupID = id
            tableView.reloadRows(at: [IndexPath(row: 2, section: 0)], with: .none)
        }
        navigationController?.pushViewController(page, animated: true)
    }
}

final class RelayAccountGroupPicker: TableController {
    private let groups: [AgentRelayGroup]
    private let selectedID: String
    private let onSelect: (String) -> Void
    private lazy var dataSource = TableDataSource<Int, String, AgentRelayGroup>(
        tableView: tableView, identifier: { $0.id },
    ) { [weak self] _, _, group in
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        var content = cell.defaultContentConfiguration()
        content.text = group.name
        content.textProperties.numberOfLines = 0
        cell.contentConfiguration = content
        let selected = group.id == self?.selectedID
        cell.accessoryType = selected ? .checkmark : .none
        cell.accessibilityTraits = selected ? [.button, .selected] : .button
        return cell
    }

    init(groups: [AgentRelayGroup], selectedID: String, onSelect: @escaping (String) -> Void) {
        self.groups = groups
        self.selectedID = selectedID
        self.onSelect = onSelect
        super.init(style: .insetGrouped)
        title = String(localized: "API Group")
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("Use init(groups:selectedID:onSelect:)")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 48
        dataSource.update([(0, groups)])
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard let group = dataSource.value(at: indexPath) else { return }
        onSelect(group.id)
        navigationController?.popViewController(animated: true)
    }
}

final class RelayGroupEditor: TableController, UISearchResultsUpdating {
    private var group: AgentRelayGroup
    private let provider: AgentProvider
    private let values: [AgentSignInField: String]
    private let onSave: (AgentRelayGroup) -> Void
    private let nameField = UITextField()
    private let search = UISearchController(searchResultsController: nil)
    @objc private dynamic var catalogue: [String]
    @objc private dynamic var selected: Set<String>
    @objc private dynamic var shown: [String] = []
    private var loader: Task<Void, Never>?

    init(group: AgentRelayGroup, provider: AgentProvider, values: [AgentSignInField: String], onSave: @escaping (AgentRelayGroup) -> Void) {
        self.group = group
        self.provider = provider
        self.values = values
        self.onSave = onSave
        catalogue = group.models
        selected = Set(group.models)
        super.init(style: .insetGrouped)
        title = String(localized: "API Group")
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("Use init(group:provider:values:onSave:)")
    }

    deinit { loader?.cancel() }

    override func viewDidLoad() {
        super.viewDidLoad()
        nameField.text = group.name
        nameField.placeholder = String(localized: "Name")
        nameField.accessibilityLabel = String(localized: "Name")
        nameField.font = .preferredFont(forTextStyle: .body)
        nameField.clearButtonMode = .whileEditing
        search.searchResultsUpdater = self
        search.obscuresBackgroundDuringPresentation = false
        search.searchBar.placeholder = String(localized: "Search")
        navigationItem.searchController = search
        navigationItem.rightBarButtonItems = [
            UIBarButtonItem(title: String(localized: "Save"), primaryAction: UIAction { [weak self] _ in self?.save() }),
            UIBarButtonItem(systemItem: .add, primaryAction: UIAction { [weak self] _ in self?.addModel() }),
            UIBarButtonItem(image: UIImage(systemName: "arrow.clockwise"), primaryAction: UIAction { [weak self] _ in self?.fetch() }),
        ]
        navigationItem.rightBarButtonItems?[1].accessibilityLabel = String(localized: "Add Model")
        navigationItem.rightBarButtonItems?[2].accessibilityLabel = String(localized: "Fetch Models")
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 48
        updateSearchResults(for: search)
    }

    @objc dynamic func updateSearchResults(for searchController: UISearchController) {
        let query = searchController.searchBar.text ?? ""
        shown = catalogue.filter { query.isEmpty || $0.localizedCaseInsensitiveContains(query) }
        tableView.reloadData()
    }

    @objc private dynamic func save() {
        group.name = (nameField.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        group.models = selected.sorted()
        do {
            try AgentRelayConfiguration(groups: [group]).validate()
            onSave(group)
            navigationController?.popViewController(animated: true)
        } catch {
            presentNotice(title: "Unable to Save", message: "Enter an API group name and valid model IDs.")
        }
    }

    @objc private dynamic func addModel() {
        let alert = UIAlertController(title: String(localized: "Add Model"), message: nil, preferredStyle: .alert)
        alert.addTextField {
            $0.placeholder = String(localized: "Model ID")
            $0.accessibilityLabel = String(localized: "Model ID")
            $0.autocapitalizationType = .none
            $0.autocorrectionType = .no
        }
        alert.addAction(UIAlertAction(title: String(localized: "Cancel"), style: .cancel))
        alert.addAction(UIAlertAction(title: String(localized: "Add"), style: .default) { [weak self, weak alert] _ in
            guard let self else { return }
            let model = (alert?.textFields?.first?.text ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            do {
                try AgentRelayConfiguration(groups: [AgentRelayGroup(name: "validation", models: [model])]).validate()
                selected.insert(model)
                catalogue = Array(Set(catalogue + [model])).sorted()
                updateSearchResults(for: search)
            } catch {
                presentNotice(title: "Add Model", message: "Enter a valid model ID without spaces or line breaks.")
            }
        })
        present(alert, animated: true)
    }

    @objc private dynamic func fetch() {
        guard !(values[.apiKey] ?? "").isEmpty else {
            presentNotice(title: "Fetch Models", message: "Add an enabled account to this API group first.")
            return
        }
        loader?.cancel()
        navigationItem.rightBarButtonItems?[2].isEnabled = false
        loader = Task { [weak self, provider, values] in
            do {
                let response = try await ApelinService.app.agentModelList(
                    provider: provider,
                    candidateValues: Dictionary(uniqueKeysWithValues: values.map { ($0.key.rawValue, $0.value) }),
                )
                guard let self, !Task.isCancelled else { return }
                catalogue = Array(Set(response.models).union(selected)).sorted()
                updateSearchResults(for: search)
            } catch {
                guard !Task.isCancelled else { return }
                self?.presentNotice(title: "Models Unavailable", message: error.readableMessage)
            }
            self?.navigationItem.rightBarButtonItems?[2].isEnabled = true
        }
    }

    override func numberOfSections(in _: UITableView) -> Int {
        2
    }

    override func tableView(_: UITableView, numberOfRowsInSection section: Int) -> Int {
        section == 0 ? 1 : shown.count
    }

    override func tableView(_: UITableView, titleForHeaderInSection section: Int) -> String? {
        section == 0 ? String(localized: "Name") : String(localized: "Models")
    }

    override func tableView(_: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        if indexPath.section == 0 {
            nameField.translatesAutoresizingMaskIntoConstraints = false
            cell.contentView.addSubview(nameField)
            NSLayoutConstraint.activate([
                nameField.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
                nameField.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
                nameField.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 12),
                nameField.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -12),
            ])
            cell.selectionStyle = .none
        } else {
            let model = shown[indexPath.row]
            var content = cell.defaultContentConfiguration()
            content.text = model
            content.textProperties.numberOfLines = 0
            cell.contentConfiguration = content
            cell.accessoryType = selected.contains(model) ? .checkmark : .none
            cell.accessibilityTraits = selected.contains(model) ? [.button, .selected] : .button
        }
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard indexPath.section == 1 else { return }
        let model = shown[indexPath.row]
        if selected.contains(model) {
            selected.remove(model)
        } else {
            selected.insert(model)
        }
        tableView.reloadRows(at: [indexPath], with: .none)
    }
}
