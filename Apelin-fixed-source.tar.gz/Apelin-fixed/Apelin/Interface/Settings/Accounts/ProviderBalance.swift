import Foundation

/// What an endpoint says is left on the key it was given.
///
/// Only the routes that answer a number without a browser session can be
/// asked: an OpenAI-compatible gateway's billing endpoints, DeepSeek's own
/// balance and OpenRouter's credits. A relay that keeps balance behind a
/// login page may answer 401 or 404: authentication failures stay distinct
/// from routes that simply do not report a balance.
struct ProviderBalance: Sendable {
    let remaining: Double
    let currency: String
    /// What the key started with, when the endpoint says so.
    let limit: Double?
    /// The path that answered, so the detail page can say what was asked and
    /// a person can check it against the endpoint's own docs.
    var route: String? = nil
    var unit: Unit = .currency
    var used: Double? = nil
    var unlimited = false

    enum Unit: Sendable, Equatable {
        case currency
        case quota
    }

    /// `$16.79`, `$16.79 / $20.00`, or the relay's unscaled quota units.
    var described: String {
        guard !unlimited else { return "∞" }
        let left = amountDescription(remaining)
        guard let limit, limit > 0 else { return left }
        return "\(left) / \(amountDescription(limit))"
    }

    func amountDescription(_ amount: Double) -> String {
        switch unit {
        case .currency:
            Self.money(amount, currency: currency)
        case .quota:
            "\(Self.number(amount)) quota"
        }
    }

    private static func number(_ amount: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 2
        return formatter.string(from: NSNumber(value: amount)) ?? "\(amount)"
    }

    private static func money(_ amount: Double, currency: String) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = currency
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2
        return formatter.string(from: NSNumber(value: amount)) ?? "\(currency) \(amount)"
    }
}

enum ProviderBalanceError: LocalizedError {
    /// The configuration holds no address to ask.
    case noEndpoint
    /// The endpoint answered, with nothing this can read as a balance.
    case unsupported
    /// A candidate route exists but rejected this request.
    case httpStatus(Int)
    /// Sub2API explicitly identified the key as invalid in its usage response.
    case rejectedKey

    var errorDescription: String? {
        switch self {
        case .noEndpoint:
            String(localized: "Unable to Connect")
        case .unsupported:
            String(localized: "This endpoint does not report a balance.")
        case let .httpStatus(status):
            "\(String(localized: "Unable to Connect")) (HTTP \(status))"
        case .rejectedKey:
            "\(String(localized: "Unable to Connect")) (HTTP 401)"
        }
    }
}

enum ProviderBalanceLookup {
    static func displayText(for balance: ProviderBalance) -> String {
        guard !balance.unlimited else { return "∞" }
        let amount: String
        switch balance.unit {
        case .currency:
            let formatter = NumberFormatter()
            formatter.numberStyle = .currency
            formatter.currencyCode = balance.currency
            formatter.minimumFractionDigits = 2
            formatter.maximumFractionDigits = 2
            amount = formatter.string(from: NSNumber(value: balance.remaining))
                ?? "\(balance.currency) \(balance.remaining)"
        case .quota:
            let formatter = NumberFormatter()
            formatter.numberStyle = .decimal
            formatter.maximumFractionDigits = 2
            amount = "\(formatter.string(from: NSNumber(value: balance.remaining)) ?? "\(balance.remaining)") quota"
        }
        if let limit = balance.limit, limit > 0 {
            return "\(amount) / \(balance.amountDescription(limit))"
        }
        return amount
    }

    /// Asks `baseURL`'s endpoint what `apiKey` has left.
    ///
    /// `using` is the protocol picked in the endpoint's form. `auto` reads the
    /// host — DeepSeek and OpenRouter answer on paths of their own — and then
    /// tries the routes an OpenAI-compatible gateway forwards; the rest go
    /// straight to the one route they name, which is what someone picks it
    /// for when the guessing lands on the wrong answer.
    ///
    /// Every base is tried: a relay served under a prefix keeps its billing
    /// endpoints under that prefix too, and asking the bare origin there
    /// answers 404 to everything.
    static func fetch(
        baseURL: String,
        apiKey: String,
        using picked: String = ProviderBalanceProtocol.automatic,
    ) async throws -> ProviderBalance {
        let trimmed = baseURL.trimmingCharacters(in: .whitespacesAndNewlines)
        let roots = roots(of: trimmed)
        guard let first = roots.first else { throw ProviderBalanceError.noEndpoint }
        let host = (first.host ?? "").lowercased()
        var errors: [Error] = []

        for root in roots {
            do {
                return try await attempt(root: root, host: host, key: apiKey, using: picked)
            } catch {
                errors.append(error)
            }
        }
        throw bestProbeError(errors)
    }

    /// One base, asked the way `picked` says, or the way the host suggests.
    private static func attempt(
        root: URL,
        host: String,
        key: String,
        using picked: String,
    ) async throws -> ProviderBalance {
        switch picked {
        case ProviderBalanceProtocol.newAPI, ProviderBalanceProtocol.oneAPI:
            do {
                return try await newAPITokenQuota(root: root, key: key)
            } catch {
                guard let balanceError = error as? ProviderBalanceError else { throw error }
                switch balanceError {
                case .unsupported, .httpStatus(404), .httpStatus(405):
                    return try await newAPI(root: root, key: key)
                default:
                    throw error
                }
            }
        case ProviderBalanceProtocol.deepSeek:
            return try await deepSeek(root: root, key: key)
        case ProviderBalanceProtocol.openRouter:
            return try await openRouter(root: root, key: key)
        case ProviderBalanceProtocol.openAI:
            return try await openAIBilling(root: root, key: key)
        default:
            break
        }

        var errors: [Error] = []
        if host.contains("deepseek") {
            do { return try await deepSeek(root: root, key: key) }
            catch { errors.append(error) }
        }
        if host.contains("openrouter") {
            do { return try await openRouter(root: root, key: key) }
            catch { errors.append(error) }
        }

        for route in ["sub2api", "newapi-token", "newapi", "openai", "credit-grants"] {
            do {
                switch route {
                case "sub2api": return try await sub2API(root: root, key: key)
                case "newapi-token": return try await newAPITokenQuota(root: root, key: key)
                case "newapi": return try await newAPI(root: root, key: key)
                case "openai": return try await openAIBilling(root: root, key: key)
                default: return try await creditGrants(root: root, key: key)
                }
            } catch {
                errors.append(error)
            }
        }
        throw bestProbeError(errors)
    }

    private static func bestProbeError(_ errors: [Error]) -> Error {
        if errors.contains(where: { error in
            guard let balanceError = error as? ProviderBalanceError else { return false }
            if case .rejectedKey = balanceError { return true }
            return false
        }) {
            return ProviderBalanceError.rejectedKey
        }
        if let rejected = errors.reversed().compactMap({ error -> ProviderBalanceError? in
            guard let balanceError = error as? ProviderBalanceError,
                  case let .httpStatus(status) = balanceError,
                  status == 401 || status == 403 else { return nil }
            return .httpStatus(status)
        }).first {
            return rejected
        }
        if let unavailable = errors.reversed().compactMap({ error -> ProviderBalanceError? in
            guard let balanceError = error as? ProviderBalanceError,
                  case let .httpStatus(status) = balanceError,
                  status != 404 && status != 405 else { return nil }
            return .httpStatus(status)
        }).first {
            return unavailable
        }
        let onlyMissingRoutes = !errors.isEmpty && errors.allSatisfy { error in
            guard let balanceError = error as? ProviderBalanceError else { return false }
            switch balanceError {
            case .unsupported:
                true
            case let .httpStatus(status):
                status == 404 || status == 405
            default:
                false
            }
        }
        if onlyMissingRoutes { return ProviderBalanceError.unsupported }
        if let transportError = errors.reversed().first(where: { !($0 is ProviderBalanceError) }) {
            return transportError
        }
        return errors.last ?? ProviderBalanceError.unsupported
    }

    /// Relay APIs are not mounted consistently: keep the base path without
    /// `/v1`, also try the API root without `/api/v1`, then the bare origin.
    private static func roots(of baseURL: String) -> [URL] {
        let candidate = baseURL.contains("://") ? baseURL : "https://" + baseURL
        guard var components = URLComponents(string: candidate),
              components.host?.isEmpty == false
        else { return [] }
        components.query = nil
        components.fragment = nil

        var path = components.path
        while path.hasSuffix("/") { path.removeLast() }

        var result: [URL] = []
        if let suffix = ["/openai/v1", "/api/v1", "/v1"].first(where: { path.hasSuffix($0) }) {
            var versionRoot = components
            versionRoot.path = String(path.dropLast("/v1".count))
            if let url = versionRoot.url { result.append(url) }

            if suffix != "/v1" {
                components.path = String(path.dropLast(suffix.count))
                if let prefixRoot = components.url, !result.contains(prefixRoot) { result.append(prefixRoot) }
            }
        } else {
            components.path = path
            if let prefixed = components.url { result.append(prefixed) }
        }
        components.path = ""
        if let origin = components.url, !result.contains(origin) { result.append(origin) }
        return result
    }

    /// `root` with `path` appended, keeping whatever prefix the base carried.
    private static func joined(_ root: URL, _ path: String) -> URL? {
        var text = root.absoluteString
        while text.hasSuffix("/") { text.removeLast() }
        return URL(string: text + path)
    }

    // MARK: - Routes

    /// New-API and One-API's legacy account quota endpoint.
    ///
    /// `quota` counts in 1/500000 of a dollar — the unit both projects use
    /// internally — and `used_quota` is what has been spent against it, so the
    /// pair gives both the remainder and the ceiling. A site that reports only
    /// the spend, or a key that is down to nothing, still answered the
    /// question that was asked, so neither counts as the route having no
    /// balance.
    private static func newAPI(root: URL, key: String) async throws -> ProviderBalance {
        guard let url = joined(root, "/api/user/self") else { throw ProviderBalanceError.noEndpoint }
        let body = try object(of: try await payload(at: url, key: key))
        guard let user = body["data"] as? [String: Any] else { throw ProviderBalanceError.unsupported }
        // `quota` is the remainder in both projects; older builds name it
        // `remain_quota`.
        let anyQuota = user["quota"] ?? user["remain_quota"]
        guard anyQuota != nil || user["used_quota"] != nil else { throw ProviderBalanceError.unsupported }
        let quota = number(anyQuota)
        let used = number(user["used_quota"])
        let total = (quota + used) / 500_000
        return ProviderBalance(
            remaining: max(0, quota / 500_000),
            currency: "USD",
            limit: total > 0 ? total : nil,
            route: "/api/user/self",
        )
    }

    /// New API's per-token quota endpoint. The quota unit is configured by
    /// each relay, so it must not be formatted as dollars.
    private static func newAPITokenQuota(root: URL, key: String) async throws -> ProviderBalance {
        guard let url = joined(root, "/api/usage/token") else { throw ProviderBalanceError.noEndpoint }
        let body = try object(of: try await payload(at: url, key: key))
        guard let data = body["data"] as? [String: Any],
              data["total_granted"] != nil || data["total_available"] != nil
        else { throw ProviderBalanceError.unsupported }

        let granted = optionalNumber(data["total_granted"])
        let used = optionalNumber(data["total_used"])
        let available = optionalNumber(data["total_available"])
        let unlimited = (data["unlimited_quota"] as? Bool) == true || (granted.map { $0 < 0 } ?? false)
        let remaining = available ?? granted.flatMap { total in used.map { max(0, total - $0) } }
        guard unlimited || remaining != nil else { throw ProviderBalanceError.unsupported }

        return ProviderBalance(
            remaining: remaining ?? 0,
            currency: "quota",
            limit: unlimited ? nil : granted.flatMap { $0 > 0 ? $0 : nil },
            route: "/api/usage/token",
            unit: .quota,
            used: used,
            unlimited: unlimited,
        )
    }

    /// Sub2API's client-key usage endpoint reports quota, wallet, or
    /// subscription amounts depending on the key's mode.
    private static func sub2API(root: URL, key: String) async throws -> ProviderBalance {
        guard let url = joined(root, "/v1/usage") else { throw ProviderBalanceError.noEndpoint }
        let body = try object(of: try await payload(at: url, key: key))
        guard let isValid = body["isValid"] as? Bool else { throw ProviderBalanceError.unsupported }
        guard isValid else { throw ProviderBalanceError.rejectedKey }

        let usage = body["usage"] as? [String: Any]
        let totalUsage = usage?["total"] as? [String: Any]
        let keyUsed = optionalNumber(totalUsage?["actual_cost"])

        if (body["mode"] as? String) == "quota_limited" {
            let quota = body["quota"] as? [String: Any] ?? [:]
            let limit = optionalNumber(quota["limit"])
            let used = body["quota"] != nil ? optionalNumber(quota["used"]) : keyUsed
            let remaining = optionalNumber(quota["remaining"])
                ?? limit.flatMap { total in used.map { max(0, total - $0) } }
            guard let remaining else { throw ProviderBalanceError.unsupported }
            return ProviderBalance(
                remaining: max(0, remaining),
                currency: "USD",
                limit: limit,
                route: "/v1/usage",
                used: used,
            )
        }

        if let wallet = optionalNumber(body["balance"]) {
            return ProviderBalance(
                remaining: max(0, wallet),
                currency: "USD",
                limit: nil,
                route: "/v1/usage",
                used: keyUsed,
            )
        }

        guard let subscriptionRemaining = optionalNumber(body["remaining"]) else {
            throw ProviderBalanceError.unsupported
        }
        let unlimited = subscriptionRemaining < 0
        return ProviderBalance(
            remaining: unlimited ? 0 : max(0, subscriptionRemaining),
            currency: "USD",
            limit: nil,
            route: "/v1/usage",
            used: keyUsed,
            unlimited: unlimited,
        )
    }

    private static func openAIBilling(root: URL, key: String) async throws -> ProviderBalance {
        guard let subscriptionURL = joined(root, "/v1/dashboard/billing/subscription") else {
            throw ProviderBalanceError.noEndpoint
        }
        let subscription = try object(of: try await payload(at: subscriptionURL, key: key))
        let subscriptionData = subscription["data"] as? [String: Any] ?? subscription
        if let balance = optionalNumber(subscriptionData["balance"]) {
            return ProviderBalance(
                remaining: max(0, balance),
                currency: "USD",
                limit: nil,
                route: "/v1/dashboard/billing/subscription",
            )
        }
        let limit = optionalNumber(subscriptionData["hard_limit_usd"])
            ?? optionalNumber(subscriptionData["system_hard_limit_usd"])
            ?? 0
        if limit >= 100_000_000 {
            return ProviderBalance(
                remaining: 0,
                currency: "USD",
                limit: nil,
                route: "/v1/dashboard/billing/subscription",
                unlimited: true,
            )
        }

        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "UTC")
        formatter.dateFormat = "yyyy-MM-dd"
        let now = Date()
        let start = formatter.string(from: now.addingTimeInterval(-86_400 * 365))
        let end = formatter.string(from: now.addingTimeInterval(86_400))

        guard let usageBase = joined(root, "/v1/dashboard/billing/usage"),
              var components = URLComponents(url: usageBase, resolvingAgainstBaseURL: false)
        else { throw ProviderBalanceError.noEndpoint }
        components.queryItems = [
            URLQueryItem(name: "start_date", value: start),
            URLQueryItem(name: "end_date", value: end),
        ]
        guard let usageURL = components.url else { throw ProviderBalanceError.noEndpoint }
        let usageResponse = try object(of: try await payload(at: usageURL, key: key))
        let usage = usageResponse["data"] as? [String: Any] ?? usageResponse
        // `total_usage` is in cents, the one place OpenAI's billing API is
        // not in dollars.
        let used = optionalNumber(usage["total_usage"]).map { $0 / 100 }
            ?? optionalNumber(usage["used_usd"])

        guard limit > 0, let used else { throw ProviderBalanceError.unsupported }
        return ProviderBalance(
            remaining: max(0, limit - used),
            currency: "USD",
            limit: limit,
            route: "/v1/dashboard/billing/subscription",
            used: used,
        )
    }

    /// The older of OpenAI's two billing shapes, which several relays went on
    /// forwarding after the newer pair was retired.
    private static func creditGrants(root: URL, key: String) async throws -> ProviderBalance {
        guard let url = joined(root, "/dashboard/billing/credit_grants") else {
            throw ProviderBalanceError.noEndpoint
        }
        let body = try object(of: try await payload(at: url, key: key))
        guard let grants = body["total_available"] ?? body["total_granted"] else {
            throw ProviderBalanceError.unsupported
        }
        return ProviderBalance(
            remaining: max(0, number(grants)),
            currency: "USD",
            limit: (body["total_granted"] as? NSNumber)?.doubleValue,
            route: "/dashboard/billing/credit_grants",
        )
    }

    private static func deepSeek(root: URL, key: String) async throws -> ProviderBalance {
        guard let url = joined(root, "/user/balance") else { throw ProviderBalanceError.noEndpoint }
        let body = try object(of: try await payload(at: url, key: key))
        guard let infos = body["balance_infos"] as? [[String: Any]],
              let first = infos.first,
              let text = first["total_balance"] as? String,
              let remaining = Double(text)
        else { throw ProviderBalanceError.unsupported }
        return ProviderBalance(
            remaining: remaining,
            currency: first["currency"] as? String ?? "CNY",
            limit: nil,
            route: "/user/balance",
        )
    }

    private static func openRouter(root: URL, key: String) async throws -> ProviderBalance {
        guard let url = joined(root, "/api/v1/credits") else { throw ProviderBalanceError.noEndpoint }
        let body = try object(of: try await payload(at: url, key: key))
        guard let credits = body["data"] as? [String: Any] else { throw ProviderBalanceError.unsupported }
        let total = number(credits["total_credits"])
        let used = number(credits["total_usage"])
        guard total > 0 else { throw ProviderBalanceError.unsupported }
        return ProviderBalance(
            remaining: max(0, total - used),
            currency: "USD",
            limit: total,
            route: "/api/v1/credits",
        )
    }

    // MARK: - Transport

    /// The bytes the endpoint answered with. Returned as `Data` rather than
    /// parsed here: a `[String: Any]` is not `Sendable`, and handing one back
    /// across the await would be a concurrency error under Swift 6.
    private static func payload(at url: URL, key: String) async throws -> Data {
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 20
        request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else {
            throw ProviderBalanceError.unsupported
        }
        guard (200 ..< 300).contains(http.statusCode) else {
            throw ProviderBalanceError.httpStatus(http.statusCode)
        }
        return data
    }

    /// JSON numbers arrive as `Int` or `Double` depending on the value, and
    /// both projects this reads send a mix.
    private static func number(_ value: Any?) -> Double {
        optionalNumber(value) ?? 0
    }

    private static func optionalNumber(_ value: Any?) -> Double? {
        if let number = value as? NSNumber { return number.doubleValue }
        if let string = value as? String { return Double(string) }
        return nil
    }

    private static func object(of data: Data) throws -> [String: Any] {
        guard let body = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw ProviderBalanceError.unsupported
        }
        return body
    }
}
