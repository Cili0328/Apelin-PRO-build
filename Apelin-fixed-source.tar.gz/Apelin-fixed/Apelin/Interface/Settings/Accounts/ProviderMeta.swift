import ApelinProtocol
import Foundation

/// What an endpoint carries beyond its credential: the group it sits in, and
/// how its balance is meant to be asked for.
///
/// None of this is a secret and none of it belongs to apelin-agent: a group is
/// a word the person picked, a protocol is a choice about a request this app
/// makes itself. So it lives in `UserDefaults`, keyed by the endpoint's
/// `rawValue`, beside the name and the colour — and out of the keychain, which
/// holds the one thing that must not be written twice.
struct ProviderMeta: Codable, Equatable {
    /// Which shelf the endpoint sits on: `Primary`, `Backup`, `Relay`,
    /// `Official`, or nothing at all. Also what the row's chip says.
    var group: String?

    /// Whether this screen may ask the endpoint for a balance at all. A relay
    /// that rate-limits, or a key that is metered elsewhere, is asked nothing
    /// once this is off.
    var balanceEnabled: Bool = true

    /// Which billing shape to ask for. `auto` reads the host and tries in
    /// turn, which is what most endpoints need; the rest skip the guessing.
    var balanceProtocol: String = ProviderBalanceProtocol.automatic

    /// How often a balance is asked for again, in minutes. `0` never.
    var refreshMinutes: Int = 30

    /// Under this, the row's pill turns amber and the detail page says the
    /// key is running out.
    var warnThreshold: Double = 5
}

enum ProviderMetaStore {
    private static let storageKey = "provider.meta"

    /// Everything stored, parsed once per call: the list is short enough that
    /// caching it would only be a second place for it to be wrong.
    private static var all: [String: ProviderMeta] {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let decoded = try? JSONDecoder().decode([String: ProviderMeta].self, from: data)
        else { return [:] }
        return decoded
    }

    static func meta(for rawValue: String) -> ProviderMeta {
        all[rawValue] ?? ProviderMeta()
    }

    static func meta(for provider: AgentProvider) -> ProviderMeta {
        meta(for: provider.rawValue)
    }

    static func set(_ meta: ProviderMeta, for rawValue: String) {
        var every = all
        every[rawValue] = meta
        guard let data = try? JSONEncoder().encode(every) else { return }
        UserDefaults.standard.set(data, forKey: storageKey)
    }

    /// Edits in place, so a change to one field does not have to spell out
    /// the other four and risk resetting them to their defaults.
    static func update(_ rawValue: String, _ body: (inout ProviderMeta) -> Void) {
        var meta = meta(for: rawValue)
        body(&meta)
        set(meta, for: rawValue)
    }
}

/// The billing shapes this app knows how to ask for.
enum ProviderBalanceProtocol {
    static let automatic = "auto"
    static let newAPI = "newapi"
    static let oneAPI = "oneapi"
    static let openRouter = "openrouter"
    static let deepSeek = "deepseek"
    static let openAI = "openai"

    /// In the order the picker shows them: automatic first, because it is what
    /// almost every endpoint wants.
    static let all = [automatic, newAPI, oneAPI, openRouter, deepSeek, openAI]

    static func title(_ value: String) -> String {
        switch value {
        case newAPI: String(localized: "New-API Standard")
        case oneAPI: String(localized: "One-API Standard")
        case openRouter: String(localized: "OpenRouter Credits")
        case deepSeek: String(localized: "DeepSeek Balance")
        case openAI: String(localized: "OpenAI Billing")
        default: String(localized: "Automatic")
        }
    }
}

/// The groups the design offers, in the order it lists them. A group is only
/// a word on a chip and a heading — nothing branches on it.
enum ProviderGroup {
    static let primary = "Primary"
    static let backup = "Backup"
    static let relay = "Relay"
    static let official = "Official"

    static let all = [primary, backup, relay, official]

    /// The word as it is written on the row.
    static func title(_ value: String?) -> String? {
        guard let value, !value.isEmpty else { return nil }
        switch value {
        case primary: return String(localized: "Primary")
        case backup: return String(localized: "Backup")
        case relay: return String(localized: "Relay")
        case official: return String(localized: "Official")
        default: return value
        }
    }
}
