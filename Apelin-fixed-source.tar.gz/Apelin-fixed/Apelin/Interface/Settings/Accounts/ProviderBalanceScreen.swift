import ApelinProtocol
import UIKit

/// What an endpoint's key has left, and how fast it is going.
///
/// The number alone is not worth a page — it is on the row behind this one.
/// What is worth a page is the shape of it: what was spent today, what was
/// spent this month, which route answered, and a bar per day so a week of
/// spending is one glance.
final class ProviderBalanceScreen: TableController {
    private let name: String
    private let baseURL: String
    private let apiKey: String
    private let rawValue: String
    private let accountID: String?
    private var meta: ProviderMeta

    private var balance: ProviderBalance?
    private var lastUpdated: Date?
    private var historyIdentity: String {
        ProviderBalanceHistory.identity(providerRawValue: rawValue, baseURL: baseURL, accountID: accountID)
    }

    private var historyCurrency: String? {
        guard let balance else { return nil }
        return balance.unit == .quota ? "quota" : balance.currency
    }

    private var failure: String?
    private var loading = false
    private var loader: Task<Void, Never>?

    private enum Row: Hashable {
        case amount
        case status
        case chart
        case spendToday
        case spendMonth
        case spendGrant
        case route
        case refreshInterval
        case warning
        case refreshButton
        case message
    }

    private enum Section: Hashable {
        case hero
        case spend
        case query
        case action
    }

    private lazy var dataSource = TableDataSource<Section, Row, Row>(
        tableView: tableView,
        identifier: { $0 },
    ) { [weak self] _, _, row in
        self?.cell(for: row)
    }

    init(name: String, baseURL: String, apiKey: String, rawValue: String, meta: ProviderMeta, accountID: String? = nil) {
        self.name = name
        self.baseURL = baseURL
        self.apiKey = apiKey
        self.rawValue = rawValue
        self.accountID = accountID
        self.meta = meta
        super.init(style: .insetGrouped)
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    deinit {
        loader?.cancel()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = name
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 48
        navigationItem.largeTitleDisplayMode = .never

        let refresh = UIRefreshControl()
        refresh.addAction(UIAction { [weak self] _ in self?.load() }, for: .valueChanged)
        tableView.refreshControl = refresh

        let reload = UIBarButtonItem(
            image: UIImage(systemName: "arrow.clockwise"),
            primaryAction: UIAction { [weak self] _ in self?.load() },
        )
        reload.accessibilityLabel = String(localized: "Refresh")
        navigationItem.rightBarButtonItem = reload

        dataSource.headerTitle = { section in
            switch section {
            case .spend: String(localized: "Spent")
            case .query: String(localized: "Lookup")
            case .hero, .action: nil
            }
        }
        rebuild()
        load()
    }

    // MARK: - Asking

    private func load() {
        loader?.cancel()
        loading = true
        rebuild()
        loader = Task { [weak self] in
            guard let self else { return }
            do {
                let balance = try await ProviderBalanceLookup.fetch(
                    baseURL: baseURL,
                    apiKey: apiKey,
                    using: meta.balanceProtocol,
                )
                guard !Task.isCancelled else { return }
                ProviderBalanceHistory.cache(balance, for: historyIdentity)
                self.balance = balance
                lastUpdated = Date()
                failure = nil
            } catch let error as ProviderBalanceError {
                guard !Task.isCancelled else { return }
                failure = error.localizedDescription
                balance = nil
            } catch {
                guard !Task.isCancelled else { return }
                failure = error.localizedDescription
                balance = nil
            }
            loading = false
            tableView.refreshControl?.endRefreshing()
            rebuild()
        }
    }

    // MARK: - Sections

    private func rebuild() {
        var sections: [(Section, [Row])] = []
        if loading, balance == nil {
            sections.append((.hero, [.message]))
        } else if balance != nil {
            sections.append((.hero, [.amount, .status, .chart]))
            sections.append((.spend, [.spendToday, .spendMonth, .spendGrant]))
        } else {
            sections.append((.hero, [.message]))
        }
        sections.append((.query, [.route, .refreshInterval, .warning]))
        sections.append((.action, [.refreshButton]))
        dataSource.update(sections)
    }

    private func cell(for row: Row) -> UITableViewCell {
        switch row {
        case .amount: amountCell()
        case .status: statusCell()
        case .chart: chartCell()
        case .spendToday: valueCell(String(localized: "Today"), historyMoney(ProviderBalanceHistory.spentToday(historyIdentity, currency: historyCurrency)))
        case .spendMonth: valueCell(String(localized: "This Month"), historyMoney(ProviderBalanceHistory.spentThisMonth(historyIdentity, currency: historyCurrency)))
        case .spendGrant: grantCell()
        case .route: routeCell()
        case .refreshInterval: valueCell(String(localized: "Auto Refresh"), refreshTitle)
        case .warning: valueCell(String(localized: "Warns Under"), money(meta.warnThreshold, currency: balance?.currency ?? "USD"))
        case .refreshButton: buttonCell()
        case .message: messageCell()
        }
    }

    private func amountCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.selectionStyle = .none
        cell.isAccessibilityElement = false

        let caption = UILabel()
        caption.text = String(localized: "Available Balance")
        caption.font = .systemFont(ofSize: 12.5)
        caption.textColor = .secondaryLabel

        let value = UILabel()
        value.font = .systemFont(ofSize: 40, weight: .bold)
        value.adjustsFontSizeToFitWidth = true
        value.minimumScaleFactor = 0.6
        value.text = balance.map { $0.unlimited ? "∞" : Self.split($0).number } ?? "—"
        value.textColor = .label

        let stack = UIStackView(arrangedSubviews: [caption, value])
        stack.axis = .vertical
        stack.spacing = 2
        stack.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
            stack.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 18),
            stack.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -6),
        ])

        // the currency is set smaller than the number, as the design draws it
        if let balance, !balance.unlimited {
            let parts = Self.split(balance)
            let text = NSMutableAttributedString(
                string: parts.symbol,
                attributes: [.font: UIFont.systemFont(ofSize: 18, weight: .semibold), .foregroundColor: UIColor.label],
            )
            text.append(NSAttributedString(
                string: parts.number,
                attributes: [
                    .font: UIFont.systemFont(ofSize: 40, weight: .bold),
                    .foregroundColor: UIColor.label,
                ],
            ))
            value.attributedText = text
        }
        return cell
    }

    private func statusCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.selectionStyle = .none
        cell.isAccessibilityElement = false

        let chip = ProviderPillLabel()
        let low = balance.map { !$0.unlimited && $0.remaining < meta.warnThreshold } ?? false
        if balance == nil {
            chip.text = String(localized: "No Balance")
            chip.textColor = .secondaryLabel
            chip.backgroundColor = UIColor.tertiarySystemFill
        } else if low {
            chip.text = String(localized: "Low")
            chip.textColor = UIColor(red: 0.64, green: 0.35, blue: 0, alpha: 1)
            chip.backgroundColor = UIColor(red: 1, green: 0.58, blue: 0, alpha: 0.15)
        } else {
            chip.text = String(localized: "Normal")
            chip.textColor = UIColor(red: 0.12, green: 0.48, blue: 0.22, alpha: 1)
            chip.backgroundColor = UIColor(red: 0.20, green: 0.78, blue: 0.35, alpha: 0.13)
        }

        let when = UILabel()
        when.font = .systemFont(ofSize: 12)
        when.textColor = .secondaryLabel
        when.text = lastUpdated.map { Self.relative($0) } ?? (loading ? String(localized: "Checking…") : "")

        let row = UIStackView(arrangedSubviews: [chip, when])
        row.axis = .horizontal
        row.spacing = 6
        row.alignment = .center
        row.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(row)
        NSLayoutConstraint.activate([
            row.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
            row.trailingAnchor.constraint(lessThanOrEqualTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
            row.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 2),
            row.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -12),
        ])
        return cell
    }

    private func chartCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.selectionStyle = .none
        cell.isAccessibilityElement = false

        let history = ProviderBalanceHistory.recent(historyIdentity, days: 7, currency: historyCurrency)
        let chart = ProviderBalanceChart(values: history.map { $0?.remaining })
        chart.translatesAutoresizingMaskIntoConstraints = false

        let labels = UIStackView()
        labels.axis = .horizontal
        labels.distribution = .fillEqually
        labels.spacing = 6
        for offset in (0 ..< 7).reversed() {
            let label = UILabel()
            label.text = ProviderBalanceHistory.axisLabel(for: offset)
            label.font = .systemFont(ofSize: 9.5)
            label.textColor = .tertiaryLabel
            label.textAlignment = .center
            labels.addArrangedSubview(label)
        }
        labels.translatesAutoresizingMaskIntoConstraints = false

        cell.contentView.addSubview(chart)
        cell.contentView.addSubview(labels)
        NSLayoutConstraint.activate([
            chart.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
            chart.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
            chart.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 6),
            chart.heightAnchor.constraint(equalToConstant: 64),
            labels.leadingAnchor.constraint(equalTo: chart.leadingAnchor),
            labels.trailingAnchor.constraint(equalTo: chart.trailingAnchor),
            labels.topAnchor.constraint(equalTo: chart.bottomAnchor, constant: 6),
            labels.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -14),
        ])
        return cell
    }

    private func grantCell() -> UITableViewCell {
        guard let balance, let limit = balance.limit else {
            return valueCell(String(localized: "Granted / Used"), "—")
        }
        let spent = balance.used ?? max(0, limit - balance.remaining)
        let text = "\(balance.amountDescription(spent)) / \(balance.amountDescription(limit))"
        return valueCell(String(localized: "Used / Granted"), text)
    }

    private func routeCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        cell.selectionStyle = .none
        var content = UIListContentConfiguration.valueCell()
        content.text = String(localized: "Route")
        content.secondaryText = balance?.route ?? "—"
        content.secondaryTextProperties.font = .monospacedSystemFont(ofSize: 13, weight: .regular)
        content.secondaryTextProperties.color = .secondaryLabel
        cell.contentConfiguration = content
        return cell
    }

    private func buttonCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        var content = cell.defaultContentConfiguration()
        content.text = loading ? String(localized: "Checking…") : String(localized: "Refresh Now")
        content.textProperties.color = loading ? .secondaryLabel : .tintColor
        content.textProperties.font = .systemFont(ofSize: 16.5, weight: .medium)
        content.textProperties.alignment = .center
        cell.contentConfiguration = content
        cell.selectionStyle = .default
        cell.isUserInteractionEnabled = !loading
        return cell
    }

    private func messageCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.selectionStyle = .none
        var content = cell.defaultContentConfiguration()
        content.text = failure ?? String(localized: "This endpoint does not report a balance.")
        content.textProperties.color = .secondaryLabel
        content.textProperties.font = .systemFont(ofSize: 13.5)
        content.textProperties.alignment = .center
        content.directionalLayoutMargins = NSDirectionalEdgeInsets(top: 24, leading: 16, bottom: 24, trailing: 16)
        cell.contentConfiguration = content
        return cell
    }

    private func valueCell(_ title: String, _ value: String?) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        cell.selectionStyle = .none
        var content = UIListContentConfiguration.valueCell()
        content.text = title
        content.textProperties.font = .systemFont(ofSize: 16.5)
        content.secondaryText = value
        content.secondaryTextProperties.font = .systemFont(ofSize: 16.5)
        content.secondaryTextProperties.color = .secondaryLabel
        cell.contentConfiguration = content
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard case .refreshButton? = dataSource.value(at: indexPath) else { return }
        load()
    }

    // MARK: - Formatting

    private var refreshTitle: String {
        switch meta.refreshMinutes {
        case 0: String(localized: "Never")
        case 15: String(localized: "Every 15 minutes")
        case 30: String(localized: "Every 30 minutes")
        case 60: String(localized: "Every hour")
        case 120: String(localized: "Every 2 hours")
        default: String(localized: "Every \(meta.refreshMinutes) minutes")
        }
    }

    /// The symbol and the number apart, because the design sets the symbol at
    /// half the size and the number carries the page.
    private static func split(_ balance: ProviderBalance) -> (symbol: String, number: String) {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.minimumFractionDigits = balance.unit == .currency ? 2 : 0
        formatter.maximumFractionDigits = 2
        let number = formatter.string(from: NSNumber(value: balance.remaining)) ?? "\(balance.remaining)"
        let symbol = balance.unit == .currency ? currencySymbol(balance.currency) : "quota "
        return (symbol, number)
    }

    private func money(_ amount: Double?, currency: String? = nil) -> String? {
        guard let amount else { return nil }
        return Self.money(amount, currency: currency ?? balance?.currency ?? "USD")
    }

    private func historyMoney(_ amount: Double?) -> String? {
        guard balance?.unit != .quota else { return amount.map { "\($0) quota" } }
        return money(amount)
    }

    private static func money(_ amount: Double, currency: String) -> String {
        let formatter = NumberFormatter()
        if currency == "quota" {
            formatter.numberStyle = .decimal
            formatter.minimumFractionDigits = 0
            formatter.maximumFractionDigits = 2
            let number = formatter.string(from: NSNumber(value: amount)) ?? String(amount)
            return "\(number) quota"
        }
        formatter.numberStyle = .currency
        formatter.currencyCode = currency
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2
        return formatter.string(from: NSNumber(value: amount)) ?? "\(currency) \(amount)"
    }

    private static func currencySymbol(_ code: String) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = code
        return formatter.currencySymbol ?? code
    }

    private static func relative(_ date: Date) -> String {
        let formatter = RelativeDateTimeFormatter()
        formatter.unitsStyle = .short
        return formatter.localizedString(for: date, relativeTo: Date())
    }
}

/// Seven bars, the tallest picked out.
///
/// Drawn from views rather than in `draw(_:)`: each bar is one constraint and
/// the heights are a fraction of the cell's, so nothing has to be laid out by
/// hand when the row resizes.
final class ProviderBalanceChart: UIView {
    private let stack = UIStackView()
    private var bars: [UIView] = []

    init(values: [Double?]) {
        super.init(frame: .zero)
        stack.axis = .horizontal
        stack.alignment = .bottom
        stack.distribution = .fillEqually
        stack.spacing = 6
        stack.translatesAutoresizingMaskIntoConstraints = false
        addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: leadingAnchor),
            stack.trailingAnchor.constraint(equalTo: trailingAnchor),
            stack.topAnchor.constraint(equalTo: topAnchor),
            stack.bottomAnchor.constraint(equalTo: bottomAnchor),
        ])

        let known = values.compactMap(\.self)
        let peak = known.max() ?? 0
        let floor = known.min() ?? 0
        let span = max(peak - floor, 0.0001)

        for value in values {
            let bar = UIView()
            bar.backgroundColor = .label.withAlphaComponent(0.12)
            bar.layer.cornerRadius = 3
            bar.layer.cornerCurve = .continuous
            bar.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
            bar.translatesAutoresizingMaskIntoConstraints = false
            // a day nothing was recorded keeps a stub, so the week still
            // reads as seven days rather than as four
            let fraction = value.map { max(0.08, ($0 - floor) / span) } ?? 0.04
            if value == peak, value != nil {
                bar.backgroundColor = .label
            }
            bars.append(bar)
            // into the stack first: a constraint between two views with no
            // common ancestor throws when it is activated
            stack.addArrangedSubview(bar)
            bar.heightAnchor.constraint(equalTo: stack.heightAnchor, multiplier: fraction).isActive = true
        }
    }

    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) is not used")
    }
}
