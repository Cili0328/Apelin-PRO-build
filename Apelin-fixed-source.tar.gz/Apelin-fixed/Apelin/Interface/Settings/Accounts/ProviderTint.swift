import UIKit

/// The colour a provider carries in the list.
///
/// The list exists to tell several relays apart, and the mark every
/// OpenAI-compatible endpoint shares does not do that: three of them in a row
/// are the same square logo three times, and the host underneath is small
/// enough that reading it is the only way to pick the right one. A colour and
/// the first character of the name are readable before the name is.
///
/// A provider that has not been given a colour takes one by its `rawValue`,
/// stably: the same endpoint keeps the same colour between launches, and two
/// endpoints next to each other almost never share one.
enum ProviderTint {
    struct Tone {
        let top: UIColor
        let bottom: UIColor

        /// Behind a badge's text.
        var wash: UIColor { top.withAlphaComponent(0.15) }
        /// The badge's text: the darker end, so it reads on `wash`.
        var ink: UIColor { bottom }
    }

    /// The five the design draws with, in the order they are handed out.
    static let palette: [Tone] = [
        Tone(top: color(0x5B8DEF), bottom: color(0x3E5FD6)),
        Tone(top: color(0xF0993F), bottom: color(0xD9701F)),
        Tone(top: color(0x34C759), bottom: color(0x1E9E43)),
        Tone(top: color(0xAF7AEF), bottom: color(0x7B4FD6)),
        Tone(top: color(0x8E8E93), bottom: color(0x636366)),
    ]

    /// The tone `rawValue` picks for itself.
    ///
    /// A stable sum, not `hashValue`: Swift seeds its hashing per process, so
    /// a provider would change colour on every launch.
    static func tone(for rawValue: String) -> Tone {
        palette[automaticIndex(for: rawValue)]
    }

    private static func automaticIndex(for rawValue: String) -> Int {
        var sum = 0
        for scalar in rawValue.unicodeScalars {
            sum = (sum &* 31 &+ Int(scalar.value)) % 1_000_003
        }
        return sum % palette.count
    }

    // MARK: - Choosing one

    private static let selectionKey = "provider.tones"

    private static var selections: [String: Int] {
        UserDefaults.standard.dictionary(forKey: selectionKey) as? [String: Int] ?? [:]
    }

    /// The colour chosen for `rawValue`, when one was. `nil` means the
    /// endpoint takes the one it picks for itself.
    static func chosenIndex(for rawValue: String) -> Int? {
        guard let index = selections[rawValue], palette.indices.contains(index) else { return nil }
        return index
    }

    /// The tone `rawValue` draws: the one it was given, or its own.
    static func resolvedTone(for rawValue: String) -> Tone {
        guard let index = chosenIndex(for: rawValue) else { return tone(for: rawValue) }
        return palette[index]
    }

    /// Gives `rawValue` a colour; `nil` hands it back to the automatic one.
    static func choose(_ index: Int?, for rawValue: String) {
        var all = selections
        all[rawValue] = index.flatMap { palette.indices.contains($0) ? $0 : nil }
        UserDefaults.standard.set(all, forKey: selectionKey)
    }

    /// The character a mark draws: one letter, in the case a name is written.
    static func initial(for name: String) -> String {
        guard let first = name.first(where: { !$0.isWhitespace }) else { return "?" }
        return String(first).uppercased()
    }

    private static func color(_ hex: UInt32) -> UIColor {
        UIColor(
            red: CGFloat((hex >> 16) & 0xFF) / 255,
            green: CGFloat((hex >> 8) & 0xFF) / 255,
            blue: CGFloat(hex & 0xFF) / 255,
            alpha: 1,
        )
    }
}
