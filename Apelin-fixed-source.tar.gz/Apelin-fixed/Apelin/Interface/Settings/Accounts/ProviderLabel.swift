import ApelinProtocol
import Foundation

/// The name a person gave a model provider.
///
/// Every OpenAI-compatible endpoint shares one display name and one mark, and
/// the list tells them apart by the host each was signed in to. Two relays
/// behind one gateway, or a host that reads as an API address, come out
/// looking the same anyway. A name is presentation only: it is not part of
/// the credential, it never reaches apelin-agent or kwwk, and it is kept in
/// this app's preferences under the provider's `rawValue` — which names one
/// endpoint (`openAICompatible`, `openAICompatible.2`) exactly, and every
/// other provider once.
enum ProviderLabel {
    private static let key = "provider.names"
    /// Past this a name is a paragraph, and the list draws one line.
    private static let limit = 40

    private static var stored: [String: String] {
        UserDefaults.standard.dictionary(forKey: key) as? [String: String] ?? [:]
    }

    /// The name given to `provider`, or nil when it has none.
    static func name(of provider: AgentProvider) -> String? {
        guard let name = stored[provider.rawValue]?.trimmingCharacters(in: .whitespacesAndNewlines),
              !name.isEmpty
        else { return nil }
        return name
    }

    /// What to call `provider` on screen: the name it was given, or its own.
    static func displayName(of provider: AgentProvider) -> String {
        name(of: provider) ?? provider.displayName
    }

    /// Names `provider`; an empty name takes the name away again.
    static func setName(_ name: String?, for provider: AgentProvider) {
        var all = stored
        let trimmed = (name ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        all[provider.rawValue] = trimmed.isEmpty ? nil : String(trimmed.prefix(limit))
        UserDefaults.standard.set(all, forKey: key)
    }
}
